using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("VXMLService.IntegrationTests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("West Corporation")]
[assembly: AssemblyProduct("VXMLService.IntegrationTests")]
[assembly: AssemblyCopyright("Copyright © West Corporation 2022")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("fc2e8c45-e35d-4b60-a541-d5b49311fc8b")]

// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]