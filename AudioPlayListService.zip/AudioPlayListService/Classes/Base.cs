﻿using System;
using TeleVox.Core.Events;

namespace TeleVox.HouseCalls.Services
{

    public class Base : LoggingEvent
    {
        #region Properties

        protected Guid TransactionID { get; set; }
        protected Guid MessageID { get; set; }
        protected Guid CallID { get; set; }

        #endregion
    }

}