﻿using System;
using System.Collections.Generic;
using System.IO;
using TeleVox.Core.DataContracts;
using TeleVox.Core.Enums;
using TeleVox.FileMgmt.DataContracts;
using TeleVox.FileMgmt.Enums;
using TeleVox.HouseCalls.DataContracts;

namespace TeleVox.HouseCalls.Services
{

    /// <summary>
    /// 
    /// </summary>
    public class AudioFileSync : Base
    {
        #region Public Properties

        /// <summary>
        /// 
        /// </summary>
        public AudioEnum.AudioFileExtension AudioFileExtension { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public AudioEnum.AudioFormat AudioFileFormat { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CustomerRootPath { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FirstNameLibraryRootPath { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PromptsRootPath { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string SurveyRootPath { get; set; }

        #endregion

        #region Public Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public FileSyncRequest GetFileSyncRequest(HCFileSyncRequest request)
        {
            SetCustomerParamOverrides(request.HCCustomerParams);

            var newRequest = new FileSyncRequest
            {
                TransactionID = request.CertifiedAudioPlaylist.TransactionID,
                MessageID = Guid.NewGuid(),
                CustomerID = request.CertifiedAudioPlaylist.CustomerID,
                CustomerNumber = request.CertifiedAudioPlaylist.CustomerNumber
            };

            foreach (CertifiedAudioPlaylistSourceFile playListSourceFile in request.CertifiedAudioPlaylist.SourceFiles)
            {
                if (playListSourceFile is CertifiedAudioPlaylistRecordedSourceFile)
                {
                    var recordedSourceFile = (CertifiedAudioPlaylistRecordedSourceFile) playListSourceFile;

                    var newElement = new FileSyncRequestElement
                    {
                        ElementID = recordedSourceFile.SourceFileID,
                        DestinationFileDirectory = recordedSourceFile.Directory,
                        DestinationFileName = Path.ChangeExtension(recordedSourceFile.FileName, AudioFileExtension.ToString().ToLower()),
                        SourceFileDirectory = recordedSourceFile.Directory,
                        SourceFileFormat = FileMgmtEnums.FileFormat.AUDIO_NMS_24,
                        SourceFileName = recordedSourceFile.FileName,
                        SourceFileRootPath = recordedSourceFile.RootPath
                    };

                    switch (AudioFileFormat)
                    {
                        case AudioEnum.AudioFormat.ULAW:
                            newElement.DestinationFileFormat = FileMgmtEnums.FileFormat.AUDIO_ULAW;
                            break;
                        default:
                            newElement.DestinationFileFormat = FileMgmtEnums.FileFormat.AUDIO_ULAW;
                            break;
                    }

                    switch (recordedSourceFile.AudioFileCategory)
                    {
                        case AudioEnum.AudioFileCategory.Customer:
                            newElement.DestinationFileRootPath = CustomerRootPath;
                            break;
                        case AudioEnum.AudioFileCategory.FirstNameLibrary:
                            newElement.DestinationFileRootPath = FirstNameLibraryRootPath;
                            break;
                        case AudioEnum.AudioFileCategory.Survey:
                            newElement.DestinationFileRootPath = SurveyRootPath;
                            break;
                    }

                    if (newRequest.Elements == null)
                        newRequest.Elements = new List<FileSyncRequestElement>();

                    newRequest.Elements.Add(newElement);
                }
            }

            return newRequest;
        }

        #endregion

        #region Private Methods

        private void SetCustomerParamOverrides(IList<HCCustomerParam> customerParams)
        {
            string audioDestinationCustomerRootPath = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioDestinationCustomerRootPath);
            string audioDestinationFileExtension = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioDestinationFileExtension);
            string audioDestinationFileFormat = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioDestinationFileFormat);
            string audioDestinationFirstNameLibraryRootPath = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioDestinationFirstNameLibraryRootPath);
            string audioDestinationPromptsRootPath = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioDestinationPromptsRootPath);

            if (!string.IsNullOrEmpty(audioDestinationCustomerRootPath))
                CustomerRootPath = audioDestinationCustomerRootPath;

            if (!string.IsNullOrEmpty(audioDestinationFileExtension))
            {
                AudioEnum.AudioFileExtension temp;
                if (Enum.TryParse(audioDestinationFileExtension, true, out temp))
                    AudioFileExtension = temp;
            }

            if (!string.IsNullOrEmpty(audioDestinationFileFormat))
            {
                AudioEnum.AudioFormat temp;
                if (Enum.TryParse(audioDestinationFileFormat, true, out temp))
                    AudioFileFormat = temp;
            }

            if (!string.IsNullOrEmpty(audioDestinationFirstNameLibraryRootPath))
                FirstNameLibraryRootPath = audioDestinationFirstNameLibraryRootPath;

            if (!string.IsNullOrEmpty(audioDestinationPromptsRootPath))
                PromptsRootPath = audioDestinationPromptsRootPath;
        }

        #endregion
    }

}