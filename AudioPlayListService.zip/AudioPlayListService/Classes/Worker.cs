﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using TeleVox.Core.DataContracts;
using TeleVox.Core.Enums;
using TeleVox.Core.Plugins;
using TeleVox.FileMgmt.Business;
using TeleVox.FileMgmt.DataContracts;
using TeleVox.HouseCalls.DataContracts;
using TeleVox.VXML.Core;
using TeleVox.VXML.DataContracts.Calling;

namespace TeleVox.HouseCalls.Services
{

    internal class Worker : WCFServiceWorkerBase
    {
        #region Private Constants

        private const string ClassNameDot = "AudioPlayListService.Worker.";

        #endregion

        #region Internal Methods

        internal RawAudioPlaylist GetRawAudioPlaylist(HCRawAudioPlaylistRequest request)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;
            RawAudioPlaylist rawAudioPlaylist = null;
            
            // Validation
            try
            {
                if (request == null)
                    throw new Exception("Request cannot be null.");
                if (request.ScheduledCall == null)
                    throw new Exception("ScheduledCall cannot be null.");
            }
            catch (Exception ex)
            {
                FireLoggingEvent(Guid.Empty, Guid.Empty, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
                return null;
            }

            // Set for Logging
            TransactionID = request.ScheduledCall.TransactionID;
            MessageID = request.ScheduledCall.MessageID;

            try
            {
                // Start Stopwatch
                var sw = new Stopwatch();
                sw.Start();

                // Logging
                var entry = new MessageLogEntry
                {
                    TransactionID = TransactionID.ToString(),
                    MessageID = MessageID.ToString(),
                    Status = LoggingEnums.MessageLogStatus.Received.ToString(),
                    Body = XMLFunctionLibrary.SerializeObject(request, true)
                };
                FireLoggingEvent(entry);

                // Work
                var biz = new AudioPlaylist
                {
                    AudioFileFormat = Configuration.AudioSourceFileFormat,
                    CustomerRootPath = Configuration.AudioSourceCustomerRootPath,
                    FirstNameLibraryRootPath = Configuration.AudioSourceFirstNameLibraryRootPath,
                    CallTransferWhisperMergeType = Enums.WhisperMergeType.Default
                };

                biz.LoggingEventReceived += OnLoggingEventReceived;
                rawAudioPlaylist = biz.GetRawAudioPlaylist(request);
                biz.LoggingEventReceived -= OnLoggingEventReceived;

                // Log Message Created
                if (rawAudioPlaylist != null)
                    FireLoggingEvent(rawAudioPlaylist.GetMessageLogEntry(LoggingEnums.MessageLogStatus.Created));

                // Log Method Duration                
                FireLoggingEvent(TransactionID, MessageID, Guid.Empty, method, "Method Duration: " + sw.Elapsed, LoggingEnums.VerbosityLevel.Medium);
            }
            catch (Exception ex)
            {
                FireLoggingEvent(TransactionID, MessageID, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
            }

            // Return
            return rawAudioPlaylist;
        }

        internal FileSyncRequest GetFileSyncRequest(HCFileSyncRequest request)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;
            FileSyncRequest fileSyncRequest = null;

            // Validation
            try
            {
                if (request == null)
                    throw new Exception("HCFileSyncRequest cannot be null");
                if (request.CertifiedAudioPlaylist == null)
                    throw new Exception("CertifiedAudioPlaylist cannot be null");
            }
            catch (Exception ex)
            {
                FireLoggingEvent(Guid.Empty, Guid.Empty, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
                return null;
            }

            // Set for Logging
            TransactionID = request.CertifiedAudioPlaylist.TransactionID;
            MessageID = request.CertifiedAudioPlaylist.MessageID;

            try
            {
                // Stopwatch
                var sw = new Stopwatch();
                sw.Start();

                // Logging
                var entry = new MessageLogEntry
                {
                    TransactionID = TransactionID.ToString(),
                    MessageID = MessageID.ToString(),
                    Status = LoggingEnums.MessageLogStatus.Received.ToString(),
                    Body = XMLFunctionLibrary.SerializeObject(request, true)
                };
                FireLoggingEvent(entry);

                // Work
                bool useAzureStorage = Convert.ToBoolean(CustomerParam.GetParamValue(request.HCCustomerParams, CustomerParam.UseAzureStorage));

                var biz = new AudioFileSync
                {
                    AudioFileExtension = Configuration.AudioDestinationFileExtension,
                    AudioFileFormat = Configuration.AudioDestinationFileFormat,
                    CustomerRootPath = useAzureStorage ? "{Azure}_{" + Configuration.AzureAudioContainerName + "}_Customer" : Configuration.AudioDestinationCustomerRootPath,                    
                    FirstNameLibraryRootPath = useAzureStorage ? "{Azure}_{" + Configuration.AzureAudioContainerName + "}_FirstNameLibrary" : Configuration.AudioDestinationFirstNameLibraryRootPath,
                    PromptsRootPath = useAzureStorage ? "{Azure}_{" + Configuration.AzureAudioContainerName + "}_Prompts" : Configuration.AudioDestinationPromptsRootPath,
                    SurveyRootPath = useAzureStorage ? "{Azure}_{" + Configuration.AzureAudioContainerName + "}_Survey" : Configuration.AudioDestinationSurveyRootPath
                };

                biz.LoggingEventReceived += OnLoggingEventReceived;
                fileSyncRequest = biz.GetFileSyncRequest(request);
                biz.LoggingEventReceived -= OnLoggingEventReceived;

                // Log Message Created
                if (fileSyncRequest != null)
                    FireLoggingEvent(FileSyncFunctions.GetMessageLogEntry(fileSyncRequest, LoggingEnums.MessageLogStatus.Created));

                // Log Method Duration
                FireLoggingEvent(TransactionID, MessageID, Guid.Empty, method, "Method Duration: " + sw.Elapsed, LoggingEnums.VerbosityLevel.Medium);
            }
            catch (Exception ex)
            {
                FireLoggingEvent(TransactionID, MessageID, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
            }

            // Return
            return fileSyncRequest;
        }

        public List<OutboundCallRequest> GetOutboundCallRequest(HCVXMLRequest request)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;
            List<OutboundCallRequest> requests = null;

            // Validation
            try
            {
                if (request == null)
                    throw new Exception("HCVXMLRequest cannot be null");
            }
            catch (Exception ex)
            {
                FireLoggingEvent(Guid.Empty, Guid.Empty, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
                return null;
            }

            // Set for Logging
            TransactionID = request.CertifiedAudioPlaylist.TransactionID;
            MessageID = request.CertifiedAudioPlaylist.MessageID;

            try
            {
                // Stopwatch
                var sw = new Stopwatch();
                sw.Start();

                // Logging
                var entry = new MessageLogEntry
                {
                    TransactionID = TransactionID.ToString(),
                    MessageID = MessageID.ToString(),
                    Status = LoggingEnums.MessageLogStatus.Received.ToString(),
                    Body = XMLFunctionLibrary.SerializeObject(request, true)
                };
                FireLoggingEvent(entry);

                // Work
                bool useVXMLWebAPI = Convert.ToBoolean(CustomerParam.GetParamValue(request.HCCustomerParams, CustomerParam.UseVXMLWebAPI));                
                bool useAzureStorage = Convert.ToBoolean(CustomerParam.GetParamValue(request.HCCustomerParams, CustomerParam.UseAzureStorage));

                var biz = new VXMLPlaylist
                {
                    AudioDestinationRootPathHTTP = useAzureStorage ? Configuration.AudioDestinationRootPathAzure : Configuration.AudioDestinationRootPathHTTP,
                    CallTransferConnectTimeout = Configuration.CallTransferConnectTimeout,
                    CallTransferMaxCallTime = Configuration.CallTransferMaxCallTime,
                    CallTransferRingBack = Configuration.CallTransferRingBack,
                    CallTransferSonusSteeringDigits = Configuration.CallTransferSonusSteeringDigits,
                    CallTransferWhisperAcceptType = VXMLEnum.WhisperAcceptType.None,
                    DefaultCallerID = Configuration.DefaultCallerID,
                    DetectionAllowMachineDTMF = Configuration.DetectionAllowMachineDTMF,
                    DetectionContactType = Configuration.DetectionContactType,
                    DetectionIncludeInitialHumanGreeting = Configuration.DetectionIncludeInitialHumanGreeting,
                    DetectionIncludeInitialMachineGreeting = Configuration.DetectionIncludeInitialMachineGreeting,
                    DetectionMaxLiveDuration = Configuration.DetectionMaxLiveDuration,
                    DetectionMaxRestarts = Configuration.DetectionMaxRestarts,
                    DetectionSourceURL = Configuration.DetectionSourceURL,
                    PostbackCallStatusURL = useVXMLWebAPI ? Configuration.PostbackCallStatusURL_VXMLWebAPI : Configuration.PostbackCallStatusURL,
                    PostbackDispositionURL = useVXMLWebAPI ? Configuration.PostbackDispositionURL_VXMLWebAPI : Configuration.PostbackDispositionURL,
                    PostbackLeaveMessageURL = useVXMLWebAPI ? Configuration.PostbackLeaveMessageURL_VXMLWebAPI : Configuration.PostbackLeaveMessageURL,
                    PostbackOptOutURL = useVXMLWebAPI ? Configuration.PostbackOptOutURL_VXMLWebAPI : Configuration.PostbackOptOutURL,
                    PostbackSurveyURL = useVXMLWebAPI ? Configuration.PostbackSurveyURL_VXMLWebAPI : Configuration.PostbackSurveyURL,
                    TTSFemaleVoice = Configuration.TTSFemaleVoice,
                    TTSMaleVoice = Configuration.TTSMaleVoice,
                    UseAzureStorage = useAzureStorage,
                    UseVXMLWebAPI = useVXMLWebAPI
                };
                biz.LoggingEventReceived += OnLoggingEventReceived;
                requests = biz.GetOutboundCallRequests(request);
                biz.LoggingEventReceived -= OnLoggingEventReceived;

                // Log Message Created
                //if (requests != null)
                //    FireLoggingEvent(requests.GetMessageLogEntry(LoggingEnums.MessageLogStatus.Created));

                // Log Method Duration                
                FireLoggingEvent(TransactionID, MessageID, Guid.Empty, method, "Method Duration: " + sw.Elapsed, LoggingEnums.VerbosityLevel.Medium);
            }
            catch (Exception ex)
            {
                FireLoggingEvent(TransactionID, MessageID, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
            }

            // Return
            return requests;
        }

        public void AddMissingRecordings(HCMissingRecordingsRequest request)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            RawAudioPlaylist raw = request.RawAudioPlaylist;
            CertifiedAudioPlaylist certified = request.CertifiedAudioPlaylist;

            // Validation
            try
            {
                if (raw == null)
                    throw new Exception("RawAudioPlaylist cannot be null");
                if (certified == null)
                    throw new Exception("CertifiedAudioPlaylist cannot be null");
            }
            catch (Exception ex)
            {
                FireLoggingEvent(Guid.Empty, Guid.Empty, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
                return;
            }

            try
            {
                // Stopwatch
                var sw = new Stopwatch();
                sw.Start();

                // Work
                var biz = new AudioPlaylist();
                biz.LoggingEventReceived += OnLoggingEventReceived;
                biz.AddMissingRecordings(raw, certified);
                biz.LoggingEventReceived -= OnLoggingEventReceived;

                // Log Method Duration                
                FireLoggingEvent(raw.TransactionID, raw.MessageID, Guid.Empty, method, "Method Duration: " + sw.Elapsed, LoggingEnums.VerbosityLevel.Medium);
            }
            catch (Exception ex)
            {
                FireLoggingEvent(raw.TransactionID, raw.MessageID, method, ex, LoggingEnums.SeverityLevel.Failure, LoggingEnums.VerbosityLevel.Low);
            }
        }

        #endregion
    }

}