﻿using System.Collections.Generic;
using System.Linq;
using TeleVox.HouseCalls.DataContracts;

namespace TeleVox.HouseCalls.Services
{

    internal static class CustomerParam
    {
        #region Public Constants

        public const string AudioDestinationCustomerRootPath = "HC_AudioDestinationCustomerRootPath";
        public const string AudioDestinationFileExtension = "HC_AudioDestinationFileExtension";
        public const string AudioDestinationFileFormat = "HC_AudioDestinationFileFormat";
        public const string AudioDestinationFirstNameLibraryRootPath = "HC_AudioDestinationFirstNameLibraryRootPath";
        public const string AudioDestinationPromptsRootPath = "HC_AudioDestinationPromptsRootPath";
        public const string AudioDestinationRootPath = "HC_AudioDestinationRootPath";
        public const string AudioDestinationRootPathHTTP = "HC_AudioDestinationRootPathHTTP";
        public const string AudioSourceCustomerRootPath = "HC_AudioSourceCustomerRootPath";
        public const string AudioSourceFileFormat = "HC_AudioSourceFileFormat";
        public const string AudioSourceFirstNameLibraryRootPath = "HC_AudioSourceFirstNameLibraryRootPath";
        public const string CallTransferConnectTimeout = "HC_CallTransferConnectTimeout";
        public const string CallTransferForceWhisper = "HC_CallTransferForceWhisper";
        public const string CallTransferMaxCallTime = "HC_CallTransferMaxCallTime";
        public const string CallTransferRingBack = "HC_CallTransferRingBack";
        public const string CallTransferSonusSteeringDigits = "HC_CallTransferSonusSteeringDigits";
        public const string CallTransferWhisperAcceptType = "HC_CallTransferWhisperAcceptType";
        public const string CallTransferWhisperDefaultAudio = "HC_CallTransferWhisperDefaultAudio";
        public const string CallTransferWhisperMergeType = "HC_CallTransferWhisperMergeType";
        public const string CallTransferWhisperMessage = "HC_CallTransferWhisperMessage";
        public const string DefaultCallerID = "HC_DefaultCallerID";
        public const string DetectionAllowMachineDTMF = "HC_DetectionAllowMachineDTMF";
        public const string DetectionContactType = "HC_DetectionContactType";
        public const string DetectionIncludeInitialHumanGreeting = "HC_DetectionIncludeInitialHumanGreeting";
        public const string DetectionIncludeInitialMachineGreeting = "HC_DetectionIncludeInitialMachineGreeting";
        public const string DetectionMaxLiveDuration = "HC_DetectionMaxLiveDuration";
        public const string DetectionMaxRestarts = "HC_DetectionMaxRestarts";
        public const string DetectionSourceURL = "HC_DetectionSourceURL";
        public const string OutdialerAPN = "HC_OutdialerAPN";
        public const string OutdialerIncludeVxmlDocumentInRequest = "HC_OutdialerIncludeVxmlDocumentInRequest";
        public const string OutdialerPrefetchAudio = "HC_OutdialerPrefetchAudio";
        public const string OutdialerPrefetchInitialPage = "HC_OutdialerPrefetchInitialPage";
        public const string PostbackCallStatusURL = "HC_PostbackCallStatusURL";
        public const string PostbackDispositionURL = "HC_PostbackDispositionURL";
        public const string PostbackLeaveMessageURL = "HC_PostbackLeaveMessageURL";
        public const string PostbackOptOutURL = "HC_PostbackOptOutURL";
        public const string PostbackSurveyURL = "HC_PostbackSurveyURL";
        public const string TTSMaleVoice = "HC_TTSMaleVoice";
        public const string TTSFemaleVoice = "HC_TTSFemaleVoice";
        public const string SimulateCalling = "HC_SimulateCalling";
        public const string DispositionMode = "HC_DispositionMode";
        public const string ConfirmInputInitialFilename = "HC_ConfirmInputInitialFilename";
        public const string ConfirmInputFinalFilename = "HC_ConfirmInputFinalFilename";
        public const string ConfirmResponseQueryString = "HC_ConfirmResponseQueryString";
        public const string CommonScriptQueryString = "HC_CommonScriptQueryString";
        public const string RecordingPromptToBeginFilename = "HC_RecordingPromptToBeginFilename";
        public const string RecordingPromptPress1Filename = "HC_RecordingPromptPress1Filename";
        public const string RecordingPromptPress2Filename = "HC_RecordingPromptPress2Filename";
        public const string RecordingPromptPressPoundFilename = "HC_RecordingPromptPressPoundFilename";
        public const string RecordingPromptPressStarFilename = "HC_RecordingPromptPressStarFilename";
        public const string InvalidResponseFilename = "HC_InvalidResponseFilename";
        public const string MaxRetriesFilename = "HC_MaxRetriesFilename";
        public const string SurveyRootPath = "HC_SurveyRootPath";
        public const string PaymentAmountSubstring = "HC_PaymentAmountSubstring";
        public const string SetProxyAddressInVxml = "HC_SetProxyAddressInVxml";
        public const string DefaultProxyAddressPortInVxml = "HC_DefaultProxyAddressPortInVxml";
        public const string ProxyAddressSiteDNS = "HC_ProxyAddressSiteDNS";
        public const string FetchTimeout = "HC_VXMLFetchTimeout";
        public const string DataFetchTimeout = "HC_VXMLDataFetchTimeout";
        public const string FetchAudioDelay = "HC_VXMLFetchAudioDelay";
        public const string InboundPinLowerBound = "HC_InboundPinLowerBound";
        public const string InboundEnforceCustNumTFN = "HC_InboundEnforceCustNumTFN";
        public const string SuppressCallScheduleStatus = "HC_SuppressCall_ScheduleStatus";
        public const string SuppressCallCallStatus = "HC_SuppressCall_CallStatus";
        public const string CallRetentionDays = "HC_CallRetentionDays";
        public const string UseVXMLWebAPI = "HC_UseVXMLWebAPI";
        public const string UseExternalOutdialer = "HC_UseExternalOutdialer";
        public const string UseAzureStorage = "HC_UseAzureStorage";

        #endregion

        #region Internal Static Methods

        internal static string GetParamValue(IList<HCCustomerParam> customerParams, string name)
        {
            if (customerParams == null || customerParams.Count == 0)
                return null;

            return (from param in customerParams where param.ParamName == name select param.ParamValue).FirstOrDefault();
        }

        #endregion
    }

}