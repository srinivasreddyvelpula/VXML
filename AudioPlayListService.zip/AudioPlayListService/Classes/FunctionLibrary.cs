﻿using System;
using System.Collections.Generic;

namespace TeleVox.HouseCalls.Services
{

    public static class FunctionLibrary
    {

        public static string GetMessageReference(int msgNumber, string msgDescription)
        {
            msgDescription = msgDescription.Replace("&apos;", "~");
            msgDescription = msgDescription.Replace("'", "~");

            return msgNumber + "|" + msgDescription.Trim().Replace("'", "~");
        }

        public static string FormatToString(List<string> values)
        {
            return FormatToString(values, " | ");
        }

        public static string FormatToString(List<string> values, string delimiter)
        {
            string retVal = null;

            if (values != null && values.Count > 0)
            {
                foreach (string value in values)
                {
                    if (retVal == null)
                        retVal = value;
                    else
                        retVal = delimiter + value;
                }
            }

            return retVal;
        }

        public static int GetMod10Digit(string data)
        {
            int sum = 0;
            bool odd = true;
            for (int i = data.Length - 1; i >= 0; i--)
            {
                if (odd)
                {
                    int tSum = Convert.ToInt32(data[i].ToString())*2;
                    if (tSum >= 10)
                    {
                        string tData = tSum.ToString();
                        tSum = Convert.ToInt32(tData[0].ToString()) + Convert.ToInt32(tData[1].ToString());
                    }
                    sum += tSum;
                }
                else
                    sum += Convert.ToInt32(data[i].ToString());
                odd = !odd;
            }

            int result = (((sum/10) + 1)*10) - sum;

            return result%10;
        }

    }

}