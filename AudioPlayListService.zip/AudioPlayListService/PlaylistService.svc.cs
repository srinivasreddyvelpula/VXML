﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel;
using TeleVox.Core.DataContracts;
using TeleVox.Core.Enums;
using TeleVox.Core.Events;
using TeleVox.Core.Plugins;
using TeleVox.FileMgmt.DataContracts;
using TeleVox.HouseCalls.DataContracts;
using TeleVox.HouseCalls.ServiceContracts;
using TeleVox.VXML.DataContracts.Calling;

namespace TeleVox.HouseCalls.Services
{

    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, ConcurrencyMode = ConcurrencyMode.Single)]
    public class AudioPlayListService : WCFService, IAudioPlayList
    {
        #region Private Variables

        private Configuration _config;
        private Worker _worker;

        #endregion

        #region Public Constructors

        public AudioPlayListService()
        {
            Initialize();
        }

        #endregion

        #region Private Methods

        private void Initialize()
        {
            _config = new Configuration();
            _config.LoggingEventReceived += OnLoggingEvent;

            _worker = new Worker();
            _worker.LoggingEventReceived += OnLoggingEvent;
        }

        #endregion

        #region Protectecd Methods

        protected override void UpdateServerProcessConfigurationSetting(Dictionary<string, string> config)
        {
            _config.Load(config);
            UpdateHelperClassProperties();
        }

        #endregion

        #region IAudioPlayList Members

        public RawAudioPlaylist GetRawAudioPlaylist(HCRawAudioPlaylistRequest request)
        {
            try
            {
                Execute();
                return _worker.GetRawAudioPlaylist(request);
            }
            catch (Exception ex)
            {
                var e = new LoggingEventArgs
                {
                    Method = MethodBase.GetCurrentMethod().Name,
                    Message = ex.Message,
                    StackTrace = ex.StackTrace,
                    SendNotification = true,
                    SeverityLevel = LoggingEnums.SeverityLevel.Failure,
                    VerbosityLevel = LoggingEnums.VerbosityLevel.Low,
                    LoggingType = LoggingEnums.LoggingType.Error
                };

                LogEvent(e);

                throw new FaultException(ex.Message);
            }
        }

        public FileSyncRequest GetFileSyncRequest(HCFileSyncRequest request)
        {
            try
            {
                Execute();
                return _worker.GetFileSyncRequest(request);
            }
            catch (Exception ex)
            {
                var e = new LoggingEventArgs
                {
                    Method = MethodBase.GetCurrentMethod().Name,
                    Message = ex.Message,
                    StackTrace = ex.StackTrace,
                    SendNotification = true,
                    SeverityLevel = LoggingEnums.SeverityLevel.Failure,
                    VerbosityLevel = LoggingEnums.VerbosityLevel.Low,
                    LoggingType = LoggingEnums.LoggingType.Error
                };

                LogEvent(e);

                throw new FaultException(ex.Message);
            }
        }

        public List<OutboundCallRequest> GetOutboundCallRequests(HCVXMLRequest request)
        {
            try
            {
                Execute();
                return _worker.GetOutboundCallRequest(request);
            }
            catch (Exception ex)
            {
                var e = new LoggingEventArgs
                {
                    Method = MethodBase.GetCurrentMethod().Name,
                    Message = ex.Message,
                    StackTrace = ex.StackTrace,
                    SendNotification = true,
                    SeverityLevel = LoggingEnums.SeverityLevel.Failure,
                    VerbosityLevel = LoggingEnums.VerbosityLevel.Low,
                    LoggingType = LoggingEnums.LoggingType.Error
                };

                LogEvent(e);

                throw new FaultException(ex.Message);
            }
        }

        public void AddMissingRecordings(HCMissingRecordingsRequest request)
        {
            try
            {
                Execute();
                _worker.AddMissingRecordings(request);
            }
            catch (Exception ex)
            {
                var e = new LoggingEventArgs
                {
                    Method = MethodBase.GetCurrentMethod().Name,
                    Message = ex.Message,
                    StackTrace = ex.StackTrace,
                    SendNotification = true,
                    SeverityLevel = LoggingEnums.SeverityLevel.Failure,
                    VerbosityLevel = LoggingEnums.VerbosityLevel.Low,
                    LoggingType = LoggingEnums.LoggingType.Error
                };

                throw new FaultException(ex.Message);
            }
        }

        #endregion
    }

}