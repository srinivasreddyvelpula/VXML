﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using TeleVox.Core.DataContracts;
using TeleVox.Core.Enums;
using TeleVox.HouseCalls.Data;
using TeleVox.HouseCalls.DataContracts;
using TeleVox.HouseCalls.Enums;
using TeleVox.VXML.Core;
using VoiceElement = TeleVox.HouseCalls.DataContracts.VoiceElement;
using MessageElement = TeleVox.HouseCalls.DataContracts.MessageElement;
using ActionKey = TeleVox.HouseCalls.DataContracts.ActionKey;

namespace TeleVox.HouseCalls.Services
{

    /// <summary>
    /// 
    /// </summary>
    public class AudioPlaylist : Base
    {
        #region Private Constants

        private const string ClassNameDot = "AudioPlayListService.AudioPlaylist.";
        private const string DotVox = ".vox";
        private const string DotVce = ".vce";

        private const string MissingRecordingCustomerNumberPrefix = @"L:\HCASP\";

        #endregion

        #region Private Variables

        private readonly Dictionary<string, RawAudioPlaylistSource> _rawCache = new Dictionary<string, RawAudioPlaylistSource>();

        // Assigned from ScheduledCall
        private string _appPath;
        private int _callNumber;
        private CallParameter _callParameter;
        private Call _currentCall;
        private CallExtendedHC _currentCallExtendedHC;
        private List<HouseCallsCallRecord> _currentCallRecordList;
        private List<MergeElement> _currentMergeElementList;
        private string _customerNumber;
        // ---------------------------------

        // DataContract that is created from ScheduledCall
        private RawAudioPlaylist _rawAudioPlaylist;
        private int _scheduleNumber;
        private int _ttsCount;
        private bool _ttsNames;

        private RawAudioPlaylistElement _whisperElement;

        #endregion

        #region Public Properties

        /// <summary>
        /// 
        /// </summary>
        public AudioEnum.AudioFormat AudioFileFormat { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CustomerRootPath { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FirstNameLibraryRootPath { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Enums.WhisperMergeType CallTransferWhisperMergeType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CallTransferWhisperMessage { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string SurveyRootPath { get; set; }

        #endregion

        private void SetCustomerParamOverrides(IList<HCCustomerParam> customerParams)
        {
            string audioSourceCustomerRootPath = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioSourceCustomerRootPath);
            string audioSourceFileFormat = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioSourceFileFormat);
            string audioSourceFirstNameLibraryRootPath = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioSourceFirstNameLibraryRootPath);
            string callTransferWhisperMergeType = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferWhisperMergeType);
            string callTransferWhisperMessage = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferWhisperMessage);
            string surveyRootPath = CustomerParam.GetParamValue(customerParams, CustomerParam.SurveyRootPath);

            if (!string.IsNullOrEmpty(audioSourceCustomerRootPath))
                CustomerRootPath = audioSourceCustomerRootPath;

            if (!string.IsNullOrEmpty(audioSourceFileFormat))
            {
                AudioEnum.AudioFormat temp;
                if (Enum.TryParse(audioSourceFileFormat, true, out temp))
                    AudioFileFormat = temp;
            }

            if (!string.IsNullOrEmpty(audioSourceFirstNameLibraryRootPath))
                FirstNameLibraryRootPath = audioSourceFirstNameLibraryRootPath;

            if (!string.IsNullOrEmpty(callTransferWhisperMergeType))
            {
                Enums.WhisperMergeType temp;
                if (Enum.TryParse(callTransferWhisperMergeType, true, out temp))
                    CallTransferWhisperMergeType = temp;
            }

            if (!string.IsNullOrEmpty(callTransferWhisperMessage))
                CallTransferWhisperMessage = callTransferWhisperMessage;

            // SurveyRootPath
            if (string.IsNullOrWhiteSpace(surveyRootPath))
                throw new Exception("CustomerParamValue for [SurveyRootPath] cannot be empty.");
            SurveyRootPath = surveyRootPath;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public RawAudioPlaylist GetRawAudioPlaylist(HCRawAudioPlaylistRequest request)
        {
            Initialize();

            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            ScheduledCall schedCall = request.ScheduledCall;

            _rawAudioPlaylist = new RawAudioPlaylist
            {
                TransactionID = schedCall.TransactionID,
                MessageID = schedCall.MessageID,
                CustomerID = schedCall.CustomerID,
                CustomerNumber = schedCall.CustomerNumber
            };

            _scheduleNumber = schedCall.Schedule.ScheduleNumber;
            _customerNumber = schedCall.CustomerNumber;
            _appPath = CustomerRootPath + "\\" + schedCall.CustomerNumber;
            _callParameter = schedCall.CallParameter;
            _ttsNames = schedCall.CallParameter.TTSNames;

            TransactionID = schedCall.TransactionID;
            MessageID = schedCall.MessageID;

            SetCustomerParamOverrides(request.HCCustomerParams);

            FireLoggingEvent(TransactionID, MessageID, method, string.Format("Creating AudioPlayList for {0} calls", schedCall.CallList.Count),
                LoggingEnums.VerbosityLevel.High);

            foreach (Call call in schedCall.CallList)
            {
                CallID = call.CallIDGuid;
                _callNumber = call.CallNumber;
                _currentCall = call;

                try
                {
                    var notification = new RawAudioPlaylistNotification
                    {
                        NotificationID = call.CallIDGuid,
                        Elements = new List<RawAudioPlaylistElement>()
                    };

                    _currentCallExtendedHC = call.CallExtendedHC;
                    _currentCallRecordList = call.CallExtendedHC.HouseCallsCallRecordList;
                    _currentMergeElementList = call.CallExtendedHC.MergeElementList;

                    // Holding a collection of message numbers to prevent repeating
                    var msgNumbers = new ArrayList();

                    foreach (HouseCallsCallRecord callRecord in call.CallExtendedHC.HouseCallsCallRecordList)
                    {
                        HouseCallsCallData callData = callRecord.HouseCallsCallData;
                        short messageNumber = callRecord.HouseCallsCallData.MessageNumber;
                        byte voiceNumber = callData.VoiceNumber;

                        if (msgNumbers.Contains(messageNumber) == false)
                        {
                            // Add this message number to collection
                            msgNumbers.Add(messageNumber);

                            RawAudioPlaylistElement elementToAdd;
                            if (callRecord.State == 0) // callq record
                            {
                                // Human
                                elementToAdd = GetRawAudioPlaylistElement(AudioEnum.AudioPlaylistCategory.Human, messageNumber, callRecord.MessageElementList, voiceNumber);

                                if (elementToAdd != null)
                                    notification.Elements.Add(elementToAdd);
                                // END - Human

                                // Machine
                                short amMsgNumber;
                                byte amVoiceNumber;
                                IEnumerable<MessageElement> amMessageElements = GetAnsweringMachineMessageElements(messageNumber, out amMsgNumber, out amVoiceNumber);

                                if (amVoiceNumber <= 0)
                                    amVoiceNumber = voiceNumber;

                                elementToAdd = GetRawAudioPlaylistElement(AudioEnum.AudioPlaylistCategory.Machine, amMsgNumber, amMessageElements, amVoiceNumber);

                                msgNumbers.Add(amMsgNumber); // add the answering machine message number to collection

                                if (elementToAdd != null)
                                    notification.Elements.Add(elementToAdd);
                                // END - Machine

                                // NoInput

                                // NoMatch
                            }
                            else
                            {
                                // Message
                                elementToAdd = GetRawAudioPlaylistElement(AudioEnum.AudioPlaylistCategory.Message, messageNumber, callRecord.MessageElementList, voiceNumber);

                                if (elementToAdd != null)
                                    notification.Elements.Add(elementToAdd);
                                // END - Message
                            }

                            // ID Options
                            if (callRecord.State == 0) // callq record
                            {
                                elementToAdd = GetRawAudioPlaylistElementForIDOptions(callData);
                                if (elementToAdd != null)
                                    notification.Elements.Add(elementToAdd);
                                // --------------------
                            }

                            // ID Responses
                            List<RawAudioPlaylistElement> elementsToAdd = GetRawAudioPlaylistElementForIDResponses(callData);

                            if (elementsToAdd != null)
                            {
                                foreach (RawAudioPlaylistElement element in elementsToAdd)
                                {
                                    if (element != null)
                                        notification.Elements.Add(element);
                                }
                            }
                            // --------------------

                            // Response Option Instructions
                            elementToAdd = GetRawAudioPlaylistElementForResponseOptions(callData);
                            if (elementToAdd != null)
                                notification.Elements.Add(elementToAdd);
                            // --------------------

                            // Responses
                            elementsToAdd = GetRawAudioPlaylistElementForResponses(callData);

                            if (elementsToAdd != null)
                            {
                                foreach (RawAudioPlaylistElement element in elementsToAdd)
                                {
                                    if (element != null)
                                        notification.Elements.Add(element);
                                }
                            }
                            // END - Responses
                        }
                    }

                    // Call Transfer Whisper
                    _whisperElement = GetWhisperElements();
                    if (_whisperElement != null)
                    {
                        notification.Elements.Add(_whisperElement);
                    }

                    if (notification != null & notification.Elements.Count > 0)
                    {
                        if (_rawAudioPlaylist.Notifications == null)
                            _rawAudioPlaylist.Notifications = new List<RawAudioPlaylistNotification>();

                        _rawAudioPlaylist.AddNotification(notification);
                    }

                    // Surveys
                    if (request.HCSurveys != null)
                    {
                        foreach (HCSurvey survey in request.HCSurveys)
                            AddSurvey(survey);
                    }
                }
                catch (Exception ex)
                {
                    string errorMsg = "Failed to generate RawAudioPlaylist element for CallID: " + call.CallIDGuid;
                    FireLoggingEvent(schedCall.TransactionID, schedCall.MessageID, call.CallIDGuid, method, errorMsg + ex.Message, ex.StackTrace,
                        LoggingEnums.SeverityLevel.Warning);
                }
            }

            AddInbound();

            return _rawAudioPlaylist;
        }

        public void AddSurvey(HCSurvey hcSurvey)
        {
            const string surveyElementsQuestionsPath = @"Elements\Questions\";

            var notify = new RawAudioPlaylistNotification {Elements = new List<RawAudioPlaylistElement>()};

            foreach (var item in hcSurvey.SurveyQuestions)
            {
                var source = new RawAudioPlaylistRecordedSource
                {
                    AudioFileCategory = AudioEnum.AudioFileCategory.Survey,
                    RootPath = SurveyRootPath,
                    Directory = surveyElementsQuestionsPath + _customerNumber + @"\",
                    FileName = item.Question.QuestionID + DotVce,
                    Format = AudioEnum.AudioFormat.NMS_24,
                    IsRequired = true,
                    VoxIndex = -1,
                    SourceID = item.Question.QuestionID
                };
                _rawAudioPlaylist.AddSource(source);

                var element = new RawAudioPlaylistElement
                {
                    Category = AudioEnum.AudioPlaylistCategory.SurveyQuestion,
                    IsRequired = true,
                    SourceID = new List<Guid> {source.SourceID},
                    ElementID = Guid.NewGuid()
                };

                notify.Elements.Add(element);
            }

            _rawAudioPlaylist.AddNotification(notify);
        }

        public void AddInbound()
        {
            var notify = new RawAudioPlaylistNotification {Elements = new List<RawAudioPlaylistElement>()};

            var sources = new List<RawAudioPlaylistRecordedSource>
            {
                new RawAudioPlaylistRecordedSource
                {
                    AudioFileCategory = AudioEnum.AudioFileCategory.Customer,
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = "I-Welcome.vce",
                    Format = AudioEnum.AudioFormat.NMS_24,
                    IsRequired = false,
                    VoxIndex = -1,
                    SourceID = Guid.NewGuid()
                },
                new RawAudioPlaylistRecordedSource
                {
                    AudioFileCategory = AudioEnum.AudioFileCategory.Customer,
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = "I-Access.vce",
                    Format = AudioEnum.AudioFormat.NMS_24,
                    IsRequired = false,
                    VoxIndex = -1,
                    SourceID = Guid.NewGuid()
                },
                new RawAudioPlaylistRecordedSource
                {
                    AudioFileCategory = AudioEnum.AudioFileCategory.Customer,
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = "I-PleaseHold.vce",
                    Format = AudioEnum.AudioFormat.NMS_24,
                    IsRequired = false,
                    VoxIndex = -1,
                    SourceID = Guid.NewGuid()
                },
                new RawAudioPlaylistRecordedSource
                {
                    AudioFileCategory = AudioEnum.AudioFileCategory.Customer,
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = "I-Goodbye.vce",
                    Format = AudioEnum.AudioFormat.NMS_24,
                    IsRequired = false,
                    VoxIndex = -1,
                    SourceID = Guid.NewGuid()
                },
                new RawAudioPlaylistRecordedSource
                {
                    AudioFileCategory = AudioEnum.AudioFileCategory.Customer,
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = "I-NoMatch.vce",
                    Format = AudioEnum.AudioFormat.NMS_24,
                    IsRequired = false,
                    VoxIndex = -1,
                    SourceID = Guid.NewGuid()
                }
            };

            foreach (var source in sources)
            {
                _rawAudioPlaylist.AddSource(source);
            }

            var element = new RawAudioPlaylistElement
            {
                Category = AudioEnum.AudioPlaylistCategory.Inbound,
                IsRequired = false,
                SourceID = sources.Select(source => source.SourceID).ToList(),
                ElementID = Guid.NewGuid()
            };

            notify.Elements.Add(element);

            _rawAudioPlaylist.AddNotification(notify);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="raw"></param>
        /// <param name="certified"></param>
        public void AddMissingRecordings(RawAudioPlaylist raw, CertifiedAudioPlaylist certified)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            if (raw == null || certified == null || certified.SourceFiles == null || certified.SourceFiles.Count == 0)
                return;

            foreach (RawAudioPlaylistSource rawSource in raw.Sources)
            {
                if (rawSource is RawAudioPlaylistRecordedSource)
                {
                    var recordedSource = (RawAudioPlaylistRecordedSource) rawSource;

                    if (recordedSource.NotifyIfMissing)
                    {
                        bool addMissingRecording = true;

                        foreach (CertifiedAudioPlaylistSourceFile certSource in certified.SourceFiles)
                        {
                            if (recordedSource.SourceID == certSource.SourceFileID)
                            {
                                // We know that a recording was used for this element 
                                // But if the generic recording or tts was used, we still add missing recording entry
                                if (certSource is CertifiedAudioPlaylistRecordedSourceFile)
                                {
                                    var myCert = (CertifiedAudioPlaylistRecordedSourceFile) certSource; // only evaluate recorded, TTS will default to True for adding entry
                                    if (!myCert.FileName.StartsWith("BMSG")) // BMSG means it was a generic
                                        addMissingRecording = false; // the intended VCE or VOX recording was found
                                }

                                break;
                            }
                        }

                        if (addMissingRecording)
                        {
                            try
                            {
                                string[] s = recordedSource.NotifyReference.Split('|');
                                var hcMissedCallData = new HCMissedCall();
                                hcMissedCallData.AddMissingRecording(s[0], s[1], Convert.ToInt32(s[2]));
                            }
                            catch (Exception ex)
                            {
                                FireLoggingEvent(raw.TransactionID, raw.MessageID, Guid.Empty, method, ex, LoggingEnums.SeverityLevel.Recoverable);
                            }
                        }
                    }
                }
            }
        }

        #region Private Methods

        private void Initialize()
        {
            TransactionID = Guid.Empty;
            MessageID = Guid.Empty;
            CallID = Guid.Empty;

            _appPath = null;
            _scheduleNumber = -1;
            _callNumber = -1;
            _ttsNames = false;
            _callParameter = null;
            _currentCallRecordList = null;
            _currentMergeElementList = null;
            _ttsCount = 0;
        }

        private IEnumerable<MessageElement> GetAnsweringMachineMessageElements(short messageNumber, out short answeringMachineNumber, out byte voiceNumber)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            var messageElements = new List<MessageElement>();
            answeringMachineNumber = 0;
            voiceNumber = 0;

            // answeringMachineNumber
            foreach (HouseCallsCallRecord callRecord in _currentCallRecordList)
            {
                HouseCallsCallData callData = callRecord.HouseCallsCallData;

                if (callData.MessageNumber == messageNumber)
                {
                    answeringMachineNumber = callData.AnsweringMachineMessageNumber;
                    break;
                }
            }

            // voiceNumber
            foreach (HouseCallsCallRecord callRecord in _currentCallRecordList)
            {
                HouseCallsCallData callData = callRecord.HouseCallsCallData;

                if (callData.MessageNumber == answeringMachineNumber)
                {
                    voiceNumber = callData.VoiceNumber;
                    break;
                }
            }

            // Use the current message if no answering machine assigned
            if (answeringMachineNumber == 0)
                answeringMachineNumber = messageNumber;

            if (answeringMachineNumber > 0)
            {
                foreach (HouseCallsCallRecord callRecord in _currentCallRecordList)
                {
                    if (callRecord.HouseCallsCallData.MessageNumber == answeringMachineNumber)
                    {
                        messageElements = callRecord.MessageElementList;
                        break;
                    }
                }
            }

            FireLoggingEvent(TransactionID, MessageID, CallID, method, string.Format("Returning {0} message elements", messageElements.Count), LoggingEnums.VerbosityLevel.High);

            return messageElements;
        }

        private MergeElement GetMergeElement(CallingEnums.MergeElementType type)
        {
            foreach (MergeElement element in _currentCallExtendedHC.MergeElementList)
            {
                if (element.MergeElementTypeEnum == type)
                    return element;
            }

            return null;
        }

        private char GetMergeVoxCharIndex(short number)
        {
            if (number <= 1000)
                return 'A';
            if (number > 1000 && number <= 2000)
                return 'B';
            if (number > 2000 && number <= 3000)
                return 'C';
            if (number > 3000 && number <= 4000)
                return 'D';
            if (number > 4000 && number <= 5000)
                return 'E';
            if (number > 5000 && number <= 6000)
                return 'F';
            if (number > 6000 && number <= 7000)
                return 'G';
            if (number > 7000 && number <= 8000)
                return 'H';
            if (number > 8000 && number <= 9000)
                return 'I';
            if (number > 9000 && number <= 10000)
                return 'J';

            throw new Exception("GetMergeVoxCharIndex- Invalid Vox Number: " + number);
        }

        private RawAudioPlaylistElement GetWhisperElement()
        {
            RawAudioPlaylistElement element = null;

            RawAudioPlaylistSource audioSource = null;

            MergeElement mergeElement;
            byte voiceNumber = _currentCallRecordList[0].HouseCallsCallData.VoiceNumber;
            short voxIndex = -1;
            const string voiceElementTypeName = "whisper";

            switch (CallTransferWhisperMergeType)
            {
                case Enums.WhisperMergeType.Default:
                    audioSource = GetRawAudioPlaylistSourceFile("MSG", 2, 12, voiceElementTypeName, "");
                    break;
                case Enums.WhisperMergeType.Doctor:
                    mergeElement = GetMergeElement(CallingEnums.MergeElementType.Doctor);
                    voxIndex = (short) mergeElement.MergeNumber;
                    audioSource = GetRawAudioPlaylistSourceFile("U" + GetMergeVoxCharIndex(voxIndex) + "MSG", voiceNumber, voxIndex, voiceElementTypeName,
                        mergeElement.MergeProperName);
                    break;
                case Enums.WhisperMergeType.Location:
                    mergeElement = GetMergeElement(CallingEnums.MergeElementType.Location);
                    voxIndex = (short) mergeElement.MergeNumber;
                    audioSource = GetRawAudioPlaylistSourceFile("L" + GetMergeVoxCharIndex(voxIndex) + "MSG", voiceNumber, voxIndex, voiceElementTypeName,
                        mergeElement.MergeProperName);
                    break;
                case Enums.WhisperMergeType.Procedure:
                    mergeElement = GetMergeElement(CallingEnums.MergeElementType.Procedure);
                    voxIndex = (short) mergeElement.MergeNumber;
                    audioSource = GetRawAudioPlaylistSourceFile("P" + GetMergeVoxCharIndex(voxIndex) + "MSG", voiceNumber, voxIndex, voiceElementTypeName,
                        mergeElement.MergeProperName);
                    break;
            }

            if (audioSource != null)
            {
                element = new RawAudioPlaylistElement
                {
                    Category = AudioEnum.AudioPlaylistCategory.Whisper,
                    IsRequired = false
                };

                if (element.SourceID == null)
                    element.SourceID = new List<Guid>();

                element.SourceID.Add(audioSource.SourceID);
            }

            return element;
        }

        private RawAudioPlaylistElement GetWhisperElements()
        {
            // If CallTransferWhisperMessage cust param is not assigned, use the CallTransferWhisperMergeType cust param value
            if (CallTransferWhisperMessage.IsNullOrEmpty())
            {
                return GetWhisperElement();
            }

            // CallTransferWhisperMessage cust param is assigned so parse it to get audio message

            //var elementList = new List<RawAudioPlaylistElement>();
            RawAudioPlaylistElement element = null;

            byte voiceNumber = _currentCallRecordList[0].HouseCallsCallData.VoiceNumber;
            const string voiceElementTypeName = "whisper";

            // get array of tokens from customer param string

            var tokens = Regex.Split(CallTransferWhisperMessage, @"(\[.*?\])").Where(s => !string.IsNullOrEmpty(s)).ToArray();
            FireLoggingEvent(TransactionID, MessageID, CallID, "GetWhisperElements", "Tokens: " + string.Join("|", tokens), LoggingEnums.VerbosityLevel.Low);

            for (int i = 0; i < tokens.Length; i++)
            {
                try
                {
                    var audioSourceList = new List<RawAudioPlaylistSource>();
                    MergeElement mergeElement;
                    short voxIndex;
                    string ttsInput;

                    string myToken = tokens[i].ToUpper().Trim();

                    switch (myToken)
                    {
                        // The + character indicates a space after each alpha character

                        // callq.INST - CallExtendedHC.Instruction
                        case "[1]":
                        case "[1+]":

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(_currentCallExtendedHC.Instruction, " ")
                                : GetFormattedTTS(_currentCallExtendedHC.Instruction);

                            if (ttsInput != string.Empty)
                            {
                                var t1 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t1 != null) audioSourceList.Add(t1);
                            }
                            break;

                        // callq.Priphone - Call.PrimaryPhoneNumber
                        case "[2]":
                        case "[2+]":

                            string phoneNumber = Regex.Replace(_currentCall.PrimaryPhoneNumber, "[^0-9]", ""); // format phone number to 10 digits NNNNNNNNNN
                            if (phoneNumber.Length > 10)
                                phoneNumber = phoneNumber.Substring(phoneNumber.Length - 10);

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(phoneNumber, " ")
                                : GetFormattedTTS(phoneNumber);

                            if (ttsInput != string.Empty)
                            {
                                var t2 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t2 != null) audioSourceList.Add(t2);
                            }
                            break;

                        // callq.NumElement - CallExtendedHC.NumElement
                        case "[3]":
                        case "[3+]":
                        case "[3.]":
                        case "[3,]":

                            if (myToken.Contains("+"))
                            {
                                ttsInput = GetFormattedTTS(_currentCallExtendedHC.NumElement, " ");
                            }
                            else if (myToken.Contains("."))
                            {
                                ttsInput = GetFormattedTTS(_currentCallExtendedHC.NumElement, ".");
                            }
                            else if (myToken.Contains(","))
                            {
                                ttsInput = GetFormattedTTS(_currentCallExtendedHC.NumElement, ",");
                            }
                            else
                            {
                                ttsInput = GetFormattedTTS(_currentCallExtendedHC.NumElement);
                            }

                            if (ttsInput != string.Empty)
                            {
                                var t3 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t3 != null) audioSourceList.Add(t3);
                            }
                            break;

                        // callq.Sponsor - CallExtendedHC.Sponsor -> this will be 0 callq.Sponsor is empty
                        case "[4]":
                        case "[4+]":

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(_currentCallExtendedHC.Sponsor.ToString(), " ")
                                : GetFormattedTTS(_currentCallExtendedHC.Sponsor.ToString());

                            if (ttsInput != string.Empty)
                            {
                                var t4 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t4 != null) audioSourceList.Add(t4);
                            }
                            break;

                        // callq.Refname - CallExtendedHC.ContactReference
                        case "[5]":
                        case "[5+]":

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(_currentCallExtendedHC.ContactReference, " ")
                                : GetFormattedTTS(_currentCallExtendedHC.ContactReference);

                            if (ttsInput != string.Empty)
                            {
                                var t5 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t5 != null) audioSourceList.Add(t5);
                            }
                            break;

                        // callq.CallerID - Call.CallerID
                        case "[6]":
                        case "[6+]":

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(_currentCall.CallerID, " ")
                                : GetFormattedTTS(_currentCall.CallerID);

                            if (ttsInput != string.Empty)
                            {
                                var t6 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t6 != null) audioSourceList.Add(t6);
                            }
                            break;

                        // callq.NameL - CallExtendedHC.LastName
                        case "[7]":
                        case "[7+]":

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(_currentCallExtendedHC.LastName, " ")
                                : GetFormattedTTS(_currentCallExtendedHC.LastName);

                            if (ttsInput != string.Empty)
                            {
                                var t7 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t7 != null) audioSourceList.Add(t7);
                            }
                            break;

                        // callq.NameF - CallExtendedHC.FirstName
                        case "[8]":
                        case "[8+]":

                            ttsInput = myToken.Contains("+")
                                ? GetFormattedTTS(_currentCallExtendedHC.FirstName, " ")
                                : GetFormattedTTS(_currentCallExtendedHC.FirstName);

                            if (ttsInput != string.Empty)
                            {
                                var t8 = GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, ttsInput);
                                if (t8 != null) audioSourceList.Add(t8);
                            }
                            break;

                        // Doctor Merge
                        case "[U]":

                            mergeElement = GetMergeElement(CallingEnums.MergeElementType.Doctor);
                            voxIndex = (short) mergeElement.MergeNumber;
                            var tU = GetRawAudioPlaylistSourceFile("U" + GetMergeVoxCharIndex(voxIndex) + "MSG", voiceNumber, voxIndex, voiceElementTypeName,
                                mergeElement.MergeProperName);
                            if (tU != null) audioSourceList.Add(tU);
                            break;

                        // Location Merge
                        case "[L]":

                            mergeElement = GetMergeElement(CallingEnums.MergeElementType.Location);
                            voxIndex = (short) mergeElement.MergeNumber;
                            var tL = GetRawAudioPlaylistSourceFile("L" + GetMergeVoxCharIndex(voxIndex) + "MSG", voiceNumber, voxIndex, voiceElementTypeName,
                                mergeElement.MergeProperName);
                            if (tL != null) audioSourceList.Add(tL);
                            break;

                        // Procedure Merge
                        case "[P]":

                            mergeElement = GetMergeElement(CallingEnums.MergeElementType.Procedure);
                            voxIndex = (short) mergeElement.MergeNumber;
                            var tP = GetRawAudioPlaylistSourceFile("P" + GetMergeVoxCharIndex(voxIndex) + "MSG", voiceNumber, voxIndex, voiceElementTypeName,
                                mergeElement.MergeProperName);
                            if (tP != null) audioSourceList.Add(tP);
                            break;

                        // Optional Note Merge
                        case "[O]":

                            var tO = GetOptionalNotesSources("O", voiceNumber, 1);
                            if (tO != null) audioSourceList.AddRange(tO);
                            break;

                        // Default Whisper Merge (msg2_12.vce)
                        case "[D]":

                            var tD = GetRawAudioPlaylistSourceFile("MSG", 2, 12, voiceElementTypeName, "");
                            if (tD != null) audioSourceList.Add(tD);
                            break;

                        default:

                            if (Regex.IsMatch(myToken, @"\[M([0-9]{2})\]$")) // [Mxx], where xx == 00 to 99
                            {
                                var tM = GetRawAudioPlaylistSourceFile("MSG", 2, Convert.ToInt16(myToken.Substring(2, 2)), voiceElementTypeName, "");
                                if (tM != null) audioSourceList.Add(tM);
                            }
                            else // TTS Element
                            {
                                // not formatting tts since this is manual input into cust param value
                                if (!string.IsNullOrWhiteSpace(myToken))
                                    audioSourceList.Add(GetRawAudioPlaylistSourceFile("TTS", 99, 99, voiceElementTypeName, myToken));
                            }
                            break;
                    }

                    if (audioSourceList.Count > 0)
                    {
                        if (element == null)
                        {
                            element = new RawAudioPlaylistElement
                            {
                                Category = AudioEnum.AudioPlaylistCategory.Whisper,
                                IsRequired = false,
                                SourceID = new List<Guid>()
                            };
                        }

                        foreach (var audioSource in audioSourceList)
                            element.SourceID.Add(audioSource.SourceID);
                    }
                }
                catch (Exception ex)
                {
                    throw new Exception("Error processing token: " + tokens[i] + " - " + ex);
                }
            }

            return element;
        }

        /// <summary>
        /// Format TTS string to the following specs:
        /// 1- add space to any digit
        /// </summary>
        /// <param name="input"></param>
        /// <param name="characterAppend">string to append after each non-digit character in <see cref="input"/> param</param>
        /// <returns></returns>
        private string GetFormattedTTS(string input, string characterAppend = "")
        {
            string output = string.Empty;

            input = input.Trim();

            foreach (char c in input)
            {
                output += c + characterAppend;
                if (char.IsDigit(c) && characterAppend == "")
                {
                    output += " ";
                }
            }

            return output;
        }

        private RawAudioPlaylistElement GetRawAudioPlaylistElement(AudioEnum.AudioPlaylistCategory category, short messageNumber,
            IEnumerable<MessageElement> messageElements, byte voiceNumber)
        {
            RawAudioPlaylistElement element = null;
            List<RawAudioPlaylistSource> audioSources = null;

            _ttsCount = 0;

            foreach (MessageElement msgElement in messageElements)
            {
                List<RawAudioPlaylistSource> audioSourcesToAdd = GetRawAudioPlaylistSourceFiles(msgElement.VoiceElement.VoiceFile.FileName
                    , voiceNumber
                    , msgElement.VoiceElement.VoxIndex
                    , msgElement.VoiceElement.VoiceElementType.TypeName
                    , msgElement.TTSText);

                if (audioSources == null)
                    audioSources = new List<RawAudioPlaylistSource>();

                if (audioSourcesToAdd != null && audioSourcesToAdd.Count > 0)
                {
                    foreach (RawAudioPlaylistSource source in audioSourcesToAdd)
                        audioSources.Add(source);
                }
            }

            if (audioSources != null && audioSources.Count > 0)
            {
                element = new RawAudioPlaylistElement
                {
                    Category = category,
                    IsRequired = true,
                    MessageNumber = messageNumber
                };

                foreach (RawAudioPlaylistSource audioSource in audioSources)
                {
                    if (element.SourceID == null)
                        element.SourceID = new List<Guid>();

                    element.SourceID.Add(audioSource.SourceID);
                }
            }

            return element;
        }

        private RawAudioPlaylistElement GetRawAudioPlaylistElementForIDOptions(HouseCallsCallData callData)
        {
            RawAudioPlaylistElement element = null;

            List<RawAudioPlaylistSource> audioSources = null;

            if (callData.PlayIDMessage)
            {
                foreach (HouseCallsCallDataElement hcDataElement in callData.HouseCallsCallDataElementList)
                {
                    VoiceElement voiceElement = hcDataElement.VoiceElement;

                    if ((callData.PlayIDGreeting && voiceElement.VoiceElementType.TypeName == "IDGreeting")
                        || (callData.PlayIDInstruction && voiceElement.VoiceElementType.TypeName == "IDInstruction")
                        || (callData.PlayIDInstruction && voiceElement.VoiceElementType.TypeName == "IDName"))
                    {
                        RawAudioPlaylistSource audioSource = GetRawAudioPlaylistSourceFile(voiceElement.VoiceFile.FileName
                            , callData.VoiceNumber
                            , voiceElement.VoxIndex
                            , voiceElement.VoiceElementType.TypeName
                            , string.Empty);
                        if (audioSources == null)
                            audioSources = new List<RawAudioPlaylistSource>();

                        if (audioSource != null)
                            audioSources.Add(audioSource);
                    }
                }
            }

            if (audioSources != null)
            {
                element = new RawAudioPlaylistElement();
                element.Category = AudioEnum.AudioPlaylistCategory.IDOptions;
                element.IsRequired = true;
                element.MessageNumber = callData.MessageNumber;

                foreach (RawAudioPlaylistSource audioSource in audioSources)
                {
                    if (element.SourceID == null)
                        element.SourceID = new List<Guid>();

                    element.SourceID.Add(audioSource.SourceID);
                }
            }

            return element;
        }

        private List<RawAudioPlaylistElement> GetRawAudioPlaylistElementForIDResponses(HouseCallsCallData callData)
        {
            List<RawAudioPlaylistElement> elements = null;

            if (callData.PlayIDMessage)
            {
                foreach (ActionKey actionKey in callData.ActionKeyList)
                {
                    List<RawAudioPlaylistSource> audioSources = null;

                    if (actionKey.ActionKeyCategoryEnum == CallingEnums.ActionKeyCategory.IDOption)
                    {
                        foreach (ActionKeyElement actionKeyElement in actionKey.ActionKeyElementList)
                        {
                            if (actionKeyElement.State > 0)
                            {
                                VoiceElement voiceElement = actionKeyElement.VoiceElement;

                                if (voiceElement == null)
                                    throw new Exception("Missing VoiceElement is required for ActionKeyElement!");

                                RawAudioPlaylistSource sourceFile = GetRawAudioPlaylistSourceFile(voiceElement.VoiceFile.FileName
                                    , callData.VoiceNumber
                                    , voiceElement.VoxIndex
                                    , voiceElement.VoiceElementType.TypeName
                                    , string.Empty);

                                if (audioSources == null)
                                    audioSources = new List<RawAudioPlaylistSource>();

                                if (sourceFile != null)
                                    audioSources.Add(sourceFile);
                            }
                        }
                    }

                    if (audioSources != null && audioSources.Count > 0)
                    {
                        var element = new RawAudioPlaylistElement
                        {
                            Category = AudioEnum.AudioPlaylistCategory.IDOptions,
                            IsRequired = true,
                            MessageNumber = callData.MessageNumber,
                            ResponseNumber = actionKey.TouchTone
                        };

                        foreach (RawAudioPlaylistSource audioSource in audioSources)
                        {
                            if (element.SourceID == null)
                                element.SourceID = new List<Guid>();

                            element.SourceID.Add(audioSource.SourceID);
                        }

                        if (elements == null)
                            elements = new List<RawAudioPlaylistElement>();

                        elements.Add(element);
                    }
                }
            }

            return elements;
        }

        private RawAudioPlaylistElement GetRawAudioPlaylistElementForResponseOptions(HouseCallsCallData callData)
        {
            RawAudioPlaylistElement element = null;

            List<RawAudioPlaylistSource> audioSources = null;

            if (callData.PlayResponseOptions)
            {
                foreach (ActionKey actionKey in callData.ActionKeyList)
                {
                    if (actionKey.ActionKeyCategoryEnum == CallingEnums.ActionKeyCategory.ResponseOption)
                    {
                        foreach (ActionKeyElement actionKeyElement in actionKey.ActionKeyElementList)
                        {
                            if (actionKeyElement.State == 0)
                            {
                                VoiceElement voiceElement = actionKeyElement.VoiceElement;

                                if (voiceElement == null)
                                    throw new Exception("Missing VoiceElement is required for ActionKeyElement!");

                                RawAudioPlaylistSource sourceFile = GetRawAudioPlaylistSourceFile(voiceElement.VoiceFile.FileName
                                    , callData.VoiceNumber
                                    , voiceElement.VoxIndex
                                    , voiceElement.VoiceElementType.TypeName
                                    , string.Empty);

                                if (audioSources == null)
                                    audioSources = new List<RawAudioPlaylistSource>();

                                if (sourceFile != null)
                                    audioSources.Add(sourceFile);
                            }
                        }
                    }
                }
            }

            if (audioSources != null && audioSources.Count > 0)
            {
                element = new RawAudioPlaylistElement
                {
                    Category = AudioEnum.AudioPlaylistCategory.ResponseOptions,
                    IsRequired = true,
                    MessageNumber = callData.MessageNumber
                };

                foreach (RawAudioPlaylistSource audioSource in audioSources)
                {
                    if (element.SourceID == null)
                        element.SourceID = new List<Guid>();

                    element.SourceID.Add(audioSource.SourceID);
                }
            }

            return element;
        }

        private List<RawAudioPlaylistElement> GetRawAudioPlaylistElementForResponses(HouseCallsCallData callData)
        {
            List<RawAudioPlaylistElement> elements = null;

            if (callData.PlayResponseOptions)
            {
                foreach (ActionKey actionKey in callData.ActionKeyList)
                {
                    List<RawAudioPlaylistSource> audioSources = null;

                    if (actionKey.ActionKeyCategoryEnum == CallingEnums.ActionKeyCategory.ResponseOption)
                    {
                        string previousType = string.Empty;

                        foreach (ActionKeyElement actionKeyElement in actionKey.ActionKeyElementList)
                        {
                            if (actionKeyElement.State > 0)
                            {
                                VoiceElement voiceElement = actionKeyElement.VoiceElement;

                                if (actionKeyElement.State == 1)
                                    previousType = voiceElement.VoiceElementType.TypeName;

                                if (voiceElement == null)
                                    throw new Exception("Missing VoiceElement is required for ActionKeyElement!");

                                // Optional different key voice elements 
                                if (callData.MessageTypeEnum != CallingEnums.MessageType.Validate)
                                {
                                    if (voiceElement.VoiceElementType.TypeName == "DifferentMessageKeyEnterPIN" ||
                                        voiceElement.VoiceElementType.TypeName == "DifferentMessageKeyIncorrectPIN" ||
                                        voiceElement.VoiceElementType.TypeName == "DifferentMessageKeyMaxIncorrectPIN")
                                        continue;
                                }

                                if (actionKeyElement.State > 1)
                                {
                                    if (previousType == "YesKeyEnding" && voiceElement.VoiceElementType.TypeName == "LocationMessage")
                                    {
                                        if (!_callParameter.CallParameterExtendedHC.IncludeLocationAdditionMessageToYesResponse)
                                            continue;
                                    }
                                    else if (previousType == "NoKeyEnding" && voiceElement.VoiceElementType.TypeName == "LocationMessage")
                                    {
                                        if (!_callParameter.CallParameterExtendedHC.IncludeLocationAdditionMessageToNoResponse)
                                            continue;
                                    }

                                    // Do not include Directions for Optional Message if param not selected
                                    if (previousType == "OptionalMessageKeyEnding" && voiceElement.VoiceElementType.TypeName == "LocationMessage")
                                    {
                                        if (!_callParameter.CallParameterExtendedHC.PlayOptionalMessageDirections)
                                            continue;
                                    }

                                    // Exclusion for Double Confirm Cancellation
                                    else if (voiceElement.VoiceElementType.TypeName == "NoKeyDoubleConfirm" && !_currentCall.ConfirmCancellation)
                                    {
                                        continue;
                                    }
                                }

                                RawAudioPlaylistSource sourceFile = GetRawAudioPlaylistSourceFile(voiceElement.VoiceFile.FileName
                                    , callData.VoiceNumber
                                    , voiceElement.VoxIndex
                                    , voiceElement.VoiceElementType.TypeName
                                    , string.Empty);

                                if (voiceElement.VoiceElementType.TypeName == "RecordKeyOptionalInstruction")
                                    ((RawAudioPlaylistRecordedSource) sourceFile).IsRequired = false;

                                // Set 'please wait' audio file prior to starting survey as optional
                                if (actionKey.ActionKeyTypeEnum == CallingEnums.ActionKeyType.StartSurvey)
                                {
                                    if (voiceElement.VoiceElementType.TypeName == "OtherElement" && voiceElement.VoiceFile.FileName == "BMSG" && voiceElement.VoxIndex == 2)
                                        ((RawAudioPlaylistRecordedSource) sourceFile).IsRequired = false;
                                }

                                if (audioSources == null)
                                    audioSources = new List<RawAudioPlaylistSource>();

                                if (sourceFile != null)
                                    audioSources.Add(sourceFile);
                            }
                        }
                    }

                    if (audioSources != null && audioSources.Count > 0)
                    {
                        var element = new RawAudioPlaylistElement
                        {
                            Category = AudioEnum.AudioPlaylistCategory.Response,
                            IsRequired = true,
                            MessageNumber = callData.MessageNumber,
                            ResponseNumber = actionKey.TouchTone
                        };

                        foreach (RawAudioPlaylistSource audioSource in audioSources)
                        {
                            if (element.SourceID == null)
                                element.SourceID = new List<Guid>();

                            element.SourceID.Add(audioSource.SourceID);
                        }

                        if (elements == null)
                            elements = new List<RawAudioPlaylistElement>();

                        elements.Add(element);
                    }
                }
            }

            return elements;
        }

        private RawAudioPlaylistSource GetRawAudioPlaylistSourceFile(string voiceFileName, byte voiceNumber, short voxIndex, string voiceElementTypeName, string ttsText)
        {
            RawAudioPlaylistSource audioSource;

            //string key = voiceFileName + "|" + voiceNumber + "|" + voxIndex + "|" + voiceElementTypeName + "|" + ttsText;
            string key = voiceFileName + "|" + voiceNumber + "|" + voxIndex + "|" + "|" + ttsText;

            // Check cache, if exists grab object out. else, continue and add to cache
            // exclude patient names, optional notes, location Message
            if (!voiceElementTypeName.ToUpper().StartsWith("PAT") && voiceElementTypeName != "OptionalNote" && voiceElementTypeName != "LocationMessage")
            {
                RawAudioPlaylistSource temp;
                _rawCache.TryGetValue(key, out temp);

                if (temp != null)
                    return temp;
            }
            // -------------------------------------

            // Text-To-Speech
            if (voiceFileName.ToUpper().StartsWith("HCS") || voiceFileName.ToUpper().StartsWith("TTS-NOTES") || voiceFileName.ToUpper() == "TTS")
            {
                audioSource = GetTTSSource(voiceFileName, ttsText);
            }
            // Normal Voice Files
            else
            {
                if (voiceFileName.ToUpper().StartsWith("PAT"))
                    voiceFileName = voiceFileName + "_" + _currentCallExtendedHC.FirstName.Trim() + "_" + _currentCallExtendedHC.LastName.Trim();

                audioSource = GetSourceFile(voiceFileName, voiceNumber, voxIndex);
            }

            // check if null
            if (audioSource == null)
                return null;

            // Add to collection
            audioSource = _rawAudioPlaylist.AddSource(audioSource);

            // Add to dictionary            
            // exclude patient names, optional notes, location Message
            if (!voiceElementTypeName.ToUpper().StartsWith("PAT") && voiceElementTypeName != "OptionalNote" && voiceElementTypeName != "LocationMessage")
            {
                _rawCache.Add(key, audioSource);
            }

            return audioSource;
        }

        private List<RawAudioPlaylistSource> GetRawAudioPlaylistSourceFiles(string voiceFileName, byte voiceNumber, short voxIndex, string voiceElementTypeName, string ttsText)
        {
            List<RawAudioPlaylistSource> audioSources = null;

            if (voiceFileName.ToUpper().StartsWith("OPT-NOTES"))
            {
                List<RawAudioPlaylistSource> tempSources = GetOptionalNotesSources(voiceFileName, voiceNumber, voxIndex);

                if (tempSources != null && tempSources.Count > 0)
                {
                    audioSources = new List<RawAudioPlaylistSource>();

                    foreach (RawAudioPlaylistSource source in tempSources)
                    {
                        audioSources.Add(_rawAudioPlaylist.AddSource(source));
                    }
                }
            }
            else
            {
                RawAudioPlaylistSource temp = GetRawAudioPlaylistSourceFile(voiceFileName, voiceNumber, voxIndex, voiceElementTypeName, ttsText);

                if (temp != null)
                {
                    audioSources = new List<RawAudioPlaylistSource>();
                    audioSources.Add(temp);
                }
            }

            return audioSources;
        }

        private RawAudioPlaylistTTSSource GetTTSSource(string voiceFileName, string ttsText)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            FireLoggingEvent(TransactionID, MessageID, CallID, method,
                string.Format("VoiceFileName: {0}, TTSText: {1}", voiceFileName, ttsText),
                LoggingEnums.VerbosityLevel.High);

            // no value so no tts output
            if (string.IsNullOrEmpty(ttsText))
                return null;

            var file = new RawAudioPlaylistTTSSource
            {
                AudioFileCategory = AudioEnum.AudioFileCategory.TTS,
                Rate = _callParameter.TTSRate,
                VoiceID = _callParameter.TTSVoiceNumber,
                Volume = _callParameter.TTSVolume
            };

            if (voiceFileName.ToUpper().StartsWith("HCS") || voiceFileName.ToUpper() == "TTS")
            {
                file.Text = ttsText;
            }
            else if (voiceFileName.ToUpper().StartsWith("TTS-NOTES"))
            {
                if (_callParameter.CallParameterExtendedHC.TTSNumberElement)
                    file.Text = ttsText.Substring(20, 50);
                else if (_callParameter.CallParameterExtendedHC.TTSInstruction)
                    file.Text = ttsText.Substring(0, 70);
                else if (_callParameter.CallParameterExtendedHC.TTSInstruction3Fields)
                {
                    _ttsCount += 1;

                    switch (_ttsCount)
                    {
                        case 1:
                            file.Text = ttsText.Substring(0, 10);
                            break;
                        case 2:
                            file.Text = ttsText.Substring(10, 30);
                            break;
                        case 3:
                            file.Text = ttsText.Substring(40, 30);
                            break;
                        default:
                            throw new Exception("Invalid TTSCount for TTSInstruction3Fields - TTSCount: " + _ttsCount);
                    }
                }
                else if (_callParameter.CallParameterExtendedHC.TTSGeorgiaPower)
                {
                    _ttsCount += 1;

                    switch (_ttsCount)
                    {
                        case 1:
                            file.Text = ttsText.Substring(0, 40);
                            break;
                        case 2:
                            file.Text = ttsText.Substring(40, 10);
                            break;
                        case 3:
                            file.Text = ttsText.Substring(50, 10);
                            break;
                        case 4:
                            file.Text = ttsText.Substring(60, 10);
                            break;
                        default:
                            throw new Exception("Invalid TTSCount for TTSInstruction3Fields - TTSCount: " + _ttsCount);
                    }
                }
                else
                {
                    // Should combine all INST for priphone (fam msg) adding 'and' before last item
                    // but Family merges are not supported at this time.
                    file.Text = ttsText;
                }
            }

            file.Text = file.Text.Trim();

            // no value so no tts output
            if (string.IsNullOrEmpty(file.Text))
                return null;

            return file;
        }

        private List<RawAudioPlaylistSource> GetOptionalNotesSources(string voiceFileName, byte voiceNumber, short voxIndex)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            List<RawAudioPlaylistSource> sourceFiles = null;

            FireLoggingEvent(TransactionID, MessageID, CallID, method,
                string.Format("VoiceFileName: {0}, VoiceNumber: {1}, VoxIndex: {2}", voiceFileName, voiceNumber, voxIndex),
                LoggingEnums.VerbosityLevel.High);

            List<string> optionalNotes = GetMergeTTSNames(CallingEnums.MergeElementType.OptionalNote);

            if (optionalNotes == null || optionalNotes.Count == 0)
                return null;

            foreach (string optNote in optionalNotes)
            {
                var sourceFile = new RawAudioPlaylistRecordedSource
                {
                    IsRequired = false,
                    AudioFileCategory = AudioEnum.AudioFileCategory.Customer,
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = optNote.Trim() + "_" + voiceNumber + "_" + voxIndex + DotVce,
                    Format = AudioFileFormat
                };

                var alternative = new RawAudioPlaylistRecordedAlternativeSource
                {
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = optNote.Trim() + "_" + voiceNumber + DotVox,
                    VoxIndex = voxIndex
                };

                sourceFile.AlternativeSources = new List<RawAudioPlaylistAlternativeSource>();
                sourceFile.AlternativeSources.Add(alternative);

                //// Spell Name
                //if (_callParameter.CallParameterExtendedHC.BypassSpellingOptionalNotes == false)
                //{
                //    List<string> fileNames = GetSpellNameFileNames(optNotes[i].Trim(), voiceNumber);

                //    for (int j = 0; j < fileNames.Count; j++)
                //    {
                //        //temp = new RawAudioPlaylistSourceFile();
                //        //temp.RootPath = CustomerRootPath;
                //        //temp.Directory = _customerNumber;
                //        //temp.FileName = fileNames[j];
                //        //temp.VoxIndex = voxIndex;

                //        //Guid id = _rawAudioPlaylist.AddSourceFile(CustomerRootPath, _customerNumber, fileNames[j], voxIndex, AudioEnum.AudioFormat.NMS_24,
                //        //                                          AudioEnum.AudioFileCategory.Customer, false);

                //        //if (temp.AlternateSourceFiles == null)
                //        //    temp.AlternateSourceFiles = new List<Guid>();

                //        //temp.AlternateSourceFiles.Add(id);
                //    }
                //}

                if (sourceFiles == null)
                    sourceFiles = new List<RawAudioPlaylistSource>();

                sourceFiles.Add(sourceFile);

                //_rawAudioPlaylist.AddSource(temp);
            }

            return sourceFiles;
        }

        private string GetMergeTTSName(CallingEnums.MergeElementType type)
        {
            foreach (MergeElement element in _currentMergeElementList)
            {
                if (element.MergeElementTypeEnum == type)
                {
                    return !string.IsNullOrEmpty(element.MergeProperName.Trim())
                        ? element.MergeProperName
                        : element.MergeName;
                }
            }

            return string.Empty;
        }

        private List<string> GetMergeTTSNames(CallingEnums.MergeElementType type)
        {
            var merges = new List<string>();

            foreach (MergeElement element in _currentMergeElementList)
            {
                if (element.MergeElementTypeEnum == type)
                {
                    if (type == CallingEnums.MergeElementType.OptionalNote)
                        merges.Add(element.MergeName);
                    else
                        merges.Add(!string.IsNullOrEmpty(element.MergeProperName.Trim())
                            ? element.MergeProperName
                            : element.MergeName);
                }
            }

            return merges;
        }

        private int GetMergeNumber(CallingEnums.MergeElementType type)
        {
            foreach (MergeElement element in _currentMergeElementList)
            {
                if (element.MergeElementTypeEnum == type)
                {
                    return element.MergeNumber;
                }
            }

            return -1;
        }

        private List<string> GetSpellNameFileNames(string name, byte voiceNumber)
        {
            const string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string oneToNine = "123456789";

            var result = new List<string>();

            name = name.ToUpper();

            for (int i = 0; i < name.Length; i++)
            {
                int voxIndex;
                string vceFile = null;

                if (alphabet.Contains(name[i].ToString()))
                {
                    voxIndex = alphabet.IndexOf(name[i]) + 1;
                    vceFile = "AMSG" + voiceNumber + "_" + voxIndex + DotVce;
                }
                else if (oneToNine.Contains(name[i].ToString()))
                {
                    voxIndex = oneToNine.IndexOf(name[i]) + 1;
                    vceFile = "NAMSG" + voiceNumber + "_" + voxIndex + DotVce;
                }
                else if (name[i] == 0)
                {
                    voxIndex = 10;
                    vceFile = "NCMSG" + voiceNumber + "_" + voxIndex + DotVce;
                }
                else // ignore character
                    voxIndex = 0;

                if (voxIndex > 0)
                    result.Add(vceFile);
            }

            return result;
        }

        private RawAudioPlaylistSource GetSourceFile(string voiceFileName, byte voiceNumber, short voxIndex)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            FireLoggingEvent(TransactionID, MessageID, CallID, method,
                string.Format("VoiceFileName: {0}, VoiceNumber: {1}, VoxIndex: {2}", voiceFileName, voiceNumber, voxIndex),
                LoggingEnums.VerbosityLevel.High);

            var sourceFile = new RawAudioPlaylistRecordedSource();

            //sourceFile.IsInitial = true;
            sourceFile.IsRequired = true;
            sourceFile.RootPath = CustomerRootPath;
            sourceFile.Directory = _customerNumber;
            sourceFile.Format = AudioFileFormat;
            sourceFile.AudioFileCategory = AudioEnum.AudioFileCategory.Customer;

            // Set FlagIfMissing for Doc, Loc, Proc
            if (Regex.Match(voiceFileName, "[ULP].(MSG)").Success)
            {
                sourceFile.NotifyIfMissing = true;
                sourceFile.NotifyReference = MissingRecordingCustomerNumberPrefix + _customerNumber + "|" + voiceFileName + voiceNumber + "|" + voxIndex;
            }

            if (voiceFileName.StartsWith("LOC"))
            {
                if (voiceFileName.Length == 3)
                    voiceFileName += GetMergeNumber(CallingEnums.MergeElementType.Location);

                sourceFile.IsRequired = false;
                sourceFile.FileName = voiceFileName + "_" + voiceNumber + "_" + voxIndex + DotVce;
            }
            else if (voiceFileName.StartsWith("DR"))
            {
                sourceFile.IsRequired = false;
                sourceFile.FileName = voiceFileName + "_" + 1 + DotVce; // SDR 4717395 - do not use voiceNumber variable; always voice 1.
            }
            else if (voiceFileName.Contains("OneMoment"))
            {
                sourceFile.IsRequired = false;
                sourceFile.FileName = voiceFileName + DotVce;
            }
            else
            {
                sourceFile.FileName = voiceFileName + voiceNumber + "_" + voxIndex + DotVce;
            }

            // Alternate Files
            var alternateSourceFiles = new List<RawAudioPlaylistAlternativeSource>();

            // Creating a source file if does not exist and adding id to list to add to alternateID for source at end of method
            if (voiceFileName.ToUpper().StartsWith("LIBNAMES"))
            {
                sourceFile.AudioFileCategory = AudioEnum.AudioFileCategory.FirstNameLibrary;

                var file = new RawAudioPlaylistRecordedAlternativeSource
                {
                    RootPath = FirstNameLibraryRootPath,
                    Directory = voiceFileName.Replace("LIBNAMES\\", ""),
                    FileName = voiceFileName.Replace("LIBNAMES\\", "") + "_" + voxIndex + DotVce,
                    VoxIndex = -1,
                    Format = AudioFileFormat
                };

                alternateSourceFiles.Add(file);
            }
            else if (voiceFileName.StartsWith("LOC"))
            {
                var file = new RawAudioPlaylistRecordedAlternativeSource
                {
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = voiceFileName + "_" + voiceNumber + DotVox,
                    VoxIndex = voxIndex,
                    Format = AudioFileFormat
                };

                alternateSourceFiles.Add(file);
            }
            else if (voiceFileName.StartsWith("DR"))
            {
                var file = new RawAudioPlaylistRecordedAlternativeSource
                {
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = voiceFileName + DotVox,
                    VoxIndex = voxIndex,
                    Format = AudioFileFormat
                };

                alternateSourceFiles.Add(file);
            }
            else
            {
                var file = new RawAudioPlaylistRecordedAlternativeSource
                {
                    RootPath = CustomerRootPath,
                    Directory = _customerNumber,
                    FileName = voiceFileName + voiceNumber + DotVox,
                    VoxIndex = voxIndex,
                    Format = AudioFileFormat
                };

                alternateSourceFiles.Add(file);
            }

            if ((voiceFileName.ToUpper().StartsWith("PAT_A_L\\"))
                || (voiceFileName.ToUpper().StartsWith("PAT_M_Z\\"))
                || (voiceFileName.ToUpper().StartsWith("LIBNAMES"))
                || (voiceFileName.ToUpper().StartsWith("LSTNAMES"))
                || (voiceFileName.ToUpper().StartsWith("U"))
                || (voiceFileName.ToUpper().StartsWith("DR"))
                || (voiceFileName.ToUpper().StartsWith("L"))
                || (voiceFileName.ToUpper().StartsWith("P")))
            {
                int genericVoxIndex = 1;

                switch (voiceFileName.ToUpper().Substring(0, 1))
                {
                    case "U":
                        genericVoxIndex = 3;
                        break;
                    case "L":
                        if ((voiceFileName.ToUpper().Substring(0, 3) != "LIB") && (voiceFileName.ToUpper().Substring(0, 3) != "LST"))
                        {
                            genericVoxIndex = 4;
                        }
                        break;
                    case "P":
                        if (voiceFileName.ToUpper().Substring(0, 3) != "PAT")
                        {
                            genericVoxIndex = 5;
                        }
                        break;
                }

                if (voiceFileName.ToUpper().StartsWith("LOC"))
                {
                    if (File.Exists(_appPath + "\\LocAddDefault.vce"))
                    {
                        var file = new RawAudioPlaylistRecordedAlternativeSource
                        {
                            RootPath = CustomerRootPath,
                            Directory = _customerNumber,
                            FileName = "LocAddDefault" + DotVce,
                            VoxIndex = -1,
                            Format = AudioFileFormat
                        };

                        alternateSourceFiles.Add(file);
                    }
                    else if (File.Exists(_appPath + "\\LocAddDefault_" + voiceNumber + DotVce))
                    {
                        var file = new RawAudioPlaylistRecordedAlternativeSource
                        {
                            RootPath = CustomerRootPath,
                            Directory = _customerNumber,
                            FileName = "LocAddDefault_" + voiceNumber + DotVce,
                            VoxIndex = -1,
                            Format = AudioFileFormat
                        };

                        alternateSourceFiles.Add(file);
                    }
                }
                else if (voiceFileName.ToUpper().StartsWith("DR"))
                {
                    if (File.Exists(_appPath + "\\DrAddDefault.vce"))
                    {
                        var file = new RawAudioPlaylistRecordedAlternativeSource
                        {
                            RootPath = CustomerRootPath,
                            Directory = _customerNumber,
                            FileName = "DrAddDefault" + DotVce,
                            VoxIndex = -1,
                            Format = AudioFileFormat
                        };

                        alternateSourceFiles.Add(file);
                    }
                    else if (File.Exists(_appPath + "\\DrAddDefault" + voiceNumber + DotVce))
                    {
                        var file = new RawAudioPlaylistRecordedAlternativeSource
                        {
                            RootPath = CustomerRootPath,
                            Directory = _customerNumber,
                            FileName = "DrAddDefault" + voiceNumber + DotVce,
                            VoxIndex = -1,
                            Format = AudioFileFormat
                        };

                        alternateSourceFiles.Add(file);
                    }
                    else if (File.Exists(_appPath + "\\LocAddDefault.vce"))
                    {
                        var file = new RawAudioPlaylistRecordedAlternativeSource
                        {
                            RootPath = CustomerRootPath,
                            Directory = _customerNumber,
                            FileName = "LocAddDefault" + DotVce,
                            VoxIndex = -1,
                            Format = AudioFileFormat
                        };

                        alternateSourceFiles.Add(file);
                    }
                    else if (File.Exists(_appPath + "\\LocAddDefault_" + voiceNumber + DotVce))
                    {
                        var file = new RawAudioPlaylistRecordedAlternativeSource
                        {
                            RootPath = CustomerRootPath,
                            Directory = _customerNumber,
                            FileName = "LocAddDefault_" + voiceNumber + DotVce,
                            VoxIndex = -1,
                            Format = AudioFileFormat
                        };

                        alternateSourceFiles.Add(file);
                    }
                }
                else
                {
                    if (_ttsNames)
                    {
                        if (_callParameter.CallParameterExtendedHC.TTSNamesOnly)
                        {
                            if (!((voiceFileName.ToUpper().StartsWith("PAT_A_L\\"))
                                  || (voiceFileName.ToUpper().StartsWith("PAT_M_Z\\"))
                                  || (voiceFileName.ToUpper().StartsWith("LIBNAMES"))
                                  || (voiceFileName.ToUpper().StartsWith("LSTNAMES"))))
                            {
                                _ttsNames = false;
                            }
                        }
                    }

                    if (_ttsNames)
                    {
                        string ttsText;

                        if (voiceFileName.ToUpper().StartsWith("PAT"))
                            ttsText = _currentCallExtendedHC.FirstName.Trim() + " " + _currentCallExtendedHC.LastName.Trim();
                        else if (voiceFileName.ToUpper().StartsWith("LIB"))
                            ttsText = _currentCallExtendedHC.FirstName.Trim();
                        else if (voiceFileName.ToUpper().StartsWith("LST"))
                            ttsText = _currentCallExtendedHC.LastName.Trim();
                        else if (voiceFileName.ToUpper().StartsWith("U"))
                            ttsText = GetMergeTTSName(CallingEnums.MergeElementType.Doctor);
                        else if (voiceFileName.ToUpper().StartsWith("L"))
                            ttsText = GetMergeTTSName(CallingEnums.MergeElementType.Location);
                        else if (voiceFileName.ToUpper().StartsWith("P"))
                            ttsText = GetMergeTTSName(CallingEnums.MergeElementType.Procedure);
                        else
                            ttsText = voiceFileName.Trim();

                        //CreateTTSFile(ttsText, out directory, out fileName);

                        var file = new RawAudioPlaylistTTSAlternativeSource
                        {
                            Text = ttsText.Trim(),
                            Rate = _callParameter.TTSRate,
                            VoiceID = _callParameter.TTSVoiceNumber,
                            Volume = _callParameter.TTSVolume
                        };

                        alternateSourceFiles.Add(file);

                        // Do not notify if TTSReprot.txt does not exist
                        if (!File.Exists(_appPath + "\\TTSReport.txt") && Regex.Match(voiceFileName, "[ULP].(MSG)").Success)
                            sourceFile.NotifyIfMissing = false;
                    }

                    // Generic VCE File
                    var genericVCEFile = new RawAudioPlaylistRecordedAlternativeSource
                    {
                        RootPath = CustomerRootPath,
                        Directory = _customerNumber,
                        FileName = "BMSG" + voiceNumber + "_" + genericVoxIndex + DotVce,
                        VoxIndex = -1,
                        Format = AudioFileFormat
                    };
                    alternateSourceFiles.Add(genericVCEFile);

                    // Generic VOX File
                    var genericVOXFile = new RawAudioPlaylistRecordedAlternativeSource
                    {
                        RootPath = CustomerRootPath,
                        Directory = _customerNumber,
                        FileName = "BMSG" + voiceNumber + DotVox,
                        VoxIndex = (short) genericVoxIndex,
                        Format = AudioFileFormat
                    };
                    alternateSourceFiles.Add(genericVOXFile);
                }
            }

            if (alternateSourceFiles.Count > 0)
                sourceFile.AlternativeSources = alternateSourceFiles;

            return sourceFile;
        }

        #endregion
    }

}

//private void CreateTTSFile(string ttsText, out string directory, out string filename)
//{
//    directory = _scheduleNumber.ToString();
//    filename = _callNumber + "_" + Guid.NewGuid().ToString() + DotVce;
//    string destinationFilePath = _ttsAudioStoragePath + "\\" + directory + "\\" + filename;

//    short ttsRate = _callParameter.TTSRate;
//    int ttsVoiceNumber = _callParameter.TTSVoiceNumber;
//    short ttsVolume = _callParameter.TTSVolume;
//    byte ttsVoiceID;

//    // Get TTS VoiceID
//    switch (ttsVoiceNumber)
//    {
//        case 2:
//            ttsVoiceID = 11;
//            break;
//        case 3:
//            ttsVoiceID = 10;
//            break;
//        default:
//            ttsVoiceID = 10;
//            break;
//    }

//    // Create TTS Element
//    var ttsElement = new TTSElement
//                         {
//                             Text = ttsText.Trim(),
//                             DestinationFolder = Path.GetDirectoryName(destinationFilePath) + "\\",
//                             DestinationFile = Path.GetFileName(destinationFilePath),
//                             Rate = ttsRate,
//                             Volume = ttsVolume,
//                             PriorityID = 1,
//                             StatusID = 1,
//                             VoiceID = ttsVoiceID
//                         };
//    ttsElement.CreateTTSElement();
//}