﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.ServiceModel;

namespace VXMLService.IntegrationTests
{
    [TestClass]
    public static class TestAssembly
    {
        public static ServiceHost ServiceHost_VXMLService;

        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext context)
        {
            var uri = new Uri("http://localhost:50462/");
            var basicBinding = new BasicHttpBinding();
            ServiceHost_VXMLService = new ServiceHost(typeof(TeleVox.VXML.Services.VXMLService));
            ServiceHost_VXMLService.AddServiceEndpoint(typeof(TeleVox.VXML.ServiceContracts.IVXMLService), basicBinding, $"{uri}VXMLService.svc");
            ServiceHost_VXMLService.AddServiceEndpoint(typeof(TeleVox.VXML.ServiceContracts.ICallPacingService), basicBinding, $"{uri}VXMLService.svc");
            ServiceHost_VXMLService.Open();
        }

        [AssemblyCleanup]
        public static void AssemblyCleanup()
        {
            ServiceHost_VXMLService?.Close();
        }
    }
}