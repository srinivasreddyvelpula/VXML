﻿namespace TeleVox.HouseCalls.Services
{

    public class Enums
    {

        public enum WhisperMergeType
        {

            Default,
            Location,
            Doctor,
            Procedure

        }

    }

}