﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Text;
using System.Xml;

namespace VXMLService.IntegrationTests.Helpers
{
    public static class StringExtensions
    {
        public static object DeserializeContractObject(this string xml, Type type)
        {
            var memoryStream = new MemoryStream(Encoding.Unicode.GetBytes(xml));
            using (var reader = XmlDictionaryReader.CreateTextReader(memoryStream, Encoding.Unicode, new XmlDictionaryReaderQuotas(), null))
            {
                DataContractSerializer dataContractSerializer = new DataContractSerializer(type);
                return dataContractSerializer.ReadObject(reader);
            }
        }
    }
}