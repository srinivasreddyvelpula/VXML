﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace VXMLService.IntegrationTests
{
    [TestClass]
    public class CallPacingServiceTests
    {
        [TestMethod]
        public void GetCallPacingGroup_DoesNotExist()
        {
            var groupName = $"TEST_{Guid.NewGuid()}";

            var client = new VXMLServiceReference.CallPacingServiceClient();
            var response = client.GetCallPacingGroup(groupName);

            Assert.AreEqual(-200, response.Response.ResponseCode);
            Assert.IsTrue(response.Response.ResponseMessage.Contains("No such pacing group"));
        }

        [TestMethod]
        public void GetCallPacingGroup_DoesExist()
        {
            var groupName = $"TEST_{Guid.NewGuid()}";

            var request = new VXMLServiceReference.CallPacingGroup
            {
                Application = VXMLServiceReference.CallPacingEnumApplication.HouseCalls,
                Name = groupName,
                Rate = 100,
                Type = VXMLServiceReference.CallPacingEnumType.CallsPerSecond
            };

            var client = new VXMLServiceReference.CallPacingServiceClient();
            client.SetCallPacingGroup(request);

            var response = client.GetCallPacingGroup(groupName);

            Assert.AreEqual(0, response.Response.ResponseCode);
            Assert.AreEqual("Success", response.Response.ResponseMessage);
        }

        [TestMethod]
        public void GetCallPacingStatus()
        {
            var groupName = $"TEST_{Guid.NewGuid()}";

            var client = new VXMLServiceReference.CallPacingServiceClient();
            var response = client.GetCallPacingStatus(groupName);

            Assert.AreEqual(0, response.Response.ResponseCode);
            Assert.AreEqual("Success", response.Response.ResponseMessage);
            Assert.AreEqual(VXMLServiceReference.CallPacingEnumApplication.HouseCalls, response.Status.Application);
            Assert.AreEqual(null, response.Status.StatusGroups[0].EstimatedCompletionDate);
            Assert.AreEqual(0, response.Status.StatusGroups[0].InFlight);
            Assert.AreEqual(0, response.Status.StatusGroups[0].InQueue);
            Assert.AreEqual(groupName, response.Status.StatusGroups[0].Name);
            Assert.AreEqual(null, response.Status.StatusGroups[0].Rate);
            Assert.AreEqual(null, response.Status.StatusGroups[0].Type);
        }

        [TestMethod]
        public void DeleteCallPacingGroup()
        {
            var request = new VXMLServiceReference.CallPacingGroup
            {
                Application = VXMLServiceReference.CallPacingEnumApplication.HouseCalls,
                Name = $"TEST_{Guid.NewGuid()}",
                Rate = 100,
                Type = VXMLServiceReference.CallPacingEnumType.CallsPerSecond
            };

            var client = new VXMLServiceReference.CallPacingServiceClient();
            client.SetCallPacingGroup(request);

            var deleteResponse = client.DeleteCallPacingGroup(request.Name);
            Assert.AreEqual(0, deleteResponse.ResponseCode);
            Assert.AreEqual("Success", deleteResponse.ResponseMessage);
        }

        [TestMethod]
        public void SetCallPacingGroup()
        {
            var request = new VXMLServiceReference.CallPacingGroup
            {
                Application = VXMLServiceReference.CallPacingEnumApplication.HouseCalls,
                Name = $"TEST_{Guid.NewGuid()}",
                Rate = 100,
                Type = VXMLServiceReference.CallPacingEnumType.CallsPerSecond
            };

            var client = new VXMLServiceReference.CallPacingServiceClient();
            var response = client.SetCallPacingGroup(request);

            Assert.AreEqual(0, response.ResponseCode);
            Assert.AreEqual("Success", response.ResponseMessage);

            var deleteResponse = client.DeleteCallPacingGroup(request.Name);
            Assert.AreEqual(0, deleteResponse.ResponseCode);
            Assert.AreEqual("Success", deleteResponse.ResponseMessage);
        }
    }
}