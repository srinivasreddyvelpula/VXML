﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("TeleVox.HouseCalls.Services.AudioPlayListService")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("TeleVox")]
[assembly: AssemblyProduct("TeleVox.HouseCalls.Services.AudioPlayListService")]
[assembly: AssemblyCopyright("Copyright © TeleVox 2012-2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("55b2b9a0-1668-4856-a079-894f1f34c3d6")]
[assembly: AssemblyVersion("4.0.0.0")]
[assembly: AssemblyFileVersion("4.0.0.31")]

/*
 * 4.0.0.0 : SKM : 08/10/2012 : Converted from 3.5 to 4.0. Removed dependency on HouseCalls.Business.dll.
 * 4.0.0.1 : SKM : 10/22/2012 : CustomerParams, TTSDefaults
 * 4.0.0.2 : SKM : 11/12/2012 : AudioPlaylist : Fix for voice number used for doctor message merges (SDR 4717395).
 *                                            : Set AudioFileCategory to FirstNameLibrary where appropriate to use correct destination file path
 *                              VXMLPlaylist  : Reset MessagePlayCount prior to playing different msg after validation
 * 4.0.0.3 : SKM : 01/24/2013 : AudioPlaylist : Fix for using actual answering machine voice instead of voice for original message (SDR 4873909).
 * 4.0.0.4 : SKM : 02/22/2013 : Added new configurations for CallTransferRingBack, DetectionMaxLiveDuration, DetectionMaxRestarts
 * 4.0.0.5 : SKM : 03/19/2013 : AudioPlayList : Restructure getting audio for Optional Notes since it's possible to have more than one per call (SDR 4978725).
 *                                              Use ProperName for TTS merge elements if text exists (SDR 5007862).
 *                              VXMLPlaylist  : Fix for handling no confirmation when used in conjunction with other endings such as additional location message (SDR 4985400).  
 * 4.0.0.6 : SKM : 07/01/2013 : AudioPlayList, VXMLPlaylist : Added functionality for Call Transfer with Whisper (SDR 4987554).
 * 4.0.0.7 : SKM : 09/11/2013 : Included CallStatusOverride param for DisconnectEvent.
 *                              Fixes for PaymentIVR data.
 * 4.0.0.8 : SKM : 11/04/2013 : SDR 5407426 - Fix for notifying on missing recording if generic message is used.
 *                            : SDR 5414164 - Added functionality for simulating a call.
 *                            : Added whisper transfer for Yes/No response options.
 * 4.0.0.9 : SKM : 11/18/2013 : Set new customer param for OutboundCallRequest.DispositionMode.
 *                              Evaluate for TransferMultipleKeys.txt where all unassigned keys are assigned the Transfer key, if transfer is assigned to a key (SDR 5502038).
 * 4.0.0.10 : SKM : 01/15/2014 : Set new ValidationStringMaxLeadingZeros property to 10 (SDR 5594336).
 * 4.0.0.11 : SKM : 02/05/2014 : Add functionality for new customer param HC_CallTransferWhisperMessage (SDR 5618282).
 * 4.0.0.12 : SKM : 04/17/2014 : Set Outdialer request expiration date to LocSpecificEndTime (if enabled for call) instead of ScheduleEndTime (SDR 5740106).
 *                               Support for Survey among other enhancements (SDR 5683945).
 * 4.0.0.13 : MSD : 09/12/2014 : Changing call transfer method to whisper when needing to send DTMF Digits
 * 4.0.0.14 : DCG : 09/12/2014 : Support for tracking IVR Transfer Type
 * 4.0.0.15 : MSD : 12/01/2014 : Added customer param to force VXML transfers to use whisper instead of bridge
 * 4.0.0.16 : SKM : 03/16/2015 : Added customer param to indicate start and length of substring (from callq.inst) to get payment amount for PaymentIVR transfer type (SDR 5713348).
 *                             : Added additional whisper message functionality to support spelling out TTS words as characters (SDR 6053982).
 * 4.0.0.17 : MDD : 2015-10-26 : Updated to log CallerID invalidity messages to TraceLog instead of ErrorLog (SDR.6701362)
 * 4.0.0.18 : SKM : 11/18/2015 : Updates to allow for sending initial vxml doc in outdialer request and to set proxy address from outdialer prefetcher (SDI.6845640).
 * 4.0.0.19 : SKM : 11/24/2015 : Allow for customer param override of ProxyAddressSiteDNS.
 * 4.0.0.20 : MDD : 2015-02-23 : Allow for customer param override of FetchTimeout and FetchAudioDelay, setting a fallback default of 3000 milliseconds (SDR.6906717)
 * 4.0.0.21 : SKM : 2017-01-09 : HouseCalls Inbound VXML (SDR.7360853)
 * 4.0.0.22 : SKM : 2017-05-25 : Modified TTS Rate matrix and added [3,] and [3.] delimiter option to TTS Text (SDR.8048303) * 
 * 4.0.0.23 : SKM : 2017-07-19 : SDR.8042044
 * 4.0.0.24 : SKM : 2017-10-25 : ECP-3409 HC_ENG SDR 8356737 Call Transfer Whisper Message Changes
 * 4.0.0.25 : SKM : 2019-11-11 : TVASP-3283 - Add configurable for data fetch timeout
 * 4.0.0.26 : SKM : 2020-02-01 : TVASP-2952/TVASP-3504 - Customer driven retention days for calling data / bug fix
 * 4.0.0.27 : RLP : 2021-07-30 : MTL-602 - Configure VXML documents to have Holly integrate with the publicly available VXMLWebAPI
 * 4.0.0.28 : RLP : 2021-08-04 : MTL-606 - Update the outbound call request to consume the public Outdialer endpoint
 * 4.0.0.29 : SKM : 2021-08-17 : Added support for azure audio
 * 4.0.0.30 : SKM : 2021-09-09 : MTL-789 - Added CallID to ErrorLog method so that entry in Logging.dbo.CallErrorLog will be added on exceptions
 * 4.0.0.31 : SKM : 2021-10-12 : Handle external endpoint having an existing query string before appending current query string value 
*/
