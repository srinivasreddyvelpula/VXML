﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using TeleVox.Common.Data;
using TeleVox.Core.Caching;
using TeleVox.Core.Configuration;
using TeleVox.Core.DataContracts;
using TeleVox.Core.Enums;
using TeleVox.HouseCalls.DataContracts;
using TeleVox.HouseCalls.Enums;
using TeleVox.PaymentIVR.DataContracts;
using TeleVox.PaymentIVR.Enums;
using TeleVox.PaymentIVR.UDDIFacades;
using TeleVox.VXML.Core;
using TeleVox.VXML.DataContracts.Calling;
using TeleVox.VXML.DataContracts.VoiceApplication;
using Action = TeleVox.VXML.DataContracts.VoiceApplication.Action;

namespace TeleVox.HouseCalls.Services
{

    /// <summary>
    /// 
    /// </summary>
    public class VXMLPlaylist : Base
    {
        #region Private Constants

        private const string ClassNameDot = "AudioPlayListService.VXMLPlaylist.";

        #endregion

        #region Private Variables

        private CertifiedAudioPlaylist _certifiedAudioPlaylist;
        private Call _currentCall;
        private HouseCallsCallRecord _currentCallRecord;
        private ScheduledCall _schedCall;

        private List<HCSurvey> _hcSurveys;

        private readonly CachingHelper _cachingHelper = new CachingHelper();
        private readonly string _squidCacheKey = "ServerListForSquidCache";

        #endregion

        #region Public Properties

        /// <summary>
        /// 
        /// </summary>
        public string AudioDestinationRootPathHTTP { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int CallTransferConnectTimeout { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool CallTransferForceWhisper { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int CallTransferMaxCallTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CallTransferRingBack { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CallTransferSonusSteeringDigits { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public VXMLEnum.WhisperAcceptType CallTransferWhisperAcceptType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DefaultCallerID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool DetectionAllowMachineDTMF { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DetectionContactType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool DetectionIncludeInitialHumanGreeting { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool DetectionIncludeInitialMachineGreeting { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int DetectionMaxLiveDuration { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int DetectionMaxRestarts { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string DetectionSourceURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PostbackCallStatusURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PostbackDispositionURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PostbackLeaveMessageURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PostbackOptOutURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PostbackSurveyURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public VXMLEnum.TTSEngineVoice TTSFemaleVoice { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public VXMLEnum.TTSEngineVoice TTSMaleVoice { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ConfirmInputInitialFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ConfirmInputFinalFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ConfirmResponseQueryString { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string CommonScriptQueryString { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RecordingPromptToBeginFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RecordingPromptPress1Filename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RecordingPromptPress2Filename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RecordingPromptPressPoundFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RecordingPromptPressStarFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string InvalidResponseFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string MaxRetriesFilename { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PaymentAmountSubstring { get; set; }

        public string DefaultProxyAddressPortInVxml { get; set; }

        public string ProxyAddressSiteDNS { get; set; }

        public List<string> ProxyAddressList { get; set; }

        public int FetchTimeout { get; set; } // FetchTimeout - SDR.6906717

        public int DataFetchTimeout { get; set; }

        public int FetchAudioDelay { get; set; } // FetchAudioDelay - SDR.6906717

        public int InboundPinLowerBound { get; set; }

        public bool InboundEnforceCustNumTFN { get; set; }

        public int CallRetentionDays { get; set; }

        public bool UseAzureStorage { get; set; }

        public bool UseVXMLWebAPI { get; set; }
        

        #endregion

        #region Public Methods

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public List<OutboundCallRequest> GetOutboundCallRequests(HCVXMLRequest request)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;

            _schedCall = request.SchedCall;
            _certifiedAudioPlaylist = request.CertifiedAudioPlaylist;
            _hcSurveys = request.HCSurveys;

            if (_schedCall == null)
                throw new Exception("ScheduledCall cannot be null.");
            if (_certifiedAudioPlaylist == null)
                throw new Exception("CertifiedAudioPlaylist cannot be null.");

            TransactionID = _schedCall.TransactionID;
            MessageID = _schedCall.MessageID;

            SetCustomerParamOverrides(request.HCCustomerParams);

            var response = new List<OutboundCallRequest>();

            foreach (Call call in _schedCall.CallList)
            {
                try
                {
                    CallID = call.CallIDGuid;

                    _currentCall = call;

                    string humanFormID = string.Empty;
                    string machineFormID = string.Empty;
                    string disconnectFormID = string.Empty;
                    string errorFormID = string.Empty;

                    var outboundCallRequest = new OutboundCallRequest
                    {
                        TransactionID = TransactionID,
                        MessageID = MessageID,
                        CallID = call.CallIDGuid,
                        PhoneNumber = GetFormattedPhoneNumber(call.PrimaryPhoneNumber),
                        CallerID = GetCallerID(call.CallerID),
                        CustomerID = _schedCall.CustomerID,
                        CustomerNumber = _schedCall.CustomerNumber,
                        Expiration = _schedCall.Schedule.ScheduleEnd,
                        PacingGroup = _schedCall.Schedule.PacingGroup,
                        DispositionPageURL = PostbackDispositionURL
                    };

                    outboundCallRequest.HCInbound = new OutboundCallRequest.HouseCallsInbound();

                    var sponsor = call.CallExtendedHC.Sponsor.ToString();
                    var numElement = call.CallExtendedHC.NumElement;

                    outboundCallRequest.HCInbound.NumElement = numElement;
                    outboundCallRequest.HCInbound.Sponsor = sponsor;
                    outboundCallRequest.HCInbound.ScheduleNumber = _schedCall.Schedule.ScheduleNumber;
                    outboundCallRequest.HCInbound.CallNumber = call.CallNumber;

                    outboundCallRequest.HCInbound.PIN = _schedCall.CallParameter.CallParameterExtendedHC.PinSponsor
                        ? sponsor
                        : numElement;

                    int messageToPlay = 10;
                    if (_schedCall.CallParameter.CallParameterExtendedHC.InboundKeepMsgByFirstElementNum)
                    {
                        messageToPlay = Convert.ToInt32(call.CallExtendedHC.Message.Substring(1, 2));
                    }
                    else if (_schedCall.CallParameter.CallParameterExtendedHC.InboundKeepMsg || call.CallExtendedHC.ProcedureNumber == 1)
                    {
                        messageToPlay = 1;
                    }
                    outboundCallRequest.HCInbound.MessageToPlay = messageToPlay;

                    // prevent inbound if pin is less that expected lower bound
                    if (Convert.ToInt64(outboundCallRequest.HCInbound.PIN) < InboundPinLowerBound)
                    {
                        outboundCallRequest.HCInbound = null;
                    }

                    // prevent inbound if customer param is enabled and CustomerID does not have valid TFN as customer number
                    if (InboundEnforceCustNumTFN)
                    {
                        var custNums = new CustomerNumber().GetCustNumsForCustomerID(_schedCall.CustomerID);
                        bool hasTFN = false;
                        foreach (var custNum in custNums)
                        {
                            if (custNum.All(char.IsDigit) && (custNum.Length == 10 || custNum.Length == 11))
                            {
                                hasTFN = true;
                                break;
                            }
                        }

                        if (!hasTFN)
                            outboundCallRequest.HCInbound = null;
                    }

                    if (call.UseCallSpecificWindow)
                    {
                        // use same date as ScheduleEnd but with CallEndTime as time
                        outboundCallRequest.Expiration = outboundCallRequest.Expiration.Date.Add(call.CallEndTime);

                        FireLoggingEvent(TransactionID, MessageID, CallID, method,
                            string.Format("UseCallSpecificWindow == true. Expiration for call modified from {0} to {1}.",
                                _schedCall.Schedule.ScheduleEnd, outboundCallRequest.Expiration),
                            LoggingEnums.VerbosityLevel.Medium);
                    }

                    outboundCallRequest.PurgeDate = DateTime.Today.AddDays(CallRetentionDays);

                    // set
                    SetCustomerParamOverrideForOutboundCallRequest(request.HCCustomerParams, ref outboundCallRequest);

                    // Creating HouseCalls Application
                    var vHouseCalls = new VoiceApplicationOutbound();
                    vHouseCalls.DefaultCallStatus = CallStatusType.AnswerHungUp;

                    // Disconnect Form   
                    vHouseCalls.DisconnectForm = new FormDisconnect {FormID = VXMLEntityName.DisconnectForm};
                    disconnectFormID = vHouseCalls.DisconnectForm.FormID;

                    // Error Form                    
                    vHouseCalls.ErrorForm = new FormError {FormID = VXMLEntityName.ErrorForm, DisconnectFormID = disconnectFormID};
                    errorFormID = vHouseCalls.ErrorForm.FormID;

                    // Human Messages
                    List<FormMessageHuman> humanForms = null;

                    // A linkcallq record can be added for the same message (i.e. Play Current Message as ID Response)
                    // Holding a collection of message numbers processed
                    var msgNumbers = new ArrayList();

                    foreach (HouseCallsCallRecord callRecord in call.CallExtendedHC.HouseCallsCallRecordList)
                    {
                        _currentCallRecord = callRecord;

                        short msgNo = callRecord.HouseCallsCallData.MessageNumber;
                        string msgDesc = callRecord.HouseCallsCallData.MessageDescription;

                        //bool grammarExists = false;

                        //foreach (ActionKey ak in callRecord.HouseCallsCallData.ActionKeyList)
                        //{
                        //    if (ak.Grammar != null && ak.Grammar != string.Empty)
                        //    {
                        //        grammarExists = true;
                        //        break;
                        //    }
                        //}

                        if (humanForms == null)
                            humanForms = new List<FormMessageHuman>();

                        if (!(msgNumbers.Contains(msgNo)))
                        {
                            // Add this message number to collection
                            msgNumbers.Add(msgNo);

                            // Exclude Answering Machine Message
                            if (callRecord.State == 0 || msgNo != GetAnsweringMachineMessageNumber(call))
                            {
                                if (callRecord.HouseCallsCallData.PlayIDMessage)
                                {
                                    // ID Options
                                    List<Interaction> idOptions = GetIDOptions(callRecord.HouseCallsCallData.ActionKeyList, msgNo);

                                    if (idOptions != null && idOptions.Count > 0)
                                    {
                                        List<Audio> idOptionAudio = GetAudio(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.IDOptions, msgNo);

                                        //httpPaths = GetAudioFilePathHTTP(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.IDOptions, msgNo);

                                        //if (httpPaths == null || httpPaths.Count == 0)
                                        //    throw new Exception(string.Format("Audio file for CallID:{0}, Category:{1}, MessageNumber:{2} not found.",
                                        //                                      call.CallIDGuid, AudioEnum.AudioPlaylistCategory.IDOptions, msgNo));

                                        //List<Audio> idOptionAudio = new List<Audio>();
                                        //foreach (string path in httpPaths)
                                        //    idOptionAudio.Add(new Audio {AudioSourceFilePath = path, BargeIn = true});

                                        // Add ID Form
                                        var newForm = new FormMessageHuman
                                        {
                                            FormID = VXMLFunctionLibrary.GetIDMessageName(msgNo),
                                            DisconnectFormID = disconnectFormID,
                                            AudioItems = idOptionAudio,
                                            MaxTimesToPlayMessage = _schedCall.CallParameter.LPPlayIDOptionsAttempts,
                                            ResponseTimeout = _schedCall.CallParameter.LPTouchToneTimeout*1000,
                                            Interactions = idOptions,
                                            MessageReference = FunctionLibrary.GetMessageReference(msgNo, msgDesc),
                                            DefaultCallStatus = CallStatusType.AnswerNoResponse,
                                            NoInputFormID = VXMLFunctionLibrary.GetHumanMessageName(msgNo),
                                            NoMatchFormID = VXMLFunctionLibrary.GetHumanMessageName(msgNo),
                                            TerminationCharacter = "#",
                                            TerminationTimeout = 500,
                                            PlayFirstAudioElementInAMD = DetectionIncludeInitialHumanGreeting
                                        };

                                        humanForms.Add(newForm);
                                    }
                                }

                                // Human Messages
                                var humanAudio = new List<Audio>();
                                var humanResponseOptionsAudio = new List<Audio>();

                                if (callRecord.State == 0)
                                {
                                    humanAudio.AddRange(GetAudio(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.Human, msgNo));

                                    //httpPaths = GetAudioFilePathHTTP(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.Human, msgNo);

                                    //if (httpPaths == null || httpPaths.Count == 0)
                                    //    throw new Exception(string.Format("Audio file for CallID:{0}, Category:{1}, MessageNumber:{2} not found.", call.CallIDGuid,
                                    //                                      AudioEnum.AudioPlaylistCategory.Human, msgNo));

                                    //foreach (string path in httpPaths)
                                    //{
                                    //    humanAudio.Add(new Audio { AudioSourceFilePath = path, BargeIn = true });
                                    //}
                                }
                                else
                                {
                                    humanAudio.AddRange(GetAudio(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.Message, msgNo));

                                    //httpPaths = GetAudioFilePathHTTP(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.Message, msgNo);

                                    //if (httpPaths == null || httpPaths.Count == 0)
                                    //    throw new Exception(string.Format("Audio file for CallID:{0}, Category:{1}, MessageNumber:{2} not found.", call.CallIDGuid,
                                    //                                      AudioEnum.AudioPlaylistCategory.Message, msgNo));

                                    //foreach (string path in httpPaths)
                                    //{
                                    //    humanAudio.Add(new Audio { AudioSourceFilePath = path, BargeIn = true });
                                    //}
                                }

                                // Response Options
                                List<Interaction> responseOptions = null;

                                if (callRecord.HouseCallsCallData.PlayResponseOptions)
                                {
                                    string validationString = null;
                                    if (callRecord.HouseCallsCallData.MessageTypeEnum == CallingEnums.MessageType.Validate)
                                        validationString = call.CallExtendedHC.Sponsor.ToString();

                                    responseOptions = GetResponseOptions(msgNo, callRecord.HouseCallsCallData.ActionKeyList, call.CallExtendedHC.ContactRecording,
                                        validationString);

                                    if (responseOptions != null && responseOptions.Count > 0)
                                    {
                                        // Response Option Instructions
                                        humanResponseOptionsAudio.AddRange(GetAudio(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.ResponseOptions, msgNo));

                                        //httpPaths = GetAudioFilePathHTTP(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.ResponseOptions, msgNo);
                                        ////httpPath = GetAudioFilePath(MessageEnums.AudioFileName.ResponseOptions);

                                        //if (httpPaths == null || httpPaths.Count == 0)
                                        //    throw new Exception(string.Format("Audio file for CallID:{0}, Category:{1}, ResponseOptions:{2} not found.",
                                        //                                      call.CallIDGuid, AudioEnum.AudioPlaylistCategory.ResponseOptions, msgNo));

                                        ////humanAudio.Add(httpPath);
                                        //foreach (string path in httpPaths)
                                        //{
                                        //    humanAudio.Add(new Audio { AudioSourceFilePath = path, BargeIn = true });
                                        //}

                                        //humanAudio.Add(new VXMLApplication.InteractiveActionAudioSpec(httpPath, true));
                                    }
                                }

                                // Human {Interactive or Static}
                                if (responseOptions != null && responseOptions.Count > 0)
                                {
                                    var newForm = new FormMessageHuman
                                    {
                                        FormID = VXMLFunctionLibrary.GetHumanMessageName(msgNo),
                                        DisconnectFormID = disconnectFormID,
                                        AudioItems = humanAudio,
                                        AudioItemsForUserPrompts = humanResponseOptionsAudio,
                                        MaxTimesToPlayMessage = _schedCall.CallParameter.LPPlayMessageAttempts,
                                        ResponseTimeout = _schedCall.CallParameter.LPTouchToneTimeout*1000,
                                        Interactions = responseOptions,
                                        MessageReference = FunctionLibrary.GetMessageReference(msgNo, msgDesc),
                                        DefaultCallStatus = CallStatusType.AnswerNoResponse,
                                        PlayFirstAudioElementInAMD = DetectionIncludeInitialHumanGreeting,
                                        TerminationCharacter = "#",
                                        TerminationTimeout = 500
                                    };

                                    humanForms.Add(newForm);
                                }
                                else
                                {
                                    var newForm = new FormMessageHuman
                                    {
                                        FormID = VXMLFunctionLibrary.GetHumanMessageName(msgNo),
                                        DisconnectFormID = disconnectFormID,
                                        AudioItems = humanAudio,
                                        MaxTimesToPlayMessage = _schedCall.CallParameter.LPPlayMessageAttempts,
                                        ResponseTimeout = _schedCall.CallParameter.LPTouchToneTimeout*1000,
                                        MessageReference = FunctionLibrary.GetMessageReference(msgNo, msgDesc),
                                        DefaultCallStatus = CallStatusType.AnswerNoTTRequested,
                                        OneSecondSilenceAudioFilePath = GetOneSecondSilenceAudioFilePath(),
                                        PlayFirstAudioElementInAMD = DetectionIncludeInitialHumanGreeting,
                                        TerminationCharacter = "#",
                                        TerminationTimeout = 500
                                    };

                                    humanForms.Add(newForm);
                                }
                            }
                        }
                    }

                    if (humanForms != null && humanForms.Count > 0)
                    {
                        humanFormID = humanForms[0].FormID;
                        vHouseCalls.HumanForms = humanForms;
                    }

                    // Answering Machine Message
                    foreach (HouseCallsCallRecord callRecord in call.CallExtendedHC.HouseCallsCallRecordList)
                    {
                        if (callRecord.State == 0)
                        {
                            var machineAudio = new List<Audio>();
                            short machineMsgNo = GetAnsweringMachineMessageNumber(call);

                            if (machineMsgNo == 0)
                                machineMsgNo = call.CallExtendedHC.HouseCallsCallRecordList[0].HouseCallsCallData.MessageNumber;

                            // Machine Message Description
                            string msgDesc = string.Empty;
                            foreach (HouseCallsCallRecord record in call.CallExtendedHC.HouseCallsCallRecordList)
                            {
                                if (record.HouseCallsCallData.MessageNumber == machineMsgNo)
                                    msgDesc = record.HouseCallsCallData.MessageDescription;
                            }

                            // Audio Files
                            machineAudio.AddRange(GetAudio(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.Machine, machineMsgNo));
                            //httpPaths = GetAudioFilePathHTTP(call.CallIDGuid, AudioEnum.AudioPlaylistCategory.Machine, machineMsgNo);

                            //if (httpPaths == null || httpPaths.Count == 0)
                            //    throw new Exception(string.Format("Audio file for CallID:{0}, Category:{1}, Machine:{2} not found.", call.CallIDGuid,
                            //                                      AudioEnum.AudioPlaylistCategory.Machine, machineMsgNo));

                            //foreach (string path in httpPaths)
                            //{
                            //    machineAudio.Add(new Audio { AudioSourceFilePath = path, BargeIn = true });
                            //}

                            // Create Form
                            vHouseCalls.MachineForm = new FormMessageMachine
                            {
                                FormID = VXMLFunctionLibrary.GetMachineMessageName(machineMsgNo),
                                AudioItems = machineAudio,
                                MaxTimesToPlayMessage = _schedCall.CallParameter.AMMessagePlays,
                                ResponseTimeout = _schedCall.CallParameter.AMWaitBetweenMessages*1000,
                                DisconnectFormID = disconnectFormID,
                                OneSecondSilenceAudioFilePath = GetOneSecondSilenceAudioFilePath(),
                                MessageReference = FunctionLibrary.GetMessageReference(machineMsgNo, msgDesc),
                                DefaultCallStatus = CallStatusType.AnswerMachine,
                                PlayFirstAudioElementInAMD = DetectionIncludeInitialMachineGreeting
                            };

                            machineFormID = vHouseCalls.MachineForm.FormID;

                            break;
                        }
                    }

                    // Property
                    vHouseCalls.Property = new Property
                    {
                        AudioFetchHint = W3CEnum.FetchType.Prefetch,
                        DocumentFetchHint = W3CEnum.FetchType.Prefetch,
                        ScriptFetchHint = W3CEnum.FetchType.Prefetch,
                        // SDR.6906717 - MDD - Making FetchTimeout and FetchAudioDelay configurable
                        FetchTimeout = FetchTimeout,
                        FetchAudioDelay = FetchAudioDelay,
                        TermTimeout = 500,
                        Universals = new List<W3CEnum.UniversalsType> {W3CEnum.UniversalsType.None},
                        TTSVoice = GetTTSVoice(_schedCall.CallParameter.TTSVoiceNumber)
                    };

                    // Detection Form
                    vHouseCalls.DetectionForm = new FormDetection
                    {
                        AllowMachineDTMF = false,
                        AMDSourceURL = DetectionSourceURL,
                        DisconnectFormID = disconnectFormID,
                        ErrorFormID = errorFormID,
                        FormID = VXMLEntityName.DetectionForm,
                        HumanFormID = humanFormID,
                        ContactType = VXMLEnum.ContactType.Residential,
                        MachineFormID = machineFormID,
                        MaxDuration = 300000,
                        MaxLiveDuration = DetectionMaxLiveDuration,
                        MaxRestarts = DetectionMaxRestarts,
                        PlayAnsweringMachineOnly = call.CallExtendedHC.HouseCallsCallRecordList[0].HouseCallsCallData.PlayAnsweringMessageOnly,
                        PlayAnsweringMachineOnlyCallStatus = CallStatusType.AnswerHungUp,
                        NoAnsweringMachine = _currentCall.NeverLeaveMessage || !_schedCall.CallParameter.AMLeaveMessage,
                        NoAnsweringMachineCallStatus = CallStatusType.AnswerMachineNoMsg
                    };

                    if (DetectionIncludeInitialHumanGreeting)
                    {
                        var temp = vHouseCalls.HumanForms[0].AudioItems[0] as AudioRecorded;
                        if (temp == null) // cannot pass tts to soundecision at this time
                            vHouseCalls.HumanForms[0].PlayFirstAudioElementInAMD = false;
                        else
                            vHouseCalls.DetectionForm.HumanGreetingAudioSource = temp.AudioSourceFilePath;
                    }

                    if (DetectionIncludeInitialMachineGreeting)
                    {
                        var temp = vHouseCalls.MachineForm.AudioItems[0] as AudioRecorded;
                        if (temp == null) // cannot pass tts to soundecision at this time
                            vHouseCalls.MachineForm.PlayFirstAudioElementInAMD = false;
                        else
                            vHouseCalls.DetectionForm.MachineGreetingAudioSource = temp.AudioSourceFilePath;
                    }

                    // Disconnect Event

                    // -- Variables to pass to callstatus
                    var postCallStatusURLNameList = new List<string>
                    {
                        VXMLVariable.CallID,
                        VXMLVariable.TransactionID,
                        VXMLVariable.CallStat,
                        VXMLVariable.HMSCallID,
                        VXMLVariable.IDConfirmed,
                        VXMLVariable.MessageReference,
                        VXMLVariable.CallTimerDuration,
                        VXMLVariable.CallTimerDetectionDuration,
                        VXMLVariable.SurveyTaken,
                        VXMLVariable.IVRTransferType,
                        VXMLVariable.IsInbound,
                        VXMLVariable.CallTimerStart,
                        VXMLVariable.CallTimerEnd
                    };

                    // -- Create form
                    vHouseCalls.DisconnectEvent = new EventDisconnect
                    {
                        PostCallStatusURL = PostbackCallStatusURL,
                        PostCallStatusURLNameList = postCallStatusURLNameList,
                        CallStatusOverride = "B",
                        FetchTimeout = DataFetchTimeout
                    };

                    // --------------------------------------------------------------------------------

                    // Error Event
                    vHouseCalls.ErrorEvent = new EventError {DisconnectFormID = disconnectFormID};

                    // Set Proxy Form
                    vHouseCalls.SetProxyAddressForm = new FormSetProxyAddress
                    {
                        FormID = VXMLEntityName.SetProxyAddressForm,
                        TransitionToFormID = vHouseCalls.DetectionForm.FormID,
                        ProxyAddressSiteDNS = ProxyAddressSiteDNS,
                        ProxyAddressList = ProxyAddressList
                    };

                    // Inbound Handler
                    if (outboundCallRequest.HCInbound != null)
                    {
                        vHouseCalls.InboundHandlerForm = new FormInboundHandler();
                        vHouseCalls.InboundHandlerForm.FormID = "inbound_handler";
                        vHouseCalls.InboundHandlerForm.MessageToPlayFormID = outboundCallRequest.HCInbound.MessageToPlay.ToString();
                    }

                    // Add HouseCalls Application
                    outboundCallRequest.ApplicationDetail = vHouseCalls;

                    // Check if this call is simulated and set SimulateCallStatusPostBackURL
                    if (outboundCallRequest.OutboundCallRequestParamOverride != null
                        &&
                        (outboundCallRequest.OutboundCallRequestParamOverride.SimulateCalling == 1 || outboundCallRequest.OutboundCallRequestParamOverride.SimulateCalling == 2))
                    {
                        outboundCallRequest.OutboundCallRequestParamOverride.SimulateCallStatusPostBackURL = PostbackCallStatusURL;
                        outboundCallRequest.OutboundCallRequestParamOverride.SimulateCallStatus = "Y";
                    }

                    // Check for Survey
                    if (_hcSurveys != null && _hcSurveys.Count > 0)
                    {
                        outboundCallRequest.Surveys = new List<VoiceApplicationSurvey>();

                        var languageDataHelper = new Language();

                        foreach (var survey in _hcSurveys)
                        {
                            string language = languageDataHelper.GetLanguageByID(survey.LanguageID);
                            string surveyPromptsPath;

                            if (UseAzureStorage)
                            {
                                surveyPromptsPath = Configuration.AudioDestinationRootPathAzure + @"/Survey/Elements/Prompts/" + language + "/";
                            }
                            else
                            {
                                surveyPromptsPath = Configuration.SurveyAudioURL + @"/Elements/Prompts/" + language + "/";
                            }

                            string azureSASTokenQueryString = string.Empty;
                            if (UseAzureStorage)
                            {
                                azureSASTokenQueryString = "?" + Configuration.AzureBlobSASToken;
                            }

                            var vAppSurvey = new VoiceApplicationSurvey();

                            vAppSurvey.Property = vHouseCalls.Property;

                            vAppSurvey.SurveyForm = new FormSurvey
                            {
                                SurveyName = survey.Name,
                                Survey = GetSurvey(survey),
                                FormID = VXMLFunctionLibrary.GetVXMLGuid(survey.SurveyID),
                                DisconnectFormID = disconnectFormID,
                                ErrorFormID = errorFormID,
                                ConfirmInputInitialAudioURI = surveyPromptsPath + ConfirmInputInitialFilename + azureSASTokenQueryString,
                                ConfirmInputFinalURI = surveyPromptsPath + ConfirmInputFinalFilename + azureSASTokenQueryString,
                                ConfirmInputSubdialogURI = UseVXMLWebAPI ? Configuration.ConfirmResponseURL_VXMLWebAPI : Configuration.VXMLWebsiteURL + "?" + ConfirmResponseQueryString,
                                SaveInputURI = PostbackSurveyURL,
                                CommonScriptURL = UseVXMLWebAPI ? Configuration.CommonURL_VXMLWebAPI : Configuration.VXMLWebsiteURL + "?" + CommonScriptQueryString,
                                RecordingPromptToBegin = surveyPromptsPath + RecordingPromptToBeginFilename + azureSASTokenQueryString,
                                RecordingPromptPress1 = surveyPromptsPath + RecordingPromptPress1Filename + azureSASTokenQueryString,
                                RecordingPromptPress2 = surveyPromptsPath + RecordingPromptPress2Filename + azureSASTokenQueryString,
                                RecordingPromptPressPound = surveyPromptsPath + RecordingPromptPressPoundFilename + azureSASTokenQueryString,
                                RecordingPromptPressStar = surveyPromptsPath + RecordingPromptPressStarFilename + azureSASTokenQueryString,
                                InvalidResponseAudioURI = surveyPromptsPath + InvalidResponseFilename + azureSASTokenQueryString,
                                MaxRetriesAudioURI = surveyPromptsPath + MaxRetriesFilename + azureSASTokenQueryString,
                                ResponseTimeout = _schedCall.CallParameter.LPTouchToneTimeout*1000
                            };

                            outboundCallRequest.Surveys.Add(vAppSurvey);
                        }
                    }

                    // Add Request to Batch
                    response.Add(outboundCallRequest);
                }
                catch (Exception ex)
                {                    
                    FireLoggingEvent(TransactionID, MessageID, CallID, method, ex, LoggingEnums.SeverityLevel.Recoverable, LoggingEnums.VerbosityLevel.Low);
                }
            }

            return response;
        }

        #endregion

        #region Private Methods

        private VXMLEnum.TTSEngineVoice GetTTSVoice(int hcTTSVoiceID)
        {
            if (hcTTSVoiceID == 2)
                return TTSMaleVoice;
            if (hcTTSVoiceID == 3)
                return TTSFemaleVoice;

            return TTSFemaleVoice;
        }

        private List<Audio> GetAudio(Guid requestID, AudioEnum.AudioPlaylistCategory category, int messageNumber, int responseNumber = -1)
        {
            var voiceAppAudio = new List<Audio>();

            foreach (CertifiedAudioPlaylistNotification request in _certifiedAudioPlaylist.Notifications)
            {
                if (request.NotificationID == requestID)
                {
                    foreach (CertifiedAudioPlaylistElement element in request.Elements)
                    {
                        if (element.Category == category && element.MessageNumber == messageNumber &&
                            (responseNumber == -1 || element.ResponseNumber == responseNumber))
                        {
                            if (element.SourceFileIDs != null && element.SourceFileIDs.Count > 0)
                            {
                                foreach (Guid sourceFileID in element.SourceFileIDs)
                                {
                                    CertifiedAudioPlaylistSourceFile sourceFile = _certifiedAudioPlaylist.GetCertifiedAudioPlaylistSourceFile(sourceFileID);

                                    if (sourceFile is CertifiedAudioPlaylistRecordedSourceFile)
                                    {
                                        var recorded = (CertifiedAudioPlaylistRecordedSourceFile) sourceFile;
                                        string path =
                                            recorded.FilePath.Replace(recorded.RootPath, AudioDestinationRootPathHTTP + "/" + recorded.AudioFileCategory).Replace(
                                                "\\", "/");

                                        path = Uri.EscapeUriString(path);

                                        if (UseAzureStorage)
                                        {
                                            path = path + "?" + Configuration.AzureBlobSASToken;
                                        }                                       

                                        voiceAppAudio.Add(new AudioRecorded {AudioSourceFilePath = path, BargeIn = true});
                                    }

                                    else if (sourceFile is CertifiedAudioPlaylistTTSSourceFile)
                                    {
                                        var tts = (CertifiedAudioPlaylistTTSSourceFile) sourceFile;

                                        var a = new AudioTTS();
                                        a.BargeIn = true;
                                        a.TTSText = tts.Text;
                                        a.TTSVolume = tts.Volume;

                                        // Voice
                                        a.TTSTalentName = GetTTSVoice(tts.VoiceID);

                                        // Rate
                                        if (tts.Rate <= -5)
                                            a.TTSRate = W3CEnum.TTSRate.ExtraSlow;
                                        else if (tts.Rate > -5 && tts.Rate < 0)
                                            a.TTSRate = W3CEnum.TTSRate.Slow;
                                        else if (tts.Rate >= 0 && tts.Rate < 5)
                                            a.TTSRate = W3CEnum.TTSRate.Medium;
                                        else if (tts.Rate >= 5 && tts.Rate < 9)
                                            a.TTSRate = W3CEnum.TTSRate.Fast;
                                        else if (tts.Rate >= 9)
                                            a.TTSRate = W3CEnum.TTSRate.ExtraFast;

                                        voiceAppAudio.Add(new AudioTTS
                                        {
                                            BargeIn = true,
                                            TTSRate = a.TTSRate,
                                            TTSTalentName = a.TTSTalentName,
                                            TTSText = a.TTSText,
                                            TTSVolume = a.TTSVolume
                                        });
                                    }
                                }
                            }

                            break;
                        }
                    }

                    break;
                }
            }

            return voiceAppAudio;
        }

        private string GetCallerID(string phoneNumber)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;
            string callerID;

            try
            {
                if (string.IsNullOrEmpty(phoneNumber))
                {
                    callerID = GetFormattedPhoneNumber(DefaultCallerID);
                }
                else
                {
                    callerID = GetFormattedPhoneNumber(phoneNumber);

                    if (callerID.Length != 10)
                    {
                        callerID = GetFormattedPhoneNumber(DefaultCallerID);

                        //SDR.6701362 - MDD - Updating to push CallerID errors to tracelog instead of error log.
                        FireLoggingEvent(TransactionID, MessageID, CallID, method,
                            string.Format(
                                "CallerID has invalid number of digits - Default CallerID will be used. Original: {0}, Default: {1}, CallID: {2}"
                                , phoneNumber, callerID, CallID),
                            LoggingEnums.VerbosityLevel.Medium);
                        /*FireLoggingEvent(TransactionID, MessageID, CallID, method,
                                         string.Format(
                                             "CallerID has invalid number of digits - Default CallerID will be used. Original: {0}, Default: {1}, CallID: {2}"
                                             , phoneNumber, callerID, CallID),
                                         string.Empty, LoggingEnums.SeverityLevel.Warning, LoggingEnums.VerbosityLevel.Medium);*/
                    }
                }
            }
            catch (Exception ex)
            {
                FireLoggingEvent(TransactionID, MessageID, CallID, method, ex, LoggingEnums.SeverityLevel.Warning, LoggingEnums.VerbosityLevel.Medium);
                callerID = GetFormattedPhoneNumber(DefaultCallerID);
            }

            return callerID;
        }

        private string GetFormattedPhoneNumber(string phoneNumber)
        {
            if (!string.IsNullOrEmpty(phoneNumber))
            {
                // Remove non-numeric characters
                phoneNumber = Regex.Replace(phoneNumber, @"[^\d]", "");

                // Remove leading 1
                if (phoneNumber.Length == 11 && phoneNumber.StartsWith("1"))
                    phoneNumber = phoneNumber.Remove(0, 1);
            }

            return phoneNumber;
        }

        private short GetMessageNumber(Call call)
        {
            return call.CallExtendedHC.HouseCallsCallRecordList[0].HouseCallsCallData.MessageNumber;
        }

        private short GetAnsweringMachineMessageNumber(Call call)
        {
            return call.CallExtendedHC.HouseCallsCallRecordList[0].HouseCallsCallData.AnsweringMachineMessageNumber;
        }

        /// <summary>
        /// Conversion of ActionKey to VXMLAppHCMessageResponseOption
        /// </summary>
        /// <param name="messageNumber"></param>
        /// <param name="item"></param>
        /// <param name="contactRecordingPath"></param>
        /// <param name="validationString"></param>
        /// <returns></returns>
        private List<Interaction> GetResponseOptions(int messageNumber, IEnumerable<ActionKey> item, string contactRecordingPath, string validationString)
        {
            var responseOptions = new List<Interaction>();

            bool hasTransfer = false;
            string touchTonesNotAssigned = "0123456789";

            foreach (ActionKey actionKey in item)
            {
                if (actionKey.ActionKeyCategoryEnum == CallingEnums.ActionKeyCategory.ResponseOption)
                {
                    var responseOption = new Interaction();
                    ActionPlayAudio playAudio = null;
                    ActionCallAPI callAPI = null;

                    // Assign Grammars
                    string[] words = actionKey.Grammar.Split('|');

                    if (words.Length > 0)
                    {
                        foreach (string word in words)
                        {
                            responseOption.GrammarWords.Add(word);
                        }
                    }

                    // Touch Tone to Enter Response Option
                    responseOption.TouchTone = actionKey.TouchTone.ToString();

                    touchTonesNotAssigned = touchTonesNotAssigned.Replace(responseOption.TouchTone, "");

                    // Get Audio File by TouchTone
                    //List<string> audioURIs = GetResponseAudioFilePathHTTP(CallID, AudioEnum.AudioPlaylistCategory.Response, messageNumber, actionKey.TouchTone);

                    List<Audio> audioList = GetAudio(CallID, AudioEnum.AudioPlaylistCategory.Response, messageNumber, actionKey.TouchTone);

                    //string audioFileName = null;
                    //if (audio != null && audio.Count > 0)
                    //    audioFileName = audio[0];

                    switch (actionKey.ActionKeyTypeEnum)
                    {
                        case CallingEnums.ActionKeyType.Confirm:

                            playAudio = GetPlayAudio(audioList);
                            if (playAudio != null)
                                responseOption.Actions.Add(playAudio);
                            else
                                throw new Exception("Required audio file for AnsweredYes does not exist");

                            responseOption.Response = CallStatusType.AnswerYes;
                            responseOption.DisconnectAfterActions = true;

                            // Perform Call Transfer
                            if (_schedCall.CallParameter.CallParameterExtendedHC.TransferAfterConfirmation)
                            {
                                var confirmTransfer = GetWhisperTransfer(audioList, _schedCall.CallParameter.CallParameterExtendedHC.TransferAfterConfirmationDNIS);
                                responseOption.Actions.Add(confirmTransfer);
                            }

                            break;

                        case CallingEnums.ActionKeyType.Cancel:

                            ActionConfirmResponse confirmResponse = null;

                            var modifiedAudio = new List<Audio>();

                            foreach (Audio toAdd in audioList)
                            {
                                if (toAdd is AudioRecorded)
                                {
                                    var recordedAudio = (AudioRecorded) toAdd;
                                    if (!recordedAudio.AudioSourceFilePath.Contains("_30"))
                                        modifiedAudio.Add(toAdd);
                                }
                                else
                                {
                                    modifiedAudio.Add(toAdd);
                                }
                            }
                            playAudio = GetPlayAudio(modifiedAudio);

                            if (_currentCall.ConfirmCancellation)
                            {
                                confirmResponse = new ActionConfirmResponse();
                                confirmResponse.TouchTone = Convert.ToByte(responseOption.TouchTone);
                                confirmResponse.AudioConfirmation = GetPlayAudio(modifiedAudio);

                                foreach (Audio toAdd in audioList)
                                {
                                    if (toAdd is AudioRecorded)
                                    {
                                        var recordedAudio = (AudioRecorded) toAdd;
                                        if (recordedAudio.AudioSourceFilePath.Contains("_30"))
                                        {
                                            confirmResponse.AudioPrompt = GetPlayAudio(toAdd);
                                            break;
                                        }
                                    }
                                }
                            }

                            if (playAudio != null)
                            {
                                if (confirmResponse != null)
                                {
                                    playAudio.ConfirmResponse = confirmResponse;
                                }
                                responseOption.Actions.Add(playAudio);
                            }
                            else
                                throw new Exception("Required audio file for AnsweredNo does not exist");

                            responseOption.Response = CallStatusType.AnswerNo;
                            responseOption.DisconnectAfterActions = true;

                            // Perform Call Tranfer
                            if (_schedCall.CallParameter.CallParameterExtendedHC.TransferAfterCancellation)
                            {
                                var confirmTransfer = GetWhisperTransfer(audioList, _schedCall.CallParameter.CallParameterExtendedHC.TransferAfterCancellationDNIS);
                                responseOption.Actions.Add(confirmTransfer);
                            }

                            break;

                        case CallingEnums.ActionKeyType.Repeat:
                            responseOption.Response = CallStatusType.AnswerRepeatedMsg;
                            responseOption.DisconnectAfterActions = false;
                            responseOption.Actions.Add(new ActionPlayMessage
                            {FormID = VXMLFunctionLibrary.GetHumanMessageName(messageNumber), ResetMessagePlayCount = false});
                            break;

                        case CallingEnums.ActionKeyType.Record:

                            // Record Params
                            var recordMsg = new ActionRecordMessage
                            {
                                MaxRecordTime = 300000,
                                PlayBeep = true,
                                FinalSilence = 5000,
                                DTMFTerm = true,
                                Actions = new List<Action>()
                            };

                            // Audio
                            playAudio = GetPlayAudio(audioList);
                            if (playAudio != null)
                                recordMsg.Actions.Add(playAudio);

                            // Call API
                            callAPI = new ActionCallAPI
                            {
                                URL = GetRecordAPI(contactRecordingPath),
                                NameList = GetRecordAPINameList(),
                                FetchTimeout = DataFetchTimeout
                            };

                            recordMsg.Actions.Add(callAPI);

                            responseOption.Actions.Add(recordMsg);

                            responseOption.Response = CallStatusType.AnswerLeftMsg;
                            //responseOption.DisconnectAfterActions = true; TODO: This may be configurable
                            break;

                        case CallingEnums.ActionKeyType.PlayOptionalMessage:

                            //if audioURIs.count == 1 then No Directions
                            //if audioURIs.count == 2 then Play Direction 1
                            //if audioURIs.count == 3 then prompt for PlayDirections -- 1=Direction1, 2=Direction2

                            responseOption.Response = CallStatusType.AnswerNoResponse;
                            responseOption.DisconnectAfterActions = _schedCall.CallParameter.CallParameterExtendedHC.DisconnectAfterOptionalMessage;

                            if (audioList.Count == 3)
                            {
                                var playDirections = new ActionPlayDirections
                                {
                                    InitialPrompt = GetPlayAudio(audioList[0]),
                                    Direction1 = GetPlayAudio(audioList[1]),
                                    Direction2 = GetPlayAudio(audioList[2]),
                                    DisconnectAfterDirectionsPlayed = responseOption.DisconnectAfterActions
                                };

                                responseOption.Actions.Add(playDirections);
                            }
                            else
                            {
                                playAudio = GetPlayAudio(audioList);
                                if (playAudio != null)
                                    responseOption.Actions.Add(playAudio);
                                else
                                    throw new Exception("Required audio file for OptionalMessageKeyEnding does not exist");
                            }

                            break;

                        case CallingEnums.ActionKeyType.PlayDifferentMessage:

                            responseOption.Response = CallStatusType.AnswerNoResponse;
                            responseOption.DisconnectAfterActions = false;

                            if (validationString != null)
                            {
                                if (audioList == null || audioList.Count == 0)
                                    throw new Exception("Required audio file for PlayDifferentMessage-Validate does not exist");

                                if (audioList[0] == null)
                                    throw new Exception("Required audio file for DifferentMessageKeyEnterPIN does not exist");

                                if (audioList[1] == null)
                                    throw new Exception("Required audio file for DifferentMessageKeyIncorrectPIN does not exist");

                                if (audioList[2] == null)
                                    throw new Exception("Required audio file for DifferentMessageKeyMaxIncorrectPIN does not exist");

                                var validate = new ActionValidate
                                {
                                    InitialPrompt = GetPlayAudio(audioList[0]),
                                    InvalidAttemptPrompt = GetPlayAudio(audioList[1]),
                                    MaxInvalidAttemptsPrompt = GetPlayAudio(audioList[2]),
                                    MaxInvalidAttempts = 3,
                                    ValidationString = validationString,
                                    ValidationStringMaxLeadingZeros = 10, // matches callq.Sponsor numeric field length
                                    OnSuccesFormID = VXMLFunctionLibrary.GetHumanMessageName(actionKey.MessageNumber)
                                };

                                responseOption.Actions.Add(validate);
                            }
                            else
                            {
                                if (actionKey.MessageNumber > 0)
                                {
                                    responseOption.Actions.Add(new ActionPlayMessage
                                    {
                                        FormID = VXMLFunctionLibrary.GetHumanMessageName(actionKey.MessageNumber),
                                        ResetMessagePlayCount = true
                                    });
                                }
                            }

                            break;

                        case CallingEnums.ActionKeyType.OptOut:

                            // Response Status
                            responseOption.Response = CallStatusType.AnswerOptOut;

                            // Disconnect
                            responseOption.DisconnectAfterActions = true;

                            // Audio
                            playAudio = GetPlayAudio(audioList);
                            if (playAudio != null)
                                responseOption.Actions.Add(playAudio);
                            else
                                throw new Exception("Required audio file for OptOutKeyEnding does not exist");

                            // Call API
                            callAPI = new ActionCallAPI
                            {
                                URL = PostbackOptOutURL,
                                NameList = GetOptOutAPINameList(),
                                FetchTimeout = DataFetchTimeout
                            };

                            responseOption.Actions.Add(callAPI);

                            break;

                        case CallingEnums.ActionKeyType.Transfer:

                            if (_currentCallRecord.HouseCallsCallData.PaymentIVREnabled && !_currentCallRecord.HouseCallsCallData.PaymentIVRScript.IsNullOrEmpty())
                            {
                                // PaymentIVR
                                var uddiFacade = new TeleVoxUDDIFacade();

                                // payment amount
                                string amountDueNative = _currentCall.CallExtendedHC.Instruction;
                                decimal amountDueTemp;
                                decimal amountDue;
                                int paymentAmountStart;
                                int paymentAmountEnd;

                                try
                                {
                                    var paymentAmountArray = PaymentAmountSubstring.Split('|');
                                    paymentAmountStart = Convert.ToInt32(paymentAmountArray[0]); // default is 0
                                    paymentAmountEnd = Convert.ToInt32(paymentAmountArray[1]); // default is 10
                                }
                                catch (Exception ex)
                                {
                                    paymentAmountStart = 0;
                                    paymentAmountEnd = 10;

                                    FireLoggingEvent(TransactionID, MessageID, CallID, "GetResponseOptions.Transfer.PaymentIVR",
                                        ex.Message + " - Resetting substring to default of 0,10", ex.StackTrace, LoggingEnums.SeverityLevel.Warning);
                                }

                                var amountDueSubstring = amountDueNative.Length >= (paymentAmountStart + paymentAmountEnd)
                                    ? amountDueNative.Substring(paymentAmountStart, paymentAmountEnd)
                                    : amountDueNative.Substring(paymentAmountStart);

                                if (Decimal.TryParse(amountDueSubstring, NumberStyles.Any, CultureInfo.CurrentCulture, out amountDueTemp))
                                    amountDue = amountDueTemp;
                                else
                                    throw new Exception("Transfer-PaymentIVR - Failed to set AmountDue : " + amountDueSubstring);

                                var sb = new StringBuilder();
                                sb.Append("AmoundDueNative: " + amountDueNative);
                                sb.Append("| StartIndex: " + paymentAmountStart);
                                sb.Append("| Length: " + paymentAmountEnd);
                                sb.Append("| AmountDueSubstring: " + amountDue);

                                FireLoggingEvent(TransactionID, MessageID, CallID, "GetResponseOptions.Transfer.PaymentIVR", sb.ToString(), LoggingEnums.VerbosityLevel.Low);

                                // format phone number to 10 digits NNNNNNNNNN
                                string phoneNumber = Regex.Replace(_currentCall.PrimaryPhoneNumber, "[^0-9]", "");
                                if (phoneNumber.Length > 10)
                                    phoneNumber = phoneNumber.Substring(phoneNumber.Length - 10);

                                // create payer
                                var payer = new HouseCallsPayer
                                {
                                    PatientNumber = _currentCall.CallExtendedHC.ContactNumber,
                                    Appointment = _currentCall.CallExtendedHC.AppointmentDateTime,
                                    ReferenceNumber = _schedCall.CustomerNumber,
                                    ScriptName = _currentCallRecord.HouseCallsCallData.PaymentIVRScript.Trim(),
                                    PayerFirstName = _currentCall.CallExtendedHC.FirstName,
                                    PayerMiddleInitial = _currentCall.CallExtendedHC.MiddleNameInitial,
                                    PayerLastName = _currentCall.CallExtendedHC.LastName,
                                    PayerPhoneNumber = phoneNumber,
                                    AmountDue = amountDue,
                                    DueDate = _currentCall.CallExtendedHC.SpecialDate
                                };

                                // add payer to database
                                long payerID = uddiFacade.AddPayer(payer, _currentCall.CallExtendedHC.ContactReference);

                                // add payer transaction
                                int transID = uddiFacade.CreateTransactionForPayer((int) payerID, EntitiesEnum.TransactionType.Payer, DateTime.Now);

                                // calculate dtmf digits
                                string dtmfString = transID.ToString() + FunctionLibrary.GetMod10Digit(transID.ToString()) + "#";

                                // get dial number
                                string hostIVRNumber = uddiFacade.GetHostIVRNumber(_schedCall.CustomerNumber);

                                // Create
                                var xferMsg = new ActionTransferCall
                                {
                                    CallerID = string.IsNullOrEmpty(_currentCall.TransferCallerID) ? DefaultCallerID : _currentCall.TransferCallerID,
                                    DTMFString = dtmfString,
                                    DelayBeforeDTMFString = 4,
                                    DialString = CallTransferSonusSteeringDigits + GetFormattedPhoneNumber(hostIVRNumber),
                                    MaxCallTime = CallTransferMaxCallTime,
                                    ConnectTimeout = CallTransferConnectTimeout,
                                    TransferType = W3CEnum.TransferType.Bridge,
                                    TransferAudio = CallTransferRingBack,
                                    IVRTransferType = 1
                                };
                                if (CallTransferForceWhisper)
                                {
                                    xferMsg.TransferType = W3CEnum.TransferType.Whisper;

                                    xferMsg.WhisperAcceptType = VXMLEnum.WhisperAcceptType.None;

                                    List<Audio> temp = GetAudio(_currentCall.CallIDGuid, AudioEnum.AudioPlaylistCategory.Whisper, 0);

                                    xferMsg.WhisperAudio = temp;
                                }

                                // Add
                                responseOption.Actions.Add(xferMsg);
                            }

                            else if (_schedCall.CallParameter.LPCallTransferType == 2) // Three-Way Calling
                            {
                                // Create
                                ActionTransferCall xferMsg = GetThreeWayTransferCall(audioList);

                                // Add
                                responseOption.Actions.Add(xferMsg);
                            }

                            else if (_schedCall.CallParameter.LPCallTransferType == 3) // Dial Extension
                            {
                                // Create
                                var xferMsg = new ActionTransferCall
                                {
                                    CallerID = string.IsNullOrEmpty(_currentCall.TransferCallerID) ? DefaultCallerID : _currentCall.TransferCallerID,
                                    DialString = CallTransferSonusSteeringDigits + GetFormattedPhoneNumber(_currentCall.TransferPhoneExtension),
                                    MaxCallTime = CallTransferMaxCallTime,
                                    ConnectTimeout = CallTransferConnectTimeout,
                                    TransferType = W3CEnum.TransferType.Bridge,
                                    TransferAudio = CallTransferRingBack,
                                    IVRTransferType = 2
                                };

                                // Add
                                responseOption.Actions.Add(xferMsg);
                            }

                            // Response Status
                            responseOption.Response = CallStatusType.AnswerCalledReceptionist;

                            // Disconnect
                            responseOption.DisconnectAfterActions = true;

                            hasTransfer = true;

                            break;

                        case CallingEnums.ActionKeyType.StartSurvey:

                            // Response Status
                            responseOption.Response = CallStatusType.AnswerNoResponse;

                            var survey = GetCurrentSurvey(new Guid(_currentCallRecord.HouseCallsCallData.SurveyID));

                            string surveyContactReference = _currentCall.CallExtendedHC.ContactReference.Trim();

                            string surveyFirstName = _schedCall.CallParameter.CallParameterExtendedHC.SurveyFirstNameIsReferenceNumber
                                ? surveyContactReference
                                : _currentCall.CallExtendedHC.FirstName.Trim();

                            long surveyTakerExternalSystemKey = _currentCall.CallExtendedHC.ContactNumber;
                            if (_schedCall.CallParameter.CallParameterExtendedHC.SurveyTakerIDIsReferenceName && surveyContactReference.Length < 10)
                            {
                                long.TryParse(surveyContactReference, out surveyTakerExternalSystemKey);
                            }

                            string surveyURL = Configuration.VXMLWebsiteURL + "?" + VXMLVariable.CallID + "=" + CallID + "&type=survey&instance=" +
                                               VXMLFunctionLibrary.GetVXMLGuid(survey.SurveyID);

                            responseOption.Actions.Add(new ActionStartSurvey
                            {
                                PlayAudioBeforeSurvey = GetPlayAudio(audioList),
                                ReplayPromptsAfterSurvey = _schedCall.CallParameter.CallParameterExtendedHC.SurveyContinueResponseOptions,
                                SourceURL = surveyURL,
                                SurveyID = survey.SurveyID,
                                SurveyAllowRetake = survey.AllowRetakes,
                                SurveyName = survey.Name,
                                SurveyReplaceExisting = survey.ReplaceExisting,
                                SurveyTakerCustomerID = _schedCall.CustomerID,
                                SurveyTakerPhone = _currentCall.PrimaryPhoneNumber.Trim(),
                                SurveyTakerName = surveyFirstName.Trim() + " " + _currentCall.CallExtendedHC.LastName.Trim(),
                                SurveyTakerExternalSystemKey = surveyTakerExternalSystemKey,
                                SurveyTakerPIN = 0 // not used
                            });

                            // Disconnect
                            responseOption.DisconnectAfterActions = true;

                            break;

                        default:
                            throw new Exception("Unsupported VXML Response Option: " + actionKey.ActionKeyTypeEnum);
                    }

                    responseOptions.Add(responseOption);
                }
            }

            // Assign unassigned tones to the transfer response option if customer param is set
            if (hasTransfer && _schedCall.CallParameter.CallParameterExtendedHC.TransferMultipleKeys)
            {
                foreach (var myResponseOption in responseOptions)
                {
                    foreach (var myAction in myResponseOption.Actions)
                    {
                        if (myAction is ActionTransferCall)
                        {
                            myResponseOption.TouchTone += touchTonesNotAssigned;
                        }
                    }
                }
            }

            return responseOptions;
        }

        private HCSurvey GetCurrentSurvey(Guid surveyID)
        {
            if (_hcSurveys != null && _hcSurveys.Count > 0)
            {
                foreach (var survey in _hcSurveys)
                {
                    if (survey.SurveyID == surveyID)
                        return survey;
                }
            }

            throw new Exception(string.Format("SurveyID [{0}] not in list of available surveys", surveyID));
        }

        /// <summary>
        /// Map HouseCalls survey to VXML survey
        /// </summary>
        /// <param name="hcSurvey"></param>
        /// <returns></returns>
        private ActionStartSurvey GetSurvey(HCSurvey hcSurvey)
        {
            var action = new ActionStartSurvey();

            if (hcSurvey.SurveyQuestions != null && hcSurvey.SurveyQuestions.Count > 0)
            {
                action.SurveyQuestions = new List<ActionStartSurvey.SurveyQuestion>();

                for (int i = 0; i < hcSurvey.SurveyQuestions.Count; i++)
                {
                    var sq = hcSurvey.SurveyQuestions[i];

                    var asq = new ActionStartSurvey.SurveyQuestion();
                    asq.SurveyQuestionID = sq.SurveyQuestionID;
                    asq.MyQuestion = new ActionStartSurvey.SurveyQuestion.Question
                    {
                        ConfirmInput = sq.Question.ConfirmInput,
                        InputType = sq.Question.InputType,
                        MaxDigit = sq.Question.MaxDigit,
                        MaxValue = sq.Question.MaxValue,
                        MinDigit = sq.Question.MinDigit,
                        MinValue = sq.Question.MinValue,
                        Name = sq.Question.Name,
                        QuestionID = sq.Question.QuestionID,
                        QuestionPrompt = GetAudio(sq.Question.QuestionID)
                    };

                    if (i < hcSurvey.SurveyQuestions.Count - 1)
                        asq.NextDefaultSurveyQuestionID = hcSurvey.SurveyQuestions[i + 1].SurveyQuestionID;

                    if (sq.SurveyQuestionBranches != null && sq.SurveyQuestionBranches.Count > 0)
                    {
                        asq.Branches = new List<ActionStartSurvey.SurveyQuestion.SurveyQuestionBranch>();

                        foreach (var b in sq.SurveyQuestionBranches.OrderBy(x => x.Priority))
                        {
                            var newBranch = new ActionStartSurvey.SurveyQuestion.SurveyQuestionBranch();
                            newBranch.Operator = b.Operator;
                            newBranch.QuestionID = b.BranchQuestionID;
                            newBranch.Value = b.Value;

                            asq.Branches.Add(newBranch);
                        }
                    }

                    action.SurveyQuestions.Add(asq);
                }
            }

            return action;
        }

        private List<Audio> GetAudio(Guid sourceFileID)
        {
            var voiceAppAudio = new List<Audio>();

            CertifiedAudioPlaylistSourceFile sourceFile = _certifiedAudioPlaylist.GetCertifiedAudioPlaylistSourceFile(sourceFileID);

            if (sourceFile is CertifiedAudioPlaylistRecordedSourceFile)
            {
                var recorded = (CertifiedAudioPlaylistRecordedSourceFile) sourceFile;
                string path =
                    recorded.FilePath.Replace(recorded.RootPath, AudioDestinationRootPathHTTP + "/" + recorded.AudioFileCategory).Replace("\\", "/");

                path = Uri.EscapeUriString(path);

                if (UseAzureStorage)
                {
                    path = path + "?" + Configuration.AzureBlobSASToken;
                }               

                voiceAppAudio.Add(new AudioRecorded {AudioSourceFilePath = path, BargeIn = true});
            }

            return voiceAppAudio;
        }

        /// <summary>
        /// Get Whisper Transfer for Yes/No response options.  
        /// Suppress if the transfer number begins with N or D.
        /// </summary>
        /// <param name="audioList"></param>
        /// <param name="transferPhoneNumber"></param>
        /// <returns></returns>
        private ActionTransferCall GetWhisperTransfer(List<Audio> audioList, string transferPhoneNumber)
        {
            var xferMsg = new ActionTransferCall
            {
                CallerID = string.IsNullOrEmpty(_currentCall.TransferCallerID) ? DefaultCallerID : _currentCall.TransferCallerID,
                DialString = CallTransferSonusSteeringDigits + GetFormattedPhoneNumber(transferPhoneNumber),
                MaxCallTime = CallTransferMaxCallTime,
                ConnectTimeout = CallTransferConnectTimeout,
                TransferType = (transferPhoneNumber.StartsWith("D") || transferPhoneNumber.StartsWith("N")) ? W3CEnum.TransferType.Bridge : W3CEnum.TransferType.Whisper,
                TransferAudio = CallTransferRingBack,
                IVRTransferType = 2
            };

            if (xferMsg.TransferType == W3CEnum.TransferType.Whisper)
            {
                xferMsg.WhisperAcceptType = CallTransferWhisperAcceptType;

                List<Audio> temp = GetAudio(_currentCall.CallIDGuid, AudioEnum.AudioPlaylistCategory.Whisper, 0);

                xferMsg.WhisperAudio = temp;
            }

            foreach (AudioRecorded recorded in audioList)
            {
                if (recorded.AudioSourceFilePath.EndsWith("_3.wav"))
                    xferMsg.PlayAudioNoResponse = GetPlayAudio(recorded);
                else if (recorded.AudioSourceFilePath.EndsWith("_2.wav"))
                {
                    if (_schedCall.CallParameter.CallParameterExtendedHC.TTSGeorgiaPower)
                        xferMsg.PlayAudioBeforeTransfer = GetPlayAudio(recorded);
                    else
                        xferMsg.PlayAudioDuringTransferAttempt = GetPlayAudio(recorded);
                }
                else if (recorded.AudioSourceFilePath.EndsWith("OneMoment.wav"))
                {
                    xferMsg.PlayAudioDuringTransferAttempt = GetPlayAudio(recorded);
                }
            }

            return xferMsg;
        }

        private ActionTransferCall GetThreeWayTransferCall(List<Audio> audioList)
        {
            // Create
            var xferMsg = new ActionTransferCall
            {
                CallerID = string.IsNullOrEmpty(_currentCall.TransferCallerID) ? DefaultCallerID : _currentCall.TransferCallerID,
                DTMFString = _currentCallRecord.HouseCallsCallData.CallTransferDTMFString,
                DelayBeforeDTMFString = _schedCall.CallParameter.CallParameterExtendedHC.TransferDTMFDelay,
                DialString = CallTransferSonusSteeringDigits + GetFormattedPhoneNumber(_currentCall.TransferPhoneNumber),
                MaxCallTime = CallTransferMaxCallTime,
                ConnectTimeout = CallTransferConnectTimeout,
                TransferType = _schedCall.CallParameter.CallParameterExtendedHC.TransferPlayPromptsToThirdParty ? W3CEnum.TransferType.Whisper : W3CEnum.TransferType.Bridge,
                TransferAudio = CallTransferRingBack,
                IVRTransferType = 2
            };

            if (CallTransferForceWhisper)
            {
                xferMsg.TransferType = W3CEnum.TransferType.Whisper;
            }

            if (xferMsg.TransferType == W3CEnum.TransferType.Whisper)
            {
                xferMsg.WhisperAcceptType = CallTransferWhisperAcceptType;

                List<Audio> temp = GetAudio(_currentCall.CallIDGuid, AudioEnum.AudioPlaylistCategory.Whisper, 0);

                xferMsg.WhisperAudio = temp;
            }

            foreach (AudioRecorded recorded in audioList)
            {
                if (recorded.AudioSourceFilePath.EndsWith("_3.wav"))
                    xferMsg.PlayAudioNoResponse = GetPlayAudio(recorded);
                else if (recorded.AudioSourceFilePath.EndsWith("_2.wav"))
                {
                    if (_schedCall.CallParameter.CallParameterExtendedHC.TTSGeorgiaPower)
                        xferMsg.PlayAudioBeforeTransfer = GetPlayAudio(recorded);
                    else
                        xferMsg.PlayAudioDuringTransferAttempt = GetPlayAudio(recorded);
                }
                else if (recorded.AudioSourceFilePath.EndsWith("OneMoment.wav"))
                {
                    xferMsg.PlayAudioDuringTransferAttempt = GetPlayAudio(recorded);
                }
            }

            return xferMsg;
        }

        private ActionPlayAudio GetPlayAudio(Audio audio)
        {
            ActionPlayAudio playAudio = null;

            if (audio != null)
            {
                playAudio = new ActionPlayAudio();
                playAudio.AudioSpecs = new List<Audio>();
                playAudio.AudioSpecs.Add(audio);
            }

            return playAudio;
        }

        private ActionPlayAudio GetPlayAudio(List<Audio> audioList)
        {
            ActionPlayAudio playAudio = null;

            if (!audioList.IsNullOrEmpty())
            {
                playAudio = new ActionPlayAudio {AudioSpecs = audioList};
            }

            return playAudio;
        }

        private string GetRecordAPI(string contactRecordingPath)
        {
            // External VXMLApplicationEndpoint will have authToken in query string
            if (PostbackLeaveMessageURL.Contains("?"))
            {
                PostbackLeaveMessageURL += "&";
            }
            else
            {
                PostbackLeaveMessageURL += "?";
            }

            var result = PostbackLeaveMessageURL;
            result += "transid=" + TransactionID + "&";
            result += "callid=" + CallID + "&";
            result += "custnum=" + _schedCall.Schedule.CustomerNumber + "&";
            result += "patnox=" + contactRecordingPath.Trim().Replace(@"\", "");

            return result;
        }

        private List<string> GetRecordAPINameList()
        {
            var apiNameList = new List<string>();
            apiNameList.Add(VXMLEntityName.RecordMessage);

            return apiNameList;
        }

        private List<string> GetOptOutAPINameList()
        {
            var apiNameList = new List<string>
            {
                VXMLVariable.TransactionID,
                VXMLVariable.CallID,
                VXMLVariable.CustomerNumber,
                VXMLVariable.PhoneNumber
            };

            return apiNameList;
        }

        #endregion

        private List<Interaction> GetIDOptions(List<ActionKey> item, short origMsgNumber)
        {
            var idOptions = new List<Interaction>();

            foreach (ActionKey actionKey in item)
            {
                if (actionKey.ActionKeyCategoryEnum == CallingEnums.ActionKeyCategory.IDOption)
                {
                    // Set ResponseOption Type
                    Interaction idOption;

                    switch (actionKey.ActionKeyTypeEnum)
                    {
                        case CallingEnums.ActionKeyType.ConfirmIdentity:
                        case CallingEnums.ActionKeyType.PlayCurrentMessage:
                        case CallingEnums.ActionKeyType.PlayDifferentMessage:
                        case CallingEnums.ActionKeyType.OptOut:
                        case CallingEnums.ActionKeyType.DeclineMessage:
                        case CallingEnums.ActionKeyType.RequestCallBack:
                        case CallingEnums.ActionKeyType.StartSurvey:
                            idOption = new Interaction();
                            break;
                        default:
                            throw new Exception("Unsupported Identification Option: " + actionKey.ActionKeyTypeEnum);
                    }

                    // Assign Grammars
                    string[] words = actionKey.Grammar.Split('|');

                    if (words.Length > 0)
                    {
                        foreach (string word in words)
                        {
                            idOption.GrammarWords.Add(word);
                        }
                    }

                    // Touch Tone to Enter Response Option
                    idOption.TouchTone = actionKey.TouchTone.ToString();

                    // Response Status, Audio, etc.
                    //VXMLApplication.InteractiveActionPlayAudio playAudio = null;
                    //VXMLApplication.InteractiveActionCallAPI callAPI = null;

                    var audioList = new List<Audio>();

                    switch (actionKey.ActionKeyTypeEnum)
                    {
                        case CallingEnums.ActionKeyType.ConfirmIdentity:

                            idOption.Actions.Add(new ActionConfirmIdentity {FormID = VXMLFunctionLibrary.GetHumanMessageName(origMsgNumber)});
                            idOption.DisconnectAfterActions = false;
                            break;

                        case CallingEnums.ActionKeyType.PlayCurrentMessage:

                            idOption.Actions.Add(new ActionPlayMessage
                            {FormID = VXMLFunctionLibrary.GetHumanMessageName(origMsgNumber), ResetMessagePlayCount = false});
                            idOption.DisconnectAfterActions = false;
                            break;

                        case CallingEnums.ActionKeyType.PlayDifferentMessage:

                            if (actionKey.MessageNumber > 0)
                                idOption.Actions.Add(new ActionPlayMessage
                                {FormID = VXMLFunctionLibrary.GetHumanMessageName(actionKey.MessageNumber), ResetMessagePlayCount = true});
                            idOption.DisconnectAfterActions = false;
                            break;

                        case CallingEnums.ActionKeyType.RequestCallBack:

                            idOption.Response = CallStatusType.AnswerRequestedCallBack;
                            //TODO; ADD Play ID-CallBack.vox [1] if exists                            
                            idOption.DisconnectAfterActions = true;

                            break;

                        case CallingEnums.ActionKeyType.DeclineMessage:

                            idOption.Response = CallStatusType.AnswerIDNotConfirmed;
                            //TODO; ADD Play ID-NotConf.vox [1] if exists                            
                            idOption.DisconnectAfterActions = true;

                            break;

                        case CallingEnums.ActionKeyType.OptOut:

                            // Response Status
                            idOption.Response = CallStatusType.AnswerOptOut;

                            // Disconnect
                            idOption.DisconnectAfterActions = true;

                            // Get Audio File by TouchTone
                            //List<string> audioURIs = GetResponseAudioFilePathHTTP(CallID, AudioEnum.AudioPlaylistCategory.IDOptions, origMsgNumber,
                            //                                                      actionKey.TouchTone);

                            audioList = GetAudio(CallID, AudioEnum.AudioPlaylistCategory.IDOptions, origMsgNumber, actionKey.TouchTone);

                            //string audioFileName = null;
                            //if (audio != null && audio.Count > 0)
                            //    audioFileName = audio[0];

                            ActionPlayAudio playAudio = GetPlayAudio(audioList);
                            if (playAudio != null)
                                idOption.Actions.Add(playAudio);
                            else
                                throw new Exception("Missing required audio file for OptOutKeyEnding");

                            // Call API
                            var callAPI = new ActionCallAPI {URL = PostbackOptOutURL, NameList = GetOptOutAPINameList(), FetchTimeout = DataFetchTimeout};
                            idOption.Actions.Add(callAPI);

                            break;

                        case CallingEnums.ActionKeyType.StartSurvey:

                            // Response Status
                            idOption.Response = CallStatusType.AnswerNoResponse;

                            audioList = GetAudio(CallID, AudioEnum.AudioPlaylistCategory.IDOptions, origMsgNumber, actionKey.TouchTone);

                            var survey = GetCurrentSurvey(new Guid(_currentCallRecord.HouseCallsCallData.SurveyID));

                            string surveyContactReference = _currentCall.CallExtendedHC.ContactReference.Trim();

                            string surveyFirstName = _schedCall.CallParameter.CallParameterExtendedHC.SurveyFirstNameIsReferenceNumber
                                ? surveyContactReference
                                : _currentCall.CallExtendedHC.FirstName.Trim();

                            long surveyTakerExternalSystemKey = _currentCall.CallExtendedHC.ContactNumber;
                            if (_schedCall.CallParameter.CallParameterExtendedHC.SurveyTakerIDIsReferenceName && surveyContactReference.Length < 10)
                            {
                                long.TryParse(surveyContactReference, out surveyTakerExternalSystemKey);
                            }

                            string surveyURL = Configuration.VXMLWebsiteURL + "?" + VXMLVariable.CallID + "=" + CallID + "&type=survey&instance=" +
                                               VXMLFunctionLibrary.GetVXMLGuid(survey.SurveyID);

                            idOption.Actions.Add(new ActionStartSurvey
                            {
                                PlayAudioBeforeSurvey = GetPlayAudio(audioList),
                                ReplayPromptsAfterSurvey = true,
                                SourceURL = surveyURL,
                                SurveyID = survey.SurveyID,
                                SurveyAllowRetake = survey.AllowRetakes,
                                SurveyName = survey.Name,
                                SurveyReplaceExisting = survey.ReplaceExisting,
                                SurveyTakerCustomerID = _schedCall.CustomerID,
                                SurveyTakerPhone = _currentCall.PrimaryPhoneNumber.Trim(),
                                SurveyTakerName = surveyFirstName.Trim() + " " + _currentCall.CallExtendedHC.LastName.Trim(),
                                SurveyTakerExternalSystemKey = surveyTakerExternalSystemKey,
                                SurveyTakerPIN = 0 // not used
                            });

                            // Disconnect

                            idOption.DisconnectAfterActions = false;

                            break;

                        default:
                            throw new Exception("Unsupported VXML Identification Option: " + actionKey.ActionKeyTypeEnum);
                    }

                    idOptions.Add(idOption);
                }
            }

            return idOptions;
        }

        private void SetCustomerParamOverrides(IList<HCCustomerParam> customerParams)
        {
            string audioDestinationRootPathHTTP = CustomerParam.GetParamValue(customerParams, CustomerParam.AudioDestinationRootPathHTTP);
            string callTransferConnectTimeout = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferConnectTimeout);
            string callTransferForceWhisper = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferForceWhisper);
            string callTransferMaxCallTime = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferMaxCallTime);
            string callTransferRingBack = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferRingBack);
            string callTransferSonusSteeringDigits = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferSonusSteeringDigits);
            string callTransferWhisperAcceptType = CustomerParam.GetParamValue(customerParams, CustomerParam.CallTransferWhisperAcceptType);
            string defaultCallerID = CustomerParam.GetParamValue(customerParams, CustomerParam.DefaultCallerID);
            string detectionAllowMachineDTMF = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionAllowMachineDTMF);
            string detectionContactType = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionContactType);
            string detectionIncludeInitialHumanGreeting = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionIncludeInitialHumanGreeting);
            string detectionIncludeInitialMachineGreeting = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionIncludeInitialMachineGreeting);
            string detectionMaxLiveDuration = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionMaxLiveDuration);
            string detectionMaxRestarts = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionMaxRestarts);
            string detectionSourceURL = CustomerParam.GetParamValue(customerParams, CustomerParam.DetectionSourceURL);
            string postbackCallStatusURL = CustomerParam.GetParamValue(customerParams, CustomerParam.PostbackCallStatusURL);
            string postbackDispositionURL = CustomerParam.GetParamValue(customerParams, CustomerParam.PostbackDispositionURL);
            string postbackLeaveMessageURL = CustomerParam.GetParamValue(customerParams, CustomerParam.PostbackLeaveMessageURL);
            string postbackOptOutURL = CustomerParam.GetParamValue(customerParams, CustomerParam.PostbackOptOutURL);
            string postbackSurveyURL = CustomerParam.GetParamValue(customerParams, CustomerParam.PostbackSurveyURL);
            string ttsFemaleVoice = CustomerParam.GetParamValue(customerParams, CustomerParam.TTSFemaleVoice);
            string ttsMaleVoice = CustomerParam.GetParamValue(customerParams, CustomerParam.TTSMaleVoice);
            string confirmInputInitialFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.ConfirmInputInitialFilename);
            string confirmInputFinalFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.ConfirmInputFinalFilename);
            string confirmResponseQueryString = CustomerParam.GetParamValue(customerParams, CustomerParam.ConfirmResponseQueryString);
            string commonScriptQueryString = CustomerParam.GetParamValue(customerParams, CustomerParam.CommonScriptQueryString);
            string recordingPromptToBeginFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.RecordingPromptToBeginFilename);
            string recordingPromptPress1Filename = CustomerParam.GetParamValue(customerParams, CustomerParam.RecordingPromptPress1Filename);
            string recordingPromptPress2Filename = CustomerParam.GetParamValue(customerParams, CustomerParam.RecordingPromptPress2Filename);
            string recordingPromptPressPoundFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.RecordingPromptPressPoundFilename);
            string recordingPromptPressStarFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.RecordingPromptPressStarFilename);
            string invalidResponseFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.InvalidResponseFilename);
            string maxRetriesFilename = CustomerParam.GetParamValue(customerParams, CustomerParam.MaxRetriesFilename);
            string paymentAmountSubstring = CustomerParam.GetParamValue(customerParams, CustomerParam.PaymentAmountSubstring);
            string defaultProxyAddressPortInVxml = CustomerParam.GetParamValue(customerParams, CustomerParam.DefaultProxyAddressPortInVxml);
            string proxyAddressSiteDNS = CustomerParam.GetParamValue(customerParams, CustomerParam.ProxyAddressSiteDNS);
            string fetchTimeout = CustomerParam.GetParamValue(customerParams, CustomerParam.FetchTimeout); // FetchTimeout - SDR.6906717
            string dataFetchTimeout = CustomerParam.GetParamValue(customerParams, CustomerParam.DataFetchTimeout);
            string fetchAudioDelay = CustomerParam.GetParamValue(customerParams, CustomerParam.FetchAudioDelay); // FetchAudioDelay - SDR.6906717
            string inboundPinLowerBound = CustomerParam.GetParamValue(customerParams, CustomerParam.InboundPinLowerBound);
            string inboundEnforceCustNumTFN = CustomerParam.GetParamValue(customerParams, CustomerParam.InboundEnforceCustNumTFN);
            string callRetentionDays = CustomerParam.GetParamValue(customerParams, CustomerParam.CallRetentionDays);

            if (!string.IsNullOrEmpty(audioDestinationRootPathHTTP))
            {
                AudioDestinationRootPathHTTP = audioDestinationRootPathHTTP;
            }

            if (!string.IsNullOrEmpty(callTransferConnectTimeout))
            {
                int temp;
                if (int.TryParse(callTransferConnectTimeout, out temp))
                    CallTransferConnectTimeout = temp;
            }

            if (!string.IsNullOrEmpty(callTransferForceWhisper))
            {
                try
                {
                    bool temp;
                    if (bool.TryParse(callTransferForceWhisper, out temp))
                        CallTransferForceWhisper = temp;
                    else
                        CallTransferForceWhisper = Convert.ToBoolean(callTransferForceWhisper);
                }
                catch (Exception ex)
                {
                    CallTransferForceWhisper = false;
                    FireLoggingEvent(TransactionID, MessageID, CallID, "SetCustomerParamOverrides",
                        string.Format("Invalid param value callTransferForceWhisper : {0} defaulting to False", callTransferForceWhisper),
                        ex.StackTrace, LoggingEnums.SeverityLevel.Warning);
                }
            }

            if (!string.IsNullOrEmpty(callTransferMaxCallTime))
            {
                int temp;
                if (int.TryParse(callTransferMaxCallTime, out temp))
                    CallTransferMaxCallTime = temp;
            }

            if (!string.IsNullOrEmpty(callTransferRingBack))
            {
                CallTransferRingBack = callTransferRingBack;
            }

            if (!string.IsNullOrEmpty(callTransferSonusSteeringDigits))
                CallTransferSonusSteeringDigits = callTransferSonusSteeringDigits;

            if (!string.IsNullOrEmpty(callTransferWhisperAcceptType))
            {
                VXMLEnum.WhisperAcceptType temp;
                if (Enum.TryParse(callTransferWhisperAcceptType, true, out temp))
                    CallTransferWhisperAcceptType = temp;
            }

            if (!string.IsNullOrEmpty(defaultCallerID))
            {
                DefaultCallerID = defaultCallerID;
            }

            if (!string.IsNullOrEmpty(detectionAllowMachineDTMF))
            {
                bool temp;
                if (bool.TryParse(detectionAllowMachineDTMF, out temp))
                    DetectionAllowMachineDTMF = temp;
                else
                    DetectionAllowMachineDTMF = Convert.ToBoolean(Convert.ToInt16(detectionAllowMachineDTMF));
            }

            if (!string.IsNullOrEmpty(detectionContactType))
            {
                DetectionContactType = detectionContactType;
            }

            if (!string.IsNullOrEmpty(detectionIncludeInitialHumanGreeting))
            {
                bool temp;
                if (bool.TryParse(detectionIncludeInitialHumanGreeting, out temp))
                    DetectionIncludeInitialHumanGreeting = temp;
                else
                    DetectionIncludeInitialHumanGreeting = Convert.ToBoolean(Convert.ToInt16(detectionIncludeInitialHumanGreeting));
            }

            if (!string.IsNullOrEmpty(detectionIncludeInitialMachineGreeting))
            {
                bool temp;
                if (bool.TryParse(detectionIncludeInitialMachineGreeting, out temp))
                    DetectionIncludeInitialMachineGreeting = temp;
                else
                    DetectionIncludeInitialMachineGreeting = Convert.ToBoolean(Convert.ToInt16(detectionIncludeInitialMachineGreeting));
            }

            if (!string.IsNullOrEmpty(detectionMaxLiveDuration))
            {
                int temp;
                if (int.TryParse(detectionMaxLiveDuration, out temp))
                    DetectionMaxLiveDuration = temp;
            }

            if (!string.IsNullOrEmpty(detectionMaxRestarts))
            {
                int temp;
                if (int.TryParse(detectionMaxRestarts, out temp))
                    DetectionMaxRestarts = temp;
            }

            if (!string.IsNullOrEmpty(detectionSourceURL))
            {
                DetectionSourceURL = detectionSourceURL;
            }

            if (!string.IsNullOrEmpty(postbackCallStatusURL))
            {
                PostbackCallStatusURL = postbackCallStatusURL;
            }

            if (!string.IsNullOrEmpty(postbackDispositionURL))
            {
                PostbackDispositionURL = postbackDispositionURL;
            }

            if (!string.IsNullOrEmpty(postbackLeaveMessageURL))
            {
                PostbackLeaveMessageURL = postbackLeaveMessageURL;
            }

            if (!string.IsNullOrEmpty(postbackOptOutURL))
            {
                PostbackOptOutURL = postbackOptOutURL;
            }

            if (!string.IsNullOrEmpty(postbackSurveyURL))
            {
                PostbackSurveyURL = postbackSurveyURL;
            }

            if (!string.IsNullOrEmpty(ttsFemaleVoice))
            {
                VXMLEnum.TTSEngineVoice temp;
                if (Enum.TryParse(ttsFemaleVoice, true, out temp))
                    TTSFemaleVoice = temp;
            }

            if (!string.IsNullOrEmpty(ttsMaleVoice))
            {
                VXMLEnum.TTSEngineVoice temp;
                if (Enum.TryParse(ttsMaleVoice, true, out temp))
                    TTSMaleVoice = temp;
            }

            // ConfirmInputInitialFilename
            if (!string.IsNullOrWhiteSpace(confirmInputInitialFilename))
                ConfirmInputInitialFilename = confirmInputInitialFilename;
            else
                throw new Exception("CustomerParamValue for [ConfirmInputInitialFilename] cannot be empty.");

            // ConfirmInputFinalFilename
            if (!string.IsNullOrWhiteSpace(confirmInputFinalFilename))
                ConfirmInputFinalFilename = confirmInputFinalFilename;
            else
                throw new Exception("CustomerParamValue for [ConfirmInputFinalFilename] cannot be empty.");

            // ConfirmResponseQueryString
            if (!string.IsNullOrWhiteSpace(confirmResponseQueryString))
                ConfirmResponseQueryString = confirmResponseQueryString;
            else
                throw new Exception("CustomerParamValue for [ConfirmResponseQueryString] cannot be empty.");

            // CommonScriptQueryString
            if (!string.IsNullOrWhiteSpace(commonScriptQueryString))
                CommonScriptQueryString = commonScriptQueryString;
            else
                throw new Exception("CustomerParamValue for [CommonScriptQueryString] cannot be empty.");

            // RecordingPromptToBeginFilename
            if (!string.IsNullOrWhiteSpace(recordingPromptToBeginFilename))
                RecordingPromptToBeginFilename = recordingPromptToBeginFilename;
            else
                throw new Exception("CustomerParamValue for [RecordingPromptToBeginFilename] cannot be empty.");

            // RecordingPromptPress1Filename
            if (!string.IsNullOrWhiteSpace(recordingPromptPress1Filename))
                RecordingPromptPress1Filename = recordingPromptPress1Filename;
            else
                throw new Exception("CustomerParamValue for [RecordingPromptPress1Filename] cannot be empty.");

            // RecordingPromptPress2Filename
            if (!string.IsNullOrWhiteSpace(recordingPromptPress2Filename))
                RecordingPromptPress2Filename = recordingPromptPress2Filename;
            else
                throw new Exception("CustomerParamValue for [RecordingPromptPress2Filename] cannot be empty.");

            // RecordingPromptPressPoundFilename
            if (!string.IsNullOrWhiteSpace(recordingPromptPressPoundFilename))
                RecordingPromptPressPoundFilename = recordingPromptPressPoundFilename;
            else
                throw new Exception("CustomerParamValue for [RecordingPromptPressPoundFilename] cannot be empty.");

            // RecordingPromptPressStarFilename
            if (!string.IsNullOrWhiteSpace(recordingPromptPressStarFilename))
                RecordingPromptPressStarFilename = recordingPromptPressStarFilename;
            else
                throw new Exception("CustomerParamValue for [RecordingPromptPressStarFilename] cannot be empty.");

            // InvalidResponseFilename
            if (!string.IsNullOrWhiteSpace(invalidResponseFilename))
                InvalidResponseFilename = invalidResponseFilename;
            else
                throw new Exception("CustomerParamValue for [InvalidResponseFilename] cannot be empty.");

            // MaxRetriesFilename
            if (!string.IsNullOrWhiteSpace(maxRetriesFilename))
                MaxRetriesFilename = maxRetriesFilename;
            else
                throw new Exception("CustomerParamValue for [MaxRetriesFilename] cannot be empty.");

            // PaymentAmountSubstring
            if (!string.IsNullOrEmpty(paymentAmountSubstring))
                PaymentAmountSubstring = paymentAmountSubstring;
            else
                throw new Exception("CustomerParamValue for [PaymentAmountSubstring] cannot be empty.");

            // DefaultProxyAddressPortInVxml
            if (!defaultProxyAddressPortInVxml.IsNullOrEmpty())
                DefaultProxyAddressPortInVxml = defaultProxyAddressPortInVxml;

            // DefaultProxyAddressPortInVxml
            if (!proxyAddressSiteDNS.IsNullOrEmpty())
                ProxyAddressSiteDNS = proxyAddressSiteDNS;

            // FetchTimeout - SDR.6906717
            if (!string.IsNullOrEmpty(fetchTimeout))
            {
                int temp;
                if (int.TryParse(fetchTimeout, out temp))
                    FetchTimeout = temp;
                else
                    FetchTimeout = 3000; //default timeout of 3 seconds
            }

            // DataFetchTimeout
            if (!string.IsNullOrEmpty(dataFetchTimeout))
            {
                DataFetchTimeout = int.TryParse(dataFetchTimeout, out var temp) ? temp : 3000;
            }

            // FetchAudioDelay - SDR.6906717 
            if (!string.IsNullOrEmpty(fetchAudioDelay))
            {
                int temp;
                if (int.TryParse(fetchAudioDelay, out temp))
                    FetchAudioDelay = temp;
                else
                    FetchAudioDelay = 3000; //default delay of 3 seconds
            }

            if (!string.IsNullOrEmpty(inboundPinLowerBound))
            {
                int temp;
                if (int.TryParse(inboundPinLowerBound, out temp))
                    InboundPinLowerBound = temp;
                else
                    InboundPinLowerBound = 0; // default lower bound of 0
            }

            if (!string.IsNullOrEmpty(inboundEnforceCustNumTFN))
            {
                bool temp;
                if (bool.TryParse(inboundEnforceCustNumTFN, out temp))
                    InboundEnforceCustNumTFN = temp;
                else
                    InboundEnforceCustNumTFN = true; // default to true
            }

            // Logic to handle Proxy Address list with ports
            var serverList = GetSquidCacheList();

            ProxyAddressList = new List<string>();

            foreach (var server in serverList)
            {
                string proxyToAdd = server.ServerIP;

                if (!proxyToAdd.Contains(":"))
                    proxyToAdd = proxyToAdd + ":" + defaultProxyAddressPortInVxml;

                ProxyAddressList.Add(proxyToAdd);
            }

            // CallRetentionDays
            if (!string.IsNullOrEmpty(callRetentionDays))
            {
                int temp;
                if (int.TryParse(callRetentionDays, out temp))
                    CallRetentionDays = temp;
                else
                    CallRetentionDays = 14; //default 14 days
            }

        }

        private void SetCustomerParamOverrideForOutboundCallRequest(IList<HCCustomerParam> customerParams, ref OutboundCallRequest request)
        {
            string outdialerAPN = CustomerParam.GetParamValue(customerParams, CustomerParam.OutdialerAPN);
            string outdialerPrefetchAudio = CustomerParam.GetParamValue(customerParams, CustomerParam.OutdialerPrefetchAudio);
            string outdialerPrefetchInitialPage = CustomerParam.GetParamValue(customerParams, CustomerParam.OutdialerPrefetchInitialPage);
            string simulateCalling = CustomerParam.GetParamValue(customerParams, CustomerParam.SimulateCalling);
            string dispositionMode = CustomerParam.GetParamValue(customerParams, CustomerParam.DispositionMode);
            string outdialerIncludeVxmlDocument = CustomerParam.GetParamValue(customerParams, CustomerParam.OutdialerIncludeVxmlDocumentInRequest);
            string setProxyAddressInVxml = CustomerParam.GetParamValue(customerParams, CustomerParam.SetProxyAddressInVxml);
            string proxyAddressSiteDNS = CustomerParam.GetParamValue(customerParams, CustomerParam.ProxyAddressSiteDNS);
            string suppressCallScheduleStatus = CustomerParam.GetParamValue(customerParams, CustomerParam.SuppressCallScheduleStatus);
            string suppressCallCallStatus = CustomerParam.GetParamValue(customerParams, CustomerParam.SuppressCallCallStatus);

            request.OutboundCallRequestParamOverride = new OutboundCallRequestParamOverride();

            if (!proxyAddressSiteDNS.IsNullOrEmpty())
                request.OutboundCallRequestParamOverride.ProxyAddressSiteDNS = proxyAddressSiteDNS;

            if (!outdialerAPN.IsNullOrEmpty())
                request.OutboundCallRequestParamOverride.OutdialerAPN = outdialerAPN;

            if (!outdialerPrefetchAudio.IsNullOrEmpty())
            {
                bool temp;
                if (bool.TryParse(outdialerPrefetchAudio, out temp))
                    request.OutboundCallRequestParamOverride.OutdialerPrefetchAudio = temp;
                else
                    request.OutboundCallRequestParamOverride.OutdialerPrefetchAudio = Convert.ToBoolean(Convert.ToInt16(outdialerPrefetchAudio));
            }

            if (!outdialerPrefetchInitialPage.IsNullOrEmpty())
            {
                bool temp;
                if (bool.TryParse(outdialerPrefetchInitialPage, out temp))
                    request.OutboundCallRequestParamOverride.OutdialerPrefetchInitialPage = temp;
                else
                    request.OutboundCallRequestParamOverride.OutdialerPrefetchInitialPage = Convert.ToBoolean(Convert.ToInt16(outdialerPrefetchInitialPage));
            }

            if (!simulateCalling.IsNullOrEmpty())
            {
                int temp;
                if (int.TryParse(simulateCalling, out temp))
                    request.OutboundCallRequestParamOverride.SimulateCalling = temp;
            }

            if (!outdialerIncludeVxmlDocument.IsNullOrEmpty())
            {
                bool temp;
                if (bool.TryParse(outdialerIncludeVxmlDocument, out temp))
                    request.OutboundCallRequestParamOverride.OutdialerIncludeVxmlDocument = temp;
                else
                    request.OutboundCallRequestParamOverride.OutdialerIncludeVxmlDocument = Convert.ToBoolean(Convert.ToInt16(outdialerIncludeVxmlDocument));
            }

            if (!setProxyAddressInVxml.IsNullOrEmpty())
            {
                bool temp;
                if (bool.TryParse(setProxyAddressInVxml, out temp))
                    request.OutboundCallRequestParamOverride.SetProxyAddressInVxml = temp;
                else
                    request.OutboundCallRequestParamOverride.SetProxyAddressInVxml = Convert.ToBoolean(Convert.ToInt16(setProxyAddressInVxml));
            }

            /* DispositionMode */

            if (dispositionMode.IsNullOrEmpty()) // default to MSMQ if not assigned
            {
                request.DispositionMode = VXMLEnum.DispositionMode.MSMQ;
            }
            else
            {
                try
                {
                    request.DispositionMode = (VXMLEnum.DispositionMode) Enum.Parse(typeof(VXMLEnum.DispositionMode), dispositionMode);
                }
                catch (Exception ex)
                {
                    request.DispositionMode = VXMLEnum.DispositionMode.MSMQ;

                    FireLoggingEvent(TransactionID, MessageID, "SetCustomerParamOverrideForOutboundCallRequest",
                        string.Format("Invalid CustomerParam for DispositionMode:[{0}]. Setting to MSMQ.", dispositionMode),
                        ex.StackTrace, LoggingEnums.SeverityLevel.Warning);
                }
            }

            /* Suppress Call */
            if (string.Equals(_schedCall.Schedule.Status, suppressCallScheduleStatus, StringComparison.CurrentCultureIgnoreCase))
            {
                request.OutboundCallRequestParamOverride.SuppressCall = true;
                request.OutboundCallRequestParamOverride.SuppressCallStatus = suppressCallCallStatus;
                request.OutboundCallRequestParamOverride.SuppressCallStatusPostBackURL = PostbackCallStatusURL;
            }
        }

        private List<Server> GetSquidCacheList()
        {
            List<Server> serverList = new List<Server>();

            string debugIntro = GetDebugIntro() + MethodBase.GetCurrentMethod().Name + " - ";

            if (_cachingHelper.Contains(_squidCacheKey))
            {
                Debug.WriteLine(debugIntro + "- Getting element from cache");

                serverList = (List<Server>) _cachingHelper.Get(_squidCacheKey);
            }

            if (serverList == null || !serverList.Any())
            {
                var server = new Server(true);
                serverList = server.GetServersByServerType("SquidCache");
                _cachingHelper.Add(_squidCacheKey, serverList, DateTime.Now.AddMinutes(5));
            }

            return serverList;
        }

        private string GetOneSecondSilenceAudioFilePath()
        {
            var path = AudioDestinationRootPathHTTP + "/" + "Prompts/silence_1sec.wav";

            if (UseAzureStorage)
            {
                path = path + "?" + Configuration.AzureBlobSASToken;
            }

            return path;
        }

        private string GetDebugIntro()
        {
            return "VxmlPlaylist - ";
        }

    }

}