﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using TeleVox.Core.Enums;
using TeleVox.Core.Plugins;
using TeleVox.VXML.Core;

namespace TeleVox.HouseCalls.Services
{

    internal class Configuration : WCFServiceConfig
    {
        #region Private Constants

        private const string ClassNameDot = "AudioPlayListService.Configuration.";

        #endregion

        #region Internal Static Properties

        #region Audio

        /// <summary>
        /// File extension to use for destination audio file.
        /// </summary>
        /// <example>WAV</example>
        internal static AudioEnum.AudioFileExtension AudioDestinationFileExtension { get; set; }

        /// <summary>
        /// File format to use for destination audio file.
        /// </summary>
        /// <example>ULAW</example>
        internal static AudioEnum.AudioFormat AudioDestinationFileFormat { get; set; }

        /// <summary>
        /// Root file path to store destination audio files.
        /// </summary>
        /// <example>\\den01tvcl401wav\wav\VXMLAudio\AudioFiles</example>
        internal static string AudioDestinationRootPath { get; set; }

        /// <summary>
        /// HTTP path to <see cref="AudioDestinationRootPath" />.
        /// </summary>
        /// <example>http://10.129.3.47:8085/VXMLAudio/AudioFiles</example>
        internal static string AudioDestinationRootPathHTTP { get; set; }

        /// <summary>
        /// HTTPs path to Azure audio file storage />.
        /// </summary>
        /// <example>https://tvxvoicedev.blob.core.windows.net/dev</example>
        internal static string AudioDestinationRootPathAzure { get; set; }

        /// <summary> 
        /// Root file path where customer specific audio files will reside.
        /// </summary>
        /// <example>\\den01tvcl401wav\WAV\VXMLAudio\AudioFiles\Customer</example>
        internal static string AudioDestinationCustomerRootPath { get; set; }

        /// <summary>
        /// Root file path where library of first name audio files will reside.
        /// </summary>
        /// <example>\\den01tvcl401wav\WAV\VXMLAudio\AudioFiles\FirstNameLibrary</example>
        internal static string AudioDestinationFirstNameLibraryRootPath { get; set; }

        /// <summary>
        /// Root file path where common audio files will reside.
        /// </summary>
        /// <example>\\den01tvcl401wav\WAV\VXMLAudio\AudioFiles\Prompts</example>
        internal static string AudioDestinationPromptsRootPath { get; set; }

        /// <summary>
        /// Root file path where survey audio files will reside.
        /// </summary>
        /// <example>\\den01tvcl401wav\WAV\VXMLAudio\AudioFiles\Survey</example>
        internal static string AudioDestinationSurveyRootPath { get; set; }

        /// <summary>
        /// Root file path where customer specific audio files reside.
        /// </summary>
        /// <remarks>HouseCalls audio file recordings are stored in HCASP customer folder.</remarks>
        /// <example>\\filecluster\hcaspcust$\hcasp</example>
        internal static string AudioSourceCustomerRootPath { get; set; }

        /// <summary>
        /// File format audio recordings are stored in under <see cref="AudioSourceCustomerRootPath"/>.
        /// </summary>
        /// <example>VCE</example>
        internal static AudioEnum.AudioFormat AudioSourceFileFormat { get; set; }

        /// <summary>
        /// Root file path where library of first name audio files reside in native format. 
        /// </summary>
        /// <example>\\den01tvcl401wav\VCE\FirstNameLibrary</example>
        internal static string AudioSourceFirstNameLibraryRootPath { get; set; }

        /// <summary>
        /// Root file path where prompts reside in native format. 
        /// </summary>
        /// <example>\\den01tvcl401wav\VCE\Prompts</example>
        internal static string AudioSourcePromptsRootPath { get; set; }

        /// <summary>
        /// SAS token to Azure blob storage
        /// </summary>
        /// <example></example>
        internal static string AzureBlobSASToken { get; set; }

        /// <summary>
        /// The audio storage account container name
        /// </summary>
        /// <example>dev</example>
        internal static string AzureAudioContainerName { get; set; }

        #endregion

        #region Call Transfer

        /// <summary>
        /// Duration (seconds) to attempt to connect the call transfer before disconnecting.
        /// </summary>
        /// <example>30</example>
        internal static int CallTransferConnectTimeout { get; set; }

        /// <summary>
        /// Duration (minutes) of call transfer before forcing a disconnect.  
        /// A value of 0 or less indicates no limit.
        /// </summary>
        /// <example>60</example>
        internal static int CallTransferMaxCallTime { get; set; }

        /// <summary>
        /// The URI of an audio source to play while the transfer attempt is in progress and before far-end answer.
        /// </summary>
        internal static string CallTransferRingBack { get; set; }

        /// <summary>
        /// Routing digits used by sonus specifying Customer (WIC, WNG, Televox, etc.) and preferred Carrier (Qwest, AT&T, Level3).  
        /// </summary>
        /// <remarks> 999020001 = TVX Qwest | 999020002 = TVX AT&T | 999020003 = TVX Level3 | 999000432 = WIC Preprod</remarks>
        /// <example>999020001</example>
        internal static string CallTransferSonusSteeringDigits { get; set; }

        #endregion

        #region CallerID

        /// <summary>
        /// Default caller id to use if one is not provided.
        /// </summary>
        /// <example>3032561030 = DENVER | 3032561031 = ATLANTA</example>
        internal static string DefaultCallerID { get; set; }

        #endregion

        #region Detection

        /// <summary>
        /// Flag to allow DTMF in machine messages.
        /// </summary>
        internal static bool DetectionAllowMachineDTMF { get; set; }

        /// <summary>
        /// Improve detection rates by targeting expected contact type. 
        /// Expected values are RESIDENTIAL or COMMERCIAL.
        /// As of 2012, not currently implemented for SounDecision.
        /// </summary>
        internal static string DetectionContactType { get; set; }

        /// <summary>
        /// Flag to play first voice element during to allow additional analysis to be performed if Human detected.
        /// </summary>
        internal static bool DetectionIncludeInitialHumanGreeting { get; set; }

        /// <summary>
        /// Flag to play first voice element during to allow additional analysis to be performed if Machine detected.
        /// </summary>
        internal static bool DetectionIncludeInitialMachineGreeting { get; set; }

        /// <summary>
        /// Maximum duration (ms) of activity for live answer calls.
        /// </summary>
        internal static int DetectionMaxLiveDuration { get; set; }

        /// <summary>
        /// Maximum attempts to restart detection after interruption during initial prompt.
        /// </summary>
        internal static int DetectionMaxRestarts { get; set; }

        /// <summary>
        /// URI to subdialog hosting detection application (e.g. SounDecision). 
        /// </summary>
        /// <SounDecision>
        /// Default: http://vxmlapps/vxml/amd/subdialog.php
        /// 1.8: http://vxmlapps/vxml/amd/subdialog.php?v=1.8 (allows for configuable MaxLiveDuration and MaxRestarts)
        /// </SounDecision>
        internal static string DetectionSourceURL { get; set; }

        #endregion

        #region Postback URLs        

        /// <summary>
        /// URL to CallStatus.aspx to handle application level disposition.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/CallStatus.aspx</example>
        internal static string PostbackCallStatusURL { get; set; }

        /// <summary>
        /// URL to CallStatus.aspx to handle application level disposition.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/CallStatus.aspx</example>
        internal static string PostbackCallStatusURL_VXMLWebAPI { get; set; }
        
        /// <summary>
        /// URL to Disposition.aspx to handle call level disposition.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/Disposition.aspx</example>
        internal static string PostbackDispositionURL { get; set; }

        /// <summary>
        /// URL to Disposition.aspx to handle call level disposition.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/Disposition.aspx</example>
        internal static string PostbackDispositionURL_VXMLWebAPI { get; set; }

        /// <summary>
        /// URL to Recording.aspx to handle recording left by user.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/Recording.aspx</example>
        internal static string PostbackLeaveMessageURL { get; set; }

        /// <summary>
        /// URL to Recording.aspx to handle recording left by user.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/Recording.aspx</example>
        internal static string PostbackLeaveMessageURL_VXMLWebAPI { get; set; }

        /// <summary>
        /// URL to OptOut.aspx to handle opting out for user.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/OptOut.aspx</example>
        internal static string PostbackOptOutURL { get; set; }

        /// <summary>
        /// URL to OptOut.aspx to handle opting out for user.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/OptOut.aspx</example>
        internal static string PostbackOptOutURL_VXMLWebAPI { get; set; }

        /// <summary>
        /// URL to Survey.aspx to handle survey responses.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/Survey.aspx</example>
        internal static string PostbackSurveyURL { get; set; }

        /// <summary>
        /// URL to Survey.aspx to handle survey responses.
        /// </summary>
        /// <example>http://10.129.2.111:8085/PostContentWebsite/VXML/Survey.aspx</example>
        internal static string PostbackSurveyURL_VXMLWebAPI { get; set; }

        #endregion

        #region Text-to-Speech

        /// <summary>
        /// Preferred female text-to-speech engine to produce synthesized output.
        /// </summary>
        /// <example>RealSpeakUSEnglishJennifer</example>
        internal static VXMLEnum.TTSEngineVoice TTSFemaleVoice { get; set; }

        /// <summary>
        /// Preferred male text-to-speech engine to produce synthesized output
        /// </summary>
        /// <example>RealSpeakUSEnglishTom</example>
        internal static VXMLEnum.TTSEngineVoice TTSMaleVoice { get; set; }

        #endregion

        /// <summary>
        /// HTTP path to survey audio files.
        /// </summary>
        /// <example>http://10.26.224.99:8085/VXMLAudio/AudioFiles/Survey</example>
        internal static string SurveyAudioURL { get; set; }

        /// <summary>
        /// HTTP path to VXMLApplication aspx page to retrieve VXML/Script pages.
        /// </summary>
        /// <example>http://10.26.224.99:8087/VXMLWebsite/VXMLApplication.aspx</example>
        internal static string VXMLWebsiteURL { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <example></example>
        internal static string CommonURL_VXMLWebAPI { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <example></example>
        internal static string ConfirmResponseURL_VXMLWebAPI { get; set; }

        #endregion

        #region Internal Methods

        internal void Load(Dictionary<string, string> config)
        {
            AssignConfigSettings(config);
        }

        #endregion

        #region Protected Override Methods

        /// <summary>
        /// Assign property values from configuration dictionary generated from TeleVox.Core.Configuration
        /// </summary>
        /// <param name="config"></param>
        protected override void AssignConfigSettings(Dictionary<string, string> config)
        {
            string method = ClassNameDot + MethodBase.GetCurrentMethod().Name;
            var traceText = new StringBuilder();
            string configName = string.Empty;
            string configValue = string.Empty;

            // Assign base config settings
            base.AssignConfigSettings(config);

            try
            {
                // AudioDestinationFileExtension
                configName = "AudioDestinationFileExtension";
                configValue = config[configName];
                AudioDestinationFileExtension = (AudioEnum.AudioFileExtension) Enum.Parse(typeof(AudioEnum.AudioFileExtension), configValue);
                traceText.AppendLine(configName + ": " + AudioDestinationFileExtension);

                // AudioDestinationFileFormat
                configName = "AudioDestinationFileFormat";
                configValue = config[configName];
                AudioDestinationFileFormat = (AudioEnum.AudioFormat) Enum.Parse(typeof(AudioEnum.AudioFormat), configValue);
                traceText.AppendLine(configName + ": " + AudioDestinationFileFormat);

                // AudioDestinationRootPath
                configName = "AudioDestinationRootPath";
                configValue = config[configName];
                AudioDestinationRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationRootPath);

                // AudioDestinationRootPathHTTP
                configName = "AudioDestinationRootPathHTTP";
                configValue = config[configName];
                AudioDestinationRootPathHTTP = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationRootPathHTTP);

                // AudioDestinationRootPathAzure
                configName = "AudioDestinationRootPathAzure";
                configValue = config[configName];
                AudioDestinationRootPathAzure = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationRootPathAzure);

                // AudioDestinationCustomerRootPath
                configName = "AudioDestinationCustomerRootPath";
                configValue = config[configName];
                AudioDestinationCustomerRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationCustomerRootPath);

                // AudioDestinationFirstNameLibraryRootPath
                configName = "AudioDestinationFirstNameLibraryRootPath";
                configValue = config[configName];
                AudioDestinationFirstNameLibraryRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationFirstNameLibraryRootPath);

                // AudioDestinationPromptsRootPath
                configName = "AudioDestinationPromptsRootPath";
                configValue = config[configName];
                AudioDestinationPromptsRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationPromptsRootPath);

                // AudioDestinationSurveyRootPath
                configName = "AudioDestinationSurveyRootPath";
                configValue = config[configName];
                AudioDestinationSurveyRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioDestinationSurveyRootPath);

                // AudioSourceCustomerRootPath
                configName = "AudioSourceCustomerRootPath";
                configValue = config[configName];
                AudioSourceCustomerRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioSourceCustomerRootPath);

                // AudioSourceFileFormat
                configName = "AudioSourceFileFormat";
                configValue = config[configName];
                AudioSourceFileFormat = (AudioEnum.AudioFormat) Enum.Parse(typeof(AudioEnum.AudioFormat), configValue);
                traceText.AppendLine(configName + ": " + AudioSourceFileFormat);

                // AudioSourceFirstNameLibraryRootPath
                configName = "AudioSourceFirstNameLibraryRootPath";
                configValue = config[configName];
                AudioSourceFirstNameLibraryRootPath = configValue;
                traceText.AppendLine(configName + ": " + AudioSourceFirstNameLibraryRootPath);

                // AzureBlobSASToken
                configName = "AzureBlobSASToken";
                configValue = config[configName];
                AzureBlobSASToken = configValue;
                traceText.AppendLine(configName + ": " + AzureBlobSASToken);

                // AzureAudioContainerName
                configName = "AzureAudioContainerName";
                configValue = config[configName];
                AzureAudioContainerName = configValue;
                traceText.AppendLine(configName + ": " + AzureAudioContainerName);

                // CallTransferConnectTimeout
                configName = "CallTransferConnectTimeout";
                configValue = config[configName];
                CallTransferConnectTimeout = Convert.ToInt32(configValue);
                traceText.AppendLine(configName + ": " + CallTransferConnectTimeout);

                // CallTransferRingBack
                configName = "CallTransferRingBack";
                configValue = config[configName];
                CallTransferRingBack = configValue;
                traceText.AppendLine(configName + ": " + CallTransferRingBack);

                // CallTransferMaxCallTime
                configName = "CallTransferMaxCallTime";
                configValue = config[configName];
                CallTransferMaxCallTime = Convert.ToInt32(configValue);
                traceText.AppendLine(configName + ": " + CallTransferMaxCallTime);

                // CallTransferSonusSteeringDigits
                configName = "CallTransferSonusSteeringDigits";
                configValue = config[configName];
                CallTransferSonusSteeringDigits = (configValue);
                traceText.AppendLine(configName + ": " + CallTransferSonusSteeringDigits);

                // DefaultCallerID
                configName = "DefaultCallerID";
                configValue = config[configName];
                DefaultCallerID = (configValue);
                traceText.AppendLine(configName + ": " + DefaultCallerID);

                // DetectionAllowMachineDTMF
                configName = "DetectionAllowMachineDTMF";
                configValue = config[configName];
                DetectionAllowMachineDTMF = Convert.ToBoolean(configValue);
                traceText.AppendLine(configName + ": " + DetectionAllowMachineDTMF);

                // DetectionContactType
                configName = "DetectionContactType";
                configValue = config[configName];
                DetectionContactType = (configValue);
                traceText.AppendLine(configName + ": " + DetectionContactType);

                // DetectionIncludeInitialHumanGreeting
                configName = "DetectionIncludeInitialHumanGreeting";
                configValue = config[configName];
                DetectionIncludeInitialHumanGreeting = Convert.ToBoolean(configValue);
                traceText.AppendLine(configName + ": " + DetectionIncludeInitialHumanGreeting);

                // DetectionIncludeInitialMachineGreeting
                configName = "DetectionIncludeInitialMachineGreeting";
                configValue = config[configName];
                DetectionIncludeInitialMachineGreeting = Convert.ToBoolean(configValue);
                traceText.AppendLine(configName + ": " + DetectionIncludeInitialMachineGreeting);

                // DetectionMaxLiveDuration
                configName = "DetectionMaxLiveDuration";
                configValue = config[configName];
                DetectionMaxLiveDuration = Convert.ToInt32(configValue);
                traceText.AppendLine(configName + ": " + DetectionMaxLiveDuration);

                // DetectionMaxRestarts
                configName = "DetectionMaxRestarts";
                configValue = config[configName];
                DetectionMaxRestarts = Convert.ToInt32(configValue);
                traceText.AppendLine(configName + ": " + DetectionMaxRestarts);

                // DetectionSourceURL
                configName = "DetectionSourceURL";
                configValue = config[configName];
                DetectionSourceURL = (configValue);
                traceText.AppendLine(configName + ": " + DetectionSourceURL);               

                // PostbackCallStatusURL
                configName = "PostbackCallStatusURL";                
                configValue = config[configName];
                PostbackCallStatusURL = (configValue);
                traceText.AppendLine(configName + ": " + PostbackCallStatusURL);

                // PostbackCallStatusURL_VXMLWebAPI
                configName = "PostbackCallStatusURL_VXMLWebAPI";                
                configValue = config[configName];
                PostbackCallStatusURL_VXMLWebAPI = (configValue);
                traceText.AppendLine(configName + ": " + PostbackCallStatusURL_VXMLWebAPI);

                // PostbackDispositionURL 
                configName = "PostbackDispositionURL";                
                configValue = config[configName];
                PostbackDispositionURL = (configValue);
                traceText.AppendLine(configName + ": " + PostbackDispositionURL);

                // PostbackDispositionURL_VXMLWebAPI 
                configName = "PostbackDispositionURL_VXMLWebAPI";                
                configValue = config[configName];
                PostbackDispositionURL_VXMLWebAPI = (configValue);
                traceText.AppendLine(configName + ": " + PostbackDispositionURL_VXMLWebAPI);

                // PostbackLeaveMessageURL
                configName = "PostbackLeaveMessageURL";                
                configValue = config[configName];
                PostbackLeaveMessageURL = (configValue);
                traceText.AppendLine(configName + ": " + PostbackLeaveMessageURL);

                // PostbackLeaveMessageURL_VXMLWebAPI
                configName = "PostbackLeaveMessageURL_VXMLWebAPI";                
                configValue = config[configName];
                PostbackLeaveMessageURL_VXMLWebAPI = (configValue);
                traceText.AppendLine(configName + ": " + PostbackLeaveMessageURL_VXMLWebAPI);

                // PostbackOptOutURL
                configName = "PostbackOptOutURL";                
                configValue = config[configName];
                PostbackOptOutURL = (configValue);
                traceText.AppendLine(configName + ": " + PostbackOptOutURL);

                // PostbackOptOutURL_VXMLWebAPI
                configName = "PostbackOptOutURL_VXMLWebAPI";                
                configValue = config[configName];
                PostbackOptOutURL_VXMLWebAPI = (configValue);
                traceText.AppendLine(configName + ": " + PostbackOptOutURL_VXMLWebAPI);

                // PostbackSurveyURL
                configName = "PostbackSurveyURL";
                configValue = config[configName];
                PostbackSurveyURL = (configValue);
                traceText.AppendLine(configName + ": " + PostbackSurveyURL);

                // PostbackSurveyURL_VXMLWebAPI
                configName = "PostbackSurveyURL_VXMLWebAPI";                
                configValue = config[configName];
                PostbackSurveyURL_VXMLWebAPI = (configValue);
                traceText.AppendLine(configName + ": " + PostbackSurveyURL_VXMLWebAPI);

                // TTSFemaleVoice
                configName = "TTSFemaleVoice";
                configValue = config[configName];
                TTSFemaleVoice = (VXMLEnum.TTSEngineVoice) Enum.Parse(typeof(VXMLEnum.TTSEngineVoice), configValue);
                traceText.AppendLine(configName + ": " + TTSFemaleVoice);

                // TTSMaleVoice 
                configName = "TTSMaleVoice";
                configValue = config[configName];
                TTSMaleVoice = (VXMLEnum.TTSEngineVoice) Enum.Parse(typeof(VXMLEnum.TTSEngineVoice), configValue);
                traceText.AppendLine(configName + ": " + TTSMaleVoice);

                // SurveyAudioURL
                configName = "SurveyAudioURL";
                configValue = config[configName];
                SurveyAudioURL = configValue;
                traceText.AppendLine(configName + ": " + SurveyAudioURL);

                // VXMLWebsiteURL
                configName = "VXMLWebsiteURL";
                configValue = config[configName];
                VXMLWebsiteURL = configValue;
                traceText.AppendLine(configName + ": " + VXMLWebsiteURL);

                // CommonURL_VXMLWebAPI
                configName = "CommonURL_VXMLWebAPI";
                configValue = config[configName];
                CommonURL_VXMLWebAPI = configValue;
                traceText.AppendLine(configName + ": " + CommonURL_VXMLWebAPI);

                // ConfirmResponseURL_VXMLWebAPI
                configName = "ConfirmResponseURL_VXMLWebAPI";
                configValue = config[configName];
                ConfirmResponseURL_VXMLWebAPI = configValue;
                traceText.AppendLine(configName + ": " + ConfirmResponseURL_VXMLWebAPI);
            }
            catch (KeyNotFoundException ex1)
            {
                throw new Exception("Configuration key [" + configName + "] not found. " + ex1.Message);
            }
            catch (FormatException ex2)
            {
                throw new Exception("Configuration key [" + configName + "] with value [" + configValue + "] is invalid. " + ex2.Message);
            }

            // Raise LogEvent write configuration values to SQL
            FireLoggingEvent(method, "Custom Configuration Settings- " + traceText, LoggingEnums.VerbosityLevel.Low);
        }

        #endregion
    }

}